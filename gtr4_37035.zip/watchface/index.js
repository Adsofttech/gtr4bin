﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_pai_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let timeSensor = ''

                // смена безеля
                let btn_bezel = ''
                let bg_list = [
                  'bezel_1.png',
                  'bezel_2.png',
                  'bezel_3.png',
                  'bezel_4.png',
                  //'bezel_5.png',
                ];
              let crownSensitivity = 70;		// уровень чувствительности колесика
              let bg_index = 0;
              let degreeSum = 0;
        
              function onDigitalCrown() {
                  hmApp.registerSpinEvent(function (key, degree) {
                          if (key === hmApp.key.HOME) {
                              degreeSum += degree;
                              if (Math.abs(degreeSum) > crownSensitivity){
                                  let step = degreeSum < 0 ? -1 : 1;
                                  bg_index += step;
                                  bg_index = bg_index < 0 ? bg_list.length + bg_index : bg_index % bg_list.length;
                                  degreeSum = 0;
        
                                  normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
                                  hmUI.showToast({text: "<Цвет фона> " + parseInt(bg_index+1) });
                              }
                          }
                      }
                  ) // crown
              }
        
              let hands_smoth_btn = ''
              let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
              let sec_smoth_state_txt = ''
        
              function click_bot_ssmoth_Switcher() {
        
                let bot_sec_state_total = 6;
        
                sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;
        
                switch (sec_smoth_state) {
        
                    case 0:
                      normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                        hour_path: 'hour_1.png',
                        hour_centerX: 233,
                        hour_centerY: 233,
                        hour_posX: 233,
                        hour_posY: 233,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                      });
          
                      normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                        minute_path: 'min_1.png',
                        minute_centerX: 233,
                        minute_centerY: 233,
                        minute_posX: 233,
                        minute_posY: 233,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                      });
          
                      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                        second_path: 'sec_1.png',
                        second_centerX: 233,
                        second_centerY: 233,
                        second_posX: 233,
                        second_posY: 233,
                        second_cover_path: 'dot_1.png',
                        second_cover_x: 219,
                        second_cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                      });
              
                      sec_smoth_state_txt = 'Стрелка 1';
                        break;
        
                    case 1:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_2.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_2.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_2.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 2';
                        break;
        
                    case 2:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_3.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_3.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_3.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 3';
                        break;
        
                    case 3:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_4.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_4.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_4.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 4';
                        break;
        
                    case 4:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_5.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_5.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_5.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 5';
                        break;
        
                    case 5:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_6.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_6.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_6.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 6';
                        break;
        
                    case 6:
        
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_7.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 233,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_7.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 233,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_7.png',
                      second_centerX: 233,
                      second_centerY: 233,
                      second_posX: 233,
                      second_posY: 233,
                      second_cover_path: 'dot_1.png',
                      second_cover_x: 219,
                      second_cover_y: 0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                      sec_smoth_state_txt = 'Стрелка 7';
                        break;
        
                    default:
                        break;
                }
        
                hmUI.showToast({ text: sec_smoth_state_txt });
              }
        
              let btn_mask = ''
              let mask_num = 1
              let mask_all = 2
           
              function click_mask() {
                  if(mask_num>=mask_all) {mask_num=1;}
                  else { mask_num=mask_num+1;}
                  hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
                  normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
              }
        

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 412,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 274,
              y: 412,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'mes_1.png',
              center_x: 233,
              center_y: 233,
              posX: 233,
              posY: 233,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour24_1.png',
              // center_x: 233,
              // center_y: 279,
              // x: 233,
              // y: 279,
              // start_angle: 0,
              // end_angle: -360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 233,
              pos_y: 279 - 279,
              center_x: 233,
              center_y: 279,
              src: 'hour24_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 19,
              y: 0,
              src: 'date_p.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 378,
              day_startY: 217,
              day_sc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_tc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_en_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              second_cover_path: 'dot_1.png',
              second_cover_x: 219,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

      // календарь
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 348,
        y: 184,
        w: 97,
        h: 97,
        text: '',
        normal_src: '',
        press_src: '',
        click_func: () => {
        hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
       });	

       hands_smoth_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 184,
        y: 184,
        text: '',
        w: 97,
        h: 97,
        normal_src: '',
        press_src: '',
        click_func: () => {
          click_bot_ssmoth_Switcher();
            vibro(25);
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      hands_smoth_btn.setProperty(hmUI.prop.VISIBLE, true);

      btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 184,
        y: 28,
        text: '',
        w: 97,
        h: 97,
        normal_src: '',
        press_src: '',
        click_func: () => {
          click_mask();
            vibro(25);
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      btn_mask.setProperty(hmUI.prop.VISIBLE, true);


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_aod.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 233,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_aod.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 233,
              minute_posY: 233,
              minute_cover_path: 'dot_1.png',
              minute_cover_x: 219,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = -360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                setTimeout(() => {
                  onDigitalCrown();
                }, 350);

                text_update();
              }),
              pause_call: (function () {
                hmApp.unregisterSpinEvent();

              }),

            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}