﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'backG_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -237,
              second_startY: -9,
              second_array: ["zSecond_redline_0001.png","zSecond_redline_0002.png","zSecond_redline_0003.png","zSecond_redline_0004.png","zSecond_redline_0005.png","zSecond_redline_0006.png","zSecond_redline_0007.png","zSecond_redline_0008.png","zSecond_redline_0009.png","zSecond_redline_0010.png"],
              second_zero: 1,
              second_space: -316,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 131,
              y: 0,
              src: 'Center_Grey_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 138,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: -3,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 138,
              minute_startY: 153,
              minute_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 425,
              src: 'bluetoothoff (2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 246,
              y: 418,
              src: 'logo_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 138,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 138,
              minute_startY: 153,
              minute_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: -12,
              src: 'Logo_6z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -32,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  