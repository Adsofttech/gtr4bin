﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_image_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_stress_icon_img = ''
        let idle_stand_icon_img = ''
        let idle_stand_pointer_progress_img_pointer = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_image_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_pai_icon_img = ''
        

        
        
    		function loadSettings() {


    			if (hmFS.SysProGetInt('PRADO_X96_zona_left') === undefined) {
    				zona_left = 0;
    				hmFS.SysProSetInt('PRADO_X96_zona_left', zona_left);
    			} else {
    				zona_left = hmFS.SysProGetInt('PRADO_X96_zona_left');
    			}
                
    			if (hmFS.SysProGetInt('PRADO_X96_zona_right') === undefined) {
    				zona_right = 0;
    				hmFS.SysProSetInt('PRADO_X96_zona_right', zona_right);
    			} else {
    				zona_right = hmFS.SysProGetInt('PRADO_X96_zona_right');
    			}

    			if (hmFS.SysProGetInt('PRADO_X96_zona') === undefined) {
    				zona = 0;
    				hmFS.SysProSetInt('PRADO_X96_zona', zona);
    			} else {
    				zona = hmFS.SysProGetInt('PRADO_X96_zona');
    			}


    		}        
        
        
         function makeAOD() {
             
    			let zona = hmFS.SysProGetInt('PRADO_X96_zona');

             
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 56,
              y: 250,
              src: 'bg_dig_8.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 78,
              src: 'pr_8.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_normal_WEATHER_CURRENT_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 311,
              center_y: 136,
              x: 74,
              y: 74,
              start_angle: 68,
              end_angle: -113,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 155,
              center_y: 136,
              x: 74,
              y: 74,
              start_angle: -65,
              end_angle: 110,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			 
            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			 

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 127,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });




            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 330,
              font_array: ["dig_c_0.png","dig_c_1.png","dig_c_2.png","dig_c_3.png","dig_c_4.png","dig_c_5.png","dig_c_6.png","dig_c_7.png","dig_c_8.png","dig_c_9.png"],
              padding: true,
              h_space: 3,
              invalid_image: 'dig_c_pv.png',
              dot_image: 'dig_c_dot2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 205,
              src: 'ic_kcal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			 
            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dig_a_dot2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
                
            idle_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 34,
              y: 205,
              image_array: ["Ic_vos_0.png","Ic_vos_1.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });			 

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 288,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 288,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 335,
              second_startY: 287,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 406,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 260,
              y: 403,
              image_array: ["puls_pr_0.png","puls_pr_1.png","puls_pr_2.png","puls_pr_3.png","puls_pr_4.png","puls_pr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 262,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 272,
              month_startY: 257,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 262,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 209,
              y: 26,
              src: 'slider_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 391,
              y: 291,
              src: 'slider_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 81,
              font_array: ["dig_t_0.png","dig_t_1.png","dig_t_2.png","dig_t_3.png","dig_t_4.png","dig_t_5.png","dig_t_6.png","dig_t_7.png","dig_t_8.png","dig_t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dig_t_g.png',
              unit_tc: 'dig_t_g.png',
              unit_en: 'dig_t_g.png',
              negative_image: 'dig_t_m.png',
              invalid_image: 'dig_t_v.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 178,
              font_array: ["dig_t_0.png","dig_t_1.png","dig_t_2.png","dig_t_3.png","dig_t_4.png","dig_t_5.png","dig_t_6.png","dig_t_7.png","dig_t_8.png","dig_t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dig_t_g.png',
              unit_tc: 'dig_t_g.png',
              unit_en: 'dig_t_g.png',
              negative_image: 'dig_t_m.png',
              invalid_image: 'dig_t_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 127,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dig_p_gp.png',
              unit_tc: 'dig_p_gp.png',
              unit_en: 'dig_p_gp.png',
              negative_image: 'dig_p_m.png',
              invalid_image: 'dig_p_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 359,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
             
                    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {
                            stopVibro();
                        }),
                        pause_call: (function () {
                            stopVibro();
                        }),
                    });  
			 
idle_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
idle_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
                
idle_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
idle_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona == 1);             
             
             
         }        
        
        
            let btn_zona_left = ''
            let zona_left = 0

            function click_zona_left() {

                zona_left = (zona_left + 1) % 8;

             normal_stand_icon_img.setProperty(hmUI.prop.MORE, {
              x: 100,
              y: 78,
              src: 'pr_' + zona_left + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    			hmFS.SysProSetInt('PRADO_X96_zona_left', zona_left);

            }
        
            let btn_zona_right = ''
            let zona_right = 0

            function click_zona_right() {

                zona_right = (zona_right + 1) % 8;
                
            normal_stress_icon_img.setProperty(hmUI.prop.MORE, {
              x: 56,
              y: 250,
              src: 'bg_dig_' + zona_right + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                
                

    			hmFS.SysProSetInt('PRADO_X96_zona_right', zona_right);
            }
        
            let btn_zona = ''
            let zona = 0

            function click_zona() {

                zona = (zona + 1) % 2;
                
normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
                
normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona == 1);

    			hmFS.SysProSetInt('PRADO_X96_zona', zona);
            }
        
        
        
        
        
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
            let stopVibro_Timer = null;

            function vibro(scene = 25) {
                let stopDelay = 50;
                vibrate.stop();
                vibrate.scene = scene;
                if (scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }

            function stopVibro() {
                vibrate.stop();
                timer.stopTimer(stopVibro_Timer);
            }        
        
        
         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }            

         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,

          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }   
        
        
            
    		//переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
    		let weatherTxtImgArray = []
    		let weatherTxtImgArrayN = []
    		let pointred = new Array(6);
    		let pointblue = new Array(5);
    		let linered = new Array(6);
    		let lineblue = new Array(5);
    		let yArrH = new Array(6);
    		let yArrL = new Array(5);
    		let y_pogodaH = new Array(6);
    		let y_pogodaL = new Array(5);
    		let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
    		let week_weater_img = []
    		let day_weater_img = []
    		const ROOTPATH = "images/"

    		//let normal_city_name_text = ''
            let curTime = hmSensor.createSensor(hmSensor.id.TIME);

			
			
    			//-------------------------------- 
		 
  		//массив иконок для графика       
    		for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28

    		}

    		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
    		let weatherData = weather.getForecastWeather();
    		let forecastData = weatherData.forecastData;


    		//обновление для   графика           
    		function updateGrafik() {
				
//       weatherData = weather.getForecastWeather();
//       forecastData = weatherData.forecastData;
      // normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
				
				
				
				
    			if (forecastData.count == 0) {
    				for (let i = 0; i < 6; i++) {
    					var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");

    				}
    			} else {
    				let weekDay = curTime.week - 1;
    				for (let i = 0; i < 6; i++) {
    					yArrH[i] = forecastData.data[i].high;
    					let element = forecastData.data[i];
    					let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
    					let date = new Date(curTime.utc + 86400000 * i);
    					let data = date.getDate();
    					let week = week_weater[weekDay];
    					week_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: week,
    					});
    					day_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: data,
    					});
    					weekDay = (weekDay + 1) % 7;
    				}
    			}


    			for (let i = 0; i < 5; i++) {
    				yArrL[i] = forecastData.data[i].low;
    			}
    			let maxH = Math.max(...yArrH)
    			let maxL = Math.min(...yArrL)
    			var shag = 46;
    			var x0 = 119;
    			for (let i = 0; i < 6; i++) {
    				pointred[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + shag * [i] - 5,
    					y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFFFF0000,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 5; i++) {
    				yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					linered[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i,
    						h: 466,
    						pos_x: -31 + shag * i,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_red.png',
    					});
    			};
    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 4; i++) {
    				yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					lineblue[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i + 23,
    						h: 466,
    						pos_x: -31 + shag * i + 23,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i + 23,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_blue.png',
    					});
    			};

    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 6; i++) {
    				y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
    				weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + i * 45 * 1.02,
    					y: y_pogodaH[i] - 38, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrH[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}

    			for (let i = 0; i < 5; i++) {
    				y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
    				weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + 23 + i * 45 * 1.02,
    					y: y_pogodaL[i] - 1, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrL[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}
    		}				
        
        
        


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                
                loadSettings()                
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 56,
              y: 250,
              src: 'bg_dig_' + zona_right + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 78,
              src: 'pr_' + zona_left + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


				
            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 155,
              center_y: 136,
              x: 74,
              y: 74,
              start_angle: -65,
              end_angle: 110,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
				
				
            normal_WEATHER_CURRENT_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_pr.png',
              center_x: 311,
              center_y: 136,
              x: 74,
              y: 74,
              start_angle: 68,
              end_angle: -113,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 127,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 330,
              font_array: ["dig_c_0.png","dig_c_1.png","dig_c_2.png","dig_c_3.png","dig_c_4.png","dig_c_5.png","dig_c_6.png","dig_c_7.png","dig_c_8.png","dig_c_9.png"],
              padding: true,
              h_space: 3,
              invalid_image: 'dig_c_pv.png',
              dot_image: 'dig_c_dot2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 205,
              src: 'ic_kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 215,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dig_a_dot2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 34,
              y: 205,
              image_array: ["Ic_vos_0.png","Ic_vos_1.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 288,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 288,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 335,
              second_startY: 287,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 406,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 260,
              y: 403,
              image_array: ["puls_pr_0.png","puls_pr_1.png","puls_pr_2.png","puls_pr_3.png","puls_pr_4.png","puls_pr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 262,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 272,
              month_startY: 257,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 262,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 209,
              y: 26,
              src: 'slider_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 391,
              y: 291,
              src: 'slider_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 81,
              font_array: ["dig_t_0.png","dig_t_1.png","dig_t_2.png","dig_t_3.png","dig_t_4.png","dig_t_5.png","dig_t_6.png","dig_t_7.png","dig_t_8.png","dig_t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dig_t_g.png',
              unit_tc: 'dig_t_g.png',
              unit_en: 'dig_t_g.png',
              negative_image: 'dig_t_m.png',
              invalid_image: 'dig_t_v.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 178,
              font_array: ["dig_t_0.png","dig_t_1.png","dig_t_2.png","dig_t_3.png","dig_t_4.png","dig_t_5.png","dig_t_6.png","dig_t_7.png","dig_t_8.png","dig_t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dig_t_g.png',
              unit_tc: 'dig_t_g.png',
              unit_en: 'dig_t_g.png',
              negative_image: 'dig_t_m.png',
              invalid_image: 'dig_t_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 127,
              font_array: ["dig_p_0.png","dig_p_1.png","dig_p_2.png","dig_p_3.png","dig_p_4.png","dig_p_5.png","dig_p_6.png","dig_p_7.png","dig_p_8.png","dig_p_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dig_p_gp.png',
              unit_tc: 'dig_p_gp.png',
              unit_en: 'dig_p_gp.png',
              negative_image: 'dig_p_m.png',
              invalid_image: 'dig_p_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 359,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



                
                
          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });
                
                
                    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {
                            stopVibro();
            updateGrafik();
                        }),
                        pause_call: (function () {
                            stopVibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
           groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false); 
                        }),
                    });
                
                
//
          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });//  
                
                    btn_zona_left = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 3, //x кнопки
                        y: 111, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 84, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            click_zona_left();
                            vibro(); //имя вызываемой функции
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });                
                
                    btn_zona_right = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 363, //x кнопки
                        y: 111, //y кнопки
                        text: '',
                        w: 100, //ширина кнопки
                        h: 100, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            click_zona_right();
                            vibro(); //имя вызываемой функции
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                
                    btn_zona = groupVremya.createWidget(hmUI.widget.BUTTON, {
                        x: 28, //x кнопки
                        y: 195, //y кнопки
                        text: '',
                        w: 154, //ширина кнопки
                        h: 64, //высота кнопки
                        normal_src: '0_Empty.png',
                        press_src: '0_Empty.png',
                        click_func: () => {
                            click_zona();
                            vibro(); //имя вызываемой функции
                        },
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                
          btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
//           longpress_func: () => {
//            vibro();
//			   blok_btn_on();
//           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          }); 
                
                
                
                
         groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmApp.startApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 24,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_run();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_zona_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });                  

                
          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
                    
                    
          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });                 
                
                
                
normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
                
normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona == 1);
                
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);                
                
                
                
                //dynamic modify end
            },
            
            
    			onInit() {
    				stopVibro();
    				loadSettings();
    				logger.log('index page.js on init invoke');
    			},
//            build() {
//                this.init_view();
//                logger.log('index page.js on ready invoke');
//            },
    			build() {
    				if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) {
    					makeAOD();
    				} else {
    					this.init_view();
    				}
    			},        
            onDestroy() {
    				vibrate && vibrate.stop();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}