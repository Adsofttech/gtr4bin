﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_sun_low_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_sun_low_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 105,
              src: '0098.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 306,
              y: 105,
              src: '0099.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 323,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 316,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 379,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 215,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 138,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 329,
              y: 242,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 367,
              center_y: 233,
              posX: 12,
              posY: 62,
              start_angle: -30,
              end_angle: 335,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 339,
              day_startY: 204,
              day_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 60,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 171,
              hour_startY: 107,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'pointer_3.png',
              hour_unit_tc: 'pointer_3.png',
              hour_unit_en: 'pointer_3.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 107,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuta.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 208,
              minute_cover_path: 'pointer.png',
              minute_cover_x: 214,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 11,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 101,
              w: 44,
              h: 44,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 36,
              w: 165,
              h: 58,
              src: 'dot.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 316,
              w: 63,
              h: 63,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 307,
              w: 117,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 233,
              y: 101,
              w: 68,
              h: 49,
              src: 'dot.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 101,
              w: 73,
              h: 49,
              src: 'dot.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 372,
              w: 165,
              h: 58,
              src: 'dot.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 105,
              src: '0098.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 306,
              y: 105,
              src: '0099.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 323,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 316,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 379,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 215,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 138,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 329,
              y: 242,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 367,
              center_y: 233,
              posX: 12,
              posY: 62,
              start_angle: -30,
              end_angle: 335,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 339,
              day_startY: 204,
              day_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 60,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 171,
              hour_startY: 107,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'pointer_3.png',
              hour_unit_tc: 'pointer_3.png',
              hour_unit_en: 'pointer_3.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 107,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuta.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 208,
              minute_cover_path: 'pointer.png',
              minute_cover_x: 214,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 11,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  