﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let idle_background_bg_img = ''
        let editableZone_1_city_name_text = null;
        let editGroup_1  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 181,
              y: 267,
              w: 100,
              h: 100,
              select_image: '0006.png',
              un_select_image: '0076.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0069.png' },
                { type: hmUI.edit_type.CAL, preview: '0065.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0021.png' },
                { type: hmUI.edit_type.HEART, preview: '0029.png' },
                { type: hmUI.edit_type.PAI, preview: '0027.png' },
                { type: hmUI.edit_type.WIND, preview: '0023.png' },
                { type: hmUI.edit_type.WEATHER, preview: '0063.png' },
                { type: hmUI.edit_type.SPO2, preview: '0067.png' },
                { type: hmUI.edit_type.UVI, preview: '0025.png' },
                { type: hmUI.edit_type.STAND, preview: '0072.png' },
              ],
              count: 10,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0073.png',
              tips_x: 6,
              tips_y: 106,
              tips_width: 105,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0018.png',
                  unit_tc: '0018.png',
                  unit_en: '0018.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0007.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 203,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0068.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0064.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png"],
                  image_length: 6,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0028.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 215,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0026.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 235,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND_TARGET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 205,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: true,
                  h_space: 0,
                  unit_sc: '0071.png',
                  unit_tc: '0071.png',
                  unit_en: '0071.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0070.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0018.png',
                  unit_tc: '0018.png',
                  unit_en: '0018.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0066.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 212,
                  y: 280,
                  image_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 192,
                  y: 346,
                  w: 150,
                  h: 30,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFF00,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0062.png',
                  unit_tc: '0062.png',
                  unit_en: '0062.png',
                  negative_image: '0061.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["uvi_1.png","uvi_2.png","uvi_3.png","uvi_4.png","uvi_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 220,
                  y: 335,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0024.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 55,
                  y: 55,
                  image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
                  image_length: 12,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 212,
                  y: 313,
                  image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 221,
                  y: 339,
                  font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 212,
                  y: 280,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0074.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0075.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 10,
                    posY: 231,
                    path: '0005.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 14,
                    posY: 167,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 15,
                    posY: 207,
                    path: '0004.png',
                  },
                },
              ],
              count: 1,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            function scale_call() {

              console.log('Edit element Wearther city name');

              if(editableZone_1_city_name_text){
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              editableZone_1_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}