﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let idle_date_text_date_week = ''
		let time=false
//		let weatherData=false
//		let weatherSensor=false
		let showarrow=true;
		let normal_showhide_arrow= '';
		let normal_weather_text='';
		let normal_moon_text='';
		let normal_date_text_date_day = '';
		let idle_date_text_date_day = '';

		let normal_date_text_date_week = '';
		let normal_anim_h='';
//		let normal_anim_h_group='';
//		let anim_f=10;
//		let fps_s=30;
		let normal_digital_clock_img_time1='';
		let normal_showhide_arrow1='';
		let normal_battery_linear_scale='';
		let normal_date_text_month='';
		let idle_count_down_img='';
		let idle_stop_watch_img='';
		let idle_alarm_clock_img='';
		
		let con_rest='Connection restored';
		let con_lost='Connection lost';
		
		let weekday=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
		let weather_text=['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime'];
		let month_text=["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		let moonphase=["New Moon","Waxing Crescent","First Quarter","Waxing Gibbous","Full Moon","Waning Gibbous","Last Quarter","Waning Crescent"];
		let aod_text=["battery", "steps", "bpm"];
		
		
		let curv_group=''; // група для отображения надписей вдоль окружности
		let curv_groupi=[]; // массив для заполнения IMG в надписях вдоль окружности, для удаения виджетов при перерисовке
		let curv_sun_rise='';
		let curv_sun_set='';
		let curv_batt='';
		let curv_weatherText='';
		let curv_moonphasetext='';
		let curv_weather_text='';
 	
		let font18={
		  count: 139,
		  path: "font/",
		  files: ["F_18_48.png","F_18_49.png","F_18_50.png","F_18_51.png","F_18_52.png","F_18_53.png","F_18_54.png","F_18_55.png","F_18_56.png","F_18_57.png","F_18_65.png","F_18_66.png","F_18_67.png","F_18_68.png","F_18_69.png","F_18_70.png","F_18_71.png","F_18_72.png","F_18_73.png","F_18_74.png","F_18_75.png","F_18_76.png","F_18_77.png","F_18_78.png","F_18_79.png","F_18_80.png","F_18_81.png","F_18_82.png","F_18_83.png","F_18_84.png","F_18_85.png","F_18_86.png","F_18_87.png","F_18_88.png","F_18_89.png","F_18_90.png","F_18_1040.png","F_18_1041.png","F_18_1042.png","F_18_1043.png","F_18_1044.png","F_18_1045.png","F_18_1025.png","F_18_1046.png","F_18_1047.png","F_18_1048.png","F_18_1049.png","F_18_1050.png","F_18_1051.png","F_18_1052.png","F_18_1053.png","F_18_1054.png","F_18_1055.png","F_18_1056.png","F_18_1057.png","F_18_1058.png","F_18_1059.png","F_18_1060.png","F_18_1061.png","F_18_1062.png","F_18_1063.png","F_18_1064.png","F_18_1065.png","F_18_1068.png","F_18_1067.png","F_18_1066.png","F_18_1069.png","F_18_1070.png","F_18_1071.png","F_18_1030.png","F_18_1031.png","F_18_45.png","F_18_43.png","F_18_46.png","F_18_44.png","F_18_58.png","F_18_39.png","F_18_34.png","F_18_97.png","F_18_98.png","F_18_99.png","F_18_100.png","F_18_101.png","F_18_102.png","F_18_103.png","F_18_104.png","F_18_105.png","F_18_106.png","F_18_107.png","F_18_108.png","F_18_109.png","F_18_110.png","F_18_111.png","F_18_112.png","F_18_113.png","F_18_114.png","F_18_115.png","F_18_116.png","F_18_117.png","F_18_118.png","F_18_119.png","F_18_120.png","F_18_121.png","F_18_122.png","F_18_1072.png","F_18_1073.png","F_18_1074.png","F_18_1075.png","F_18_1076.png","F_18_1077.png","F_18_1105.png","F_18_1078.png","F_18_1079.png","F_18_1080.png","F_18_1081.png","F_18_1082.png","F_18_1083.png","F_18_1084.png","F_18_1085.png","F_18_1086.png","F_18_1087.png","F_18_1088.png","F_18_1089.png","F_18_1090.png","F_18_1091.png","F_18_1092.png","F_18_1093.png","F_18_1094.png","F_18_1095.png","F_18_1096.png","F_18_1097.png","F_18_1100.png","F_18_1099.png","F_18_1098.png","F_18_1101.png","F_18_1102.png","F_18_1103.png","F_18_1110.png","F_18_1111.png"],
		  index: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯІЇ-+.,:'\"abcdefghijklmnopqrstuvwxyzабвгдеёжзийклмнопрстуфхцчшщьыъэюяії",
		  height: 24,
		  width: [24,24,24,24,24,24,24,24,24,24,14,14,13,15,13,13,14,16,8,12,14,12,19,16,15,13,15,14,13,12,15,14,19,13,13,13,14,14,14,12,15,13,13,19,12,16,16,14,15,19,16,15,15,13,13,12,12,16,13,15,14,19,19,13,18,13,13,20,13,8,8,10,10,7,7,7,6,9,14,14,12,14,13,9,14,15,8,8,13,8,20,15,14,14,14,11,12,9,15,13,18,13,13,12,14,14,13,12,15,13,13,18,11,14,14,13,14,17,14,14,14,14,12,12,13,16,13,14,14,19,20,12,17,13,12,18,13,8,8]
		}		
		let font25={
		  count: 139,
		  path: "font/",
		  files: ["F_25_48.png","F_25_49.png","F_25_50.png","F_25_51.png","F_25_52.png","F_25_53.png","F_25_54.png","F_25_55.png","F_25_56.png","F_25_57.png","F_25_65.png","F_25_66.png","F_25_67.png","F_25_68.png","F_25_69.png","F_25_70.png","F_25_71.png","F_25_72.png","F_25_73.png","F_25_74.png","F_25_75.png","F_25_76.png","F_25_77.png","F_25_78.png","F_25_79.png","F_25_80.png","F_25_81.png","F_25_82.png","F_25_83.png","F_25_84.png","F_25_85.png","F_25_86.png","F_25_87.png","F_25_88.png","F_25_89.png","F_25_90.png","F_25_1040.png","F_25_1041.png","F_25_1042.png","F_25_1043.png","F_25_1044.png","F_25_1045.png","F_25_1025.png","F_25_1046.png","F_25_1047.png","F_25_1048.png","F_25_1049.png","F_25_1050.png","F_25_1051.png","F_25_1052.png","F_25_1053.png","F_25_1054.png","F_25_1055.png","F_25_1056.png","F_25_1057.png","F_25_1058.png","F_25_1059.png","F_25_1060.png","F_25_1061.png","F_25_1062.png","F_25_1063.png","F_25_1064.png","F_25_1065.png","F_25_1068.png","F_25_1067.png","F_25_1066.png","F_25_1069.png","F_25_1070.png","F_25_1071.png","F_25_1030.png","F_25_1031.png","F_25_45.png","F_25_43.png","F_25_46.png","F_25_44.png","F_25_58.png","F_25_39.png","F_25_34.png","F_25_97.png","F_25_98.png","F_25_99.png","F_25_100.png","F_25_101.png","F_25_102.png","F_25_103.png","F_25_104.png","F_25_105.png","F_25_106.png","F_25_107.png","F_25_108.png","F_25_109.png","F_25_110.png","F_25_111.png","F_25_112.png","F_25_113.png","F_25_114.png","F_25_115.png","F_25_116.png","F_25_117.png","F_25_118.png","F_25_119.png","F_25_120.png","F_25_121.png","F_25_122.png","F_25_1072.png","F_25_1073.png","F_25_1074.png","F_25_1075.png","F_25_1076.png","F_25_1077.png","F_25_1105.png","F_25_1078.png","F_25_1079.png","F_25_1080.png","F_25_1081.png","F_25_1082.png","F_25_1083.png","F_25_1084.png","F_25_1085.png","F_25_1086.png","F_25_1087.png","F_25_1088.png","F_25_1089.png","F_25_1090.png","F_25_1091.png","F_25_1092.png","F_25_1093.png","F_25_1094.png","F_25_1095.png","F_25_1096.png","F_25_1097.png","F_25_1100.png","F_25_1099.png","F_25_1098.png","F_25_1101.png","F_25_1102.png","F_25_1103.png","F_25_1110.png","F_25_1111.png"],
		  index: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯІЇ-+.,:'\"abcdefghijklmnopqrstuvwxyzабвгдеёжзийклмнопрстуфхцчшщьыъэюяії",
		  height: 33,
		  width: [33,33,33,33,33,33,33,33,33,33,19,19,18,20,18,17,19,21,10,15,19,16,25,21,20,18,20,18,17,16,20,19,25,18,17,17,19,18,19,15,20,18,18,26,15,21,21,18,20,25,21,20,21,18,18,16,15,21,18,20,19,26,26,18,24,17,18,27,18,10,10,13,13,9,9,9,8,11,19,19,16,19,18,12,19,20,10,10,18,10,28,20,18,19,19,15,15,12,20,17,24,17,18,16,19,18,17,16,21,18,18,24,15,19,19,18,19,23,19,18,19,19,16,16,18,21,17,19,18,26,27,16,23,17,16,25,17,10,10]
		}
		
		let fontDop={
			count: 17,
			path: "",
			files: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png",'A100_066d.png','A100_066sr.png','A100_066ss.png','A100_066b.png','A100_066p.png','A100_066bl.png','A100_066h.png'],
			index: '0123456789:udb%lh',
			height: 23,
			width: 21
		}

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
            function setLang(){
				const lang = DeviceRuntimeCore.HmUtils.getLanguage();
				if(lang=='en-US'){
					con_rest='Connection restored';
					con_lost='Connection lost';
					
					weekday=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
					weather_text=['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime'];
					moonphase=["New Moon","Waxing Crescent","First Quarter","Waxing Gibbous","Full Moon","Waning Gibbous","Last Quarter","Waning Crescent"];
					month_text=["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
					aod_text=["battery", "steps", "bpm"];
				}
				if(lang=='uk-UA'){
					weekday=["Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота", "Неділя"];
					weather_text=['Хмарно', 'Часом дощ', 'Часом сніг', 'Сонячно', 'Похмуро', 'Невеликий дощ', 'Невеликий сніг', 'Помірний дощ', 'Помірний сніг', 'Сильний сніг', 'Сильний дощ', 'Піщана буря', 'Дощ та сніг', 'Туман', 'Димка', 'Дощь з грозою', 'Хуртовина', 'Летючий пил', 'Злива', 'Дощ та град', 'Злива та град', 'Сильна злива', 'Пилова буря', 'Сильна піщана буря', 'Сильна злива', 'Невідомо', 'Хмарно вночі', 'Дощ вночі', 'Ясно вночі'];
					con_rest="З'єднання відновлено";
					con_lost="Зв'язок втрачено";	
					moonphase=["Молодик ","Зростаючий напівмісяць","Перша чверть","Зростаюча середня","Повний Місяць","Опадаюча середня","Остання чверть","Опадаючий напівмісяць"];										
					month_text=["Січня", "Лютого", "Березня", "Квітня", "Травня", "Червня", "Липня", "Серпня", "Вересня", "Жовтня", "Листопада", "Грудня"];
					aod_text=["заряд", "кроки", "пульс"];
				}
				if(lang=='ru-RU'){
					weekday=["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"];
					weather_text=['Облачно','Временами дождь','Временами снег','Солнечно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снег','Сильный дождь','Песчаная буря','Снег с дождем','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Ливень с градом','Сильный ливень','Пыльная буря','Сильная песчана буря','Сильный ливень','Не известно','Облачно ночью','Дождливо ночью','Ясная ночь'];
					con_rest='Соединение восстановлено';
					con_lost="Соединение потеряно";	
					moonphase=["Новолуние","Растущая луна","Первая четверть","Растущий полумесяц","Полнолуние","Убывающий полумесц","Последняя четверть","Убывающая луна"];					
					month_text=["Января","Февраля","Марта","Апреля","Мая","Июня","Июля","Августа","Сентября","Октября","Ноября","Декабря"];
					aod_text=["заряд","шаги","пульс"];
				}				
			}
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			curv_group=hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
//              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            idle_count_down_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 360,
	      w: 180,
              font_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              padding: false,
              h_space: 0,
              dot_image: 'A100_066d.png',
			invalid_image: 'A100_065.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_AOD,
			  alpha: 200,
            });

            idle_alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 300,
	      w: 180,
              font_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              padding: true,
              h_space: 0,
              dot_image: 'A100_066d.png',
			  invalid_image: 'A100_065.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
			  alpha: 200,
            });

            idle_stop_watch_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 330,
	      w: 180,
              font_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              padding: false,
              h_space: 0,
              dot_image: 'A100_066d.png',
			  invalid_image: 'A100_065.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_AOD,
			  alpha: 200,
            });
			
            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 58,//118,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,// 300,
              y: 331,//345,
              font_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 338,//348,
              y: 331,//345,
              image_array: ["wind_00.png","wind_01.png","wind_02.png","wind_03.png","wind_04.png","wind_05.png","wind_06.png","wind_07.png","y1.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,//122
              y: 331,//345
              font_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,//95,
              y: 327,//341,
              src: 'vl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0017.png',
              center_x: 233,
              center_y: 227,
              x: 17,
              y: 235,
              start_angle: 819,
              end_angle: 57,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 259,
              font_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 218,
              font_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 175,
              font_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
//			  cur_bpm=heart_rate.last;
			  animation_call()
            });
//			cur_bpm=heart_rate.last;

			
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
				show_all_arc_text();
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 353,//363
              font_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_079.png',
              unit_tc: 'A100_079.png',
              unit_en: 'A100_079.png',
              negative_image: 'A100_078.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 345, //355
              src: "weather_26.png",

              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

			normal_weather_text = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 70,
			  y: 292,
			  w: 328,
			  h: 45,
			  text_size: 30,
			  char_space: 0,
			  line_space: 0,
			  color: 0xFFFFFF,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.TOP,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});		
			
			normal_moon_text = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 70,
			  y: 151,
			  w: 328,
			  h: 25,
			  text_size: 18,
			  char_space: 0,
			  line_space: 0,
			  color: 0xFFFFFF,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.TOP,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});				
			
		
			function setWeatherText(){
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const weatherData = weatherSensor.getForecastWeather();

				const { forecastData, tideData } = weatherData;
				let time = hmSensor.createSensor(hmSensor.id.TIME);
				if(forecastData.count>0){

					const { index, high, low } = forecastData.data[0];
					normal_weather_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);//weather_text[index]);
					curv_weather_text=weather_text[index];
					
					
					
					var ct=time.hour*60+time.minute;
					let is_day=true;
					if(tideData.count>0){
						var sr = tideData.data[0].sunrise.hour*60+tideData.data[0].sunrise.minute;
						var ss = tideData.data[0].sunset.hour*60+tideData.data[0].sunset.minute;
						if(ct<sr || ct>ss) is_day=false;
					}
					var curimage=index+1;
					if(is_day){
						if(curimage==27) curimage=1;
						if(curimage==28) curimage=2;
						if(curimage==29) curimage=4;
					}else{
						if(curimage==1) curimage=27;
						if(curimage==2) curimage=28;
						if(curimage==4) curimage=29;
						if(curimage==3) curimage=30;
						if(curimage==16) curimage=31;
						if(curimage==17) curimage=32;
					}
					if(curimage<1 || curimage>30){
						curimage=26;
					}
					normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE,{
						src: "weather_"+curimage+".png"
					});
					curv_sun_set=(tideData.data[0].sunset.hour+'').padStart(2,'0')+' d '+(tideData.data[0].sunset.minute+'').padStart(2,'0');
					curv_sun_rise=(tideData.data[0].sunrise.hour+'').padStart(2,'0')+' u '+(tideData.data[0].sunrise.minute+'').padStart(2,'0');
				}	
				let moonBegin = 1613032380000;
				let moonMonth = 29.53059 * 24 * 60 * 60 * 1000;
				let now=new Date(time.year,time.month-1,time.day);
				let moonphaseday = ((now - moonBegin) %  moonMonth)/(moonMonth/30)|0;
				
				let phaseNumber=0;
				if(moonphaseday<29) phaseNumber=7;
				if(moonphaseday<22) phaseNumber=5;
				if(moonphaseday<15) phaseNumber=3;
				if(moonphaseday<8) phaseNumber=1;
				
				

				if(moonphaseday>28 || moonphaseday<2) phaseNumber=0;
				if(moonphaseday==7 || moonphaseday==8) phaseNumber=2;
				if(moonphaseday==14 || moonphaseday==15) phaseNumber=4;
				if(moonphaseday==21 || moonphaseday==22) phaseNumber=6;
				
				curv_moonphasetext=moonphase[phaseNumber];
			}
	

			
			normal_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,//62,//136,
              y: 130,//90,
			  w: 160,//190,
			  h:28,
			  color: 0xffffff,
			  text_size: 24,
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.BOTTOM,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_text_month = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,//136,
              y: 110,//90,
			  w: 150,//190,
			  h: 26,
			  color: 0xffffff,
			  text_size: 24,
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.BOTTOM,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
			
			time = hmSensor.createSensor(hmSensor.id.TIME);
			
			time.addEventListener(time.event.DAYCHANGE, function() {
				setTextData();
			});
			
			

			normal_date_text_date_day = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,//201,
              y: 102,//42,
			  w:71,
			  h:50,
			  color: 0xffffff,
			  text_size: 58,
			  align_h: hmUI.align.RIGHT,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
			function setTextData(){
				if(typeof normal_date_text_date_week !== 'string'){
					normal_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}
				if(typeof normal_date_text_month!== 'string'){
					normal_date_text_month.setProperty(hmUI.prop.TEXT,month_text[time.month-1]);
				}
				if(typeof idle_date_text_date_week !== 'string'){
					idle_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}
				if(typeof normal_date_text_date_day!=='string'){
					normal_date_text_date_day.setProperty(hmUI.prop.TEXT,(time.day+'').padStart(2,'0'));
				}
				if(typeof idle_date_text_date_day!=='string'){
					idle_date_text_date_day.setProperty(hmUI.prop.TEXT,(time.day+'').padStart(2,'0'));
				}				
			}
			
			normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			  hour_startX: 286,
			  hour_startY: 174,
			  hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
			  hour_zero: 1,
			  hour_space: 0,
			  hour_align: hmUI.align.RIGHT,

			  minute_startX: 286,
			  minute_startY: 232,
			  minute_array: ["A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png","A100_021.png"],
			  minute_zero: 1,
			  minute_space: 0,
			  minute_follow: 0,
			  minute_align: hmUI.align.RIGHT,

			  show_level: hmUI.show_level.ONLY_NORMAL,
			});		
			normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
			  hour_path: 'hour.png',
			  hour_centerX: 233,
			  hour_centerY: 233,
			  hour_posX: 17,
			  hour_posY: 150,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
			  minute_path: 'minuta.png',
			  minute_centerX: 233,
			  minute_centerY: 233,
			  minute_posX: 16,
			  minute_posY: 208,
			  minute_cover_path: 'pointer.png',
			  minute_cover_x: 214,
			  minute_cover_y: 215,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
			  second_path: 'second.png',
			  second_centerX: 233,
			  second_centerY: 233,
			  second_posX: 11,
			  second_posY: 230,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});				
			// переключатель стрелки
			normal_showhide_arrow=hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 200,
			  y: 200,
			  w: 66,
			  h: 66,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: (button_widget) => {
				showarrow=!showarrow;
				show_hide_arrow(showarrow);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});		


			normal_digital_clock_img_time1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			  hour_startX: 192,
			  hour_startY: 190,
			  hour_array: ["A103_002.png","A103_003.png","A103_004.png","A103_005.png","A103_006.png","A103_007.png","A103_008.png","A103_009.png","A103_010.png","A103_011.png"],
			  hour_zero: 1,
			  hour_space: -5,
			  hour_align: hmUI.align.RIGHT,

			  minute_startX: 301,
			  minute_startY: 193,
			  minute_array: ["A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png","A100_021.png"],
			  minute_zero: 1,
			  minute_space: -5,
			  minute_follow: 0,
			  minute_align: hmUI.align.RIGHT,

			  second_startX: 347,
			  second_startY: 249,
			  second_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
			  second_zero: 1,
			  second_space: -4,
			  second_follow: 0,
			  second_align: hmUI.align.RIGHT,

			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	
			// переключатель стрелки
			normal_showhide_arrow1=hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 203,
			  y: 186,
			  w: 100,
			  h: 100,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: (button_widget) => {
				showarrow=!showarrow;
				show_hide_arrow(showarrow);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	


            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 222,
              src: 'y3.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 181,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 264,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


/*            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });*/

/*            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 382,
              font_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 382,
              src: 'bt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });*/

			
			idle_date_text_date_day = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 201,
              y: 42,
			  w:65,
			  h:42,
			  color: 0xffffff,
			  text_size: 48,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
			  alpha: 200,
            });	
			
			idle_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 138,
              y: 90,
			  w: 190,
			  h: 28,
			  color: 0xffffff,
			  text_size: 24,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
			  alpha: 200,
            });			
			
			

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuta.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 16,
              minute_posY: 208,
              minute_cover_path: 'pointer.png',
              minute_cover_x: 214,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь потеряна!,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Связь восстановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: con_lost});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: con_rest});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 249,
              w: 53,
              h: 49,
              src: 'A100_090.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 350,
              w: 242,
              h: 49,
              src: 'A100_090.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 168,
              w: 117,
              h: 44,
              src: 'A100_090.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 233,
              w: 97,
              h: 64,
              src: 'A100_090.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 168,
              w: 97,
              h: 64,
              src: 'A100_090.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 405,
              w: 239,
              h: 97,
              src: 'A100_090.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 259,
              w: 117,
              h: 46,
              src: 'A100_090.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 213,
              w: 156,
              h: 46,
              src: 'A100_090.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



//			let anim_sz=10;
			
			
			function animation_call(){
				if(typeof normal_anim_h !== 'string'){
					hmUI.deleteWidget(normal_anim_h);
				}	
							
				if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
					
/*					if(!isNaN(cur_bpm) && cur_bpm>10){
						anim_sz=Math.ceil(30/(cur_bpm/60));
					}else{
						anim_sz=20;
					}*/

					normal_anim_h = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						  anim_path: 'animation',
						  anim_prefix: 'heart',
						  anim_ext: 'png',
//						  anim_fps: Math.ceil(cur_bpm/10),//6,//30,
						  anim_fps:Math.ceil(heart_rate.last/10),
						  repeat_count: 0,
						  anim_size: 6,//anim_sz,
						  anim_status: hmUI.anim_status.START,
						  anim_repeat: true,
						  x: 45,//0,
						  y: 173,//0,
						  show_level: hmUI.show_level.ONLY_NORMAL,
						});	
					
				}else{
					
				}
			}

            function scale_call() {
				
				

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 41;
                  let start_y_normal_calorie = 291;
                  let lenght_ls_normal_calorie = 160;
                  let line_width_ls_normal_calorie = 5;
                  let color_ls_normal_calorie = 0xFFD17F1B;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 41;
                  let start_y_normal_step = 250;
                  let lenght_ls_normal_step = 160;
                  let line_width_ls_normal_step = 5;
                  let color_ls_normal_step = 0xFF00C364;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });

                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 41;
                  let start_y_normal_heart_rate = 207;
                  let lenght_ls_normal_heart_rate = 160;
                  let line_width_ls_normal_heart_rate = 5;
                  let color_ls_normal_heart_rate = 0xFFE74448;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };
				

            };
			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 105,
              w: 200,
              h: 55,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});				
			// восход закат
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 28,
              y: 31,
              w: 100,
              h: 100,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: () => {
				hmApp.startApp({ url: 'TideScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});		
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 31,
              w: 100,
              h: 100,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: () => {
				hmApp.startApp({ url: 'TideScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});		
			
			// поиск телефона
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 386,
              y: 169,
              w: 50,
              h: 45,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: () => {
				hmApp.startApp({ url: 'FindPhoneScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});			

			// низкий заряд
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 340,
              w: 100,
              h: 100,
			  text: '',
			  normal_src: 'A100_090.png',
			  press_src: 'A100_090.png',
			  click_func: () => {
				hmApp.startApp({ url: 'LowBatteryScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});				

			
			
			function show_hide_arrow(vis){
				if(vis){
					normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true); 
					normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true); 
					normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true); 
					normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true); 
					normal_showhide_arrow.setProperty(hmUI.prop.VISIBLE, true); 
					normal_digital_clock_img_time1.setProperty(hmUI.prop.VISIBLE, false);
					normal_showhide_arrow1.setProperty(hmUI.prop.VISIBLE, false);
				}else{
					normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false); 
					normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false); 
					normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
					normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);	
					normal_showhide_arrow.setProperty(hmUI.prop.VISIBLE, false); 	
					normal_digital_clock_img_time1.setProperty(hmUI.prop.VISIBLE, true);
					normal_showhide_arrow1.setProperty(hmUI.prop.VISIBLE, true);					
				}
				

			}
			function show_all_arc_text(){
				// общая функция для вывода всех надписей вдоль окружности
				curv_groupi.forEach(function (widget) { // удаление старых надписей перед пересивкой
					if(widget){
						hmUI.deleteWidget(widget);
					}					
				});
				curv_groupi=[];
				curv_batt=(battery.current>15?'b':'l')+battery.current+'%';
				if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
					show_arc_text(curv_sun_set,fontDop,233,233,215,300,30,-1,true);
					show_arc_text(curv_sun_rise,fontDop,233,233,215,210,30,-1,true);
					
					
					show_arc_text(curv_batt,fontDop,233,233,215,60,30,-1,false,hmUI.show_level.ONLY_NORMAL);

	//				curv_weather_text="Зараз дуже хмарно і дощ";
					show_arc_text(curv_weather_text,font25,233,150,248,160,140,-0.5,false);
					
					show_arc_text(curv_moonphasetext,font18,233,233,190,210,120,0,true);				

				}else{
					show_arc_text(curv_batt,fontDop,233,233,213,60,30,-0.5,false, hmUI.show_level.ONAL_AOD,220);
					show_arc_text(aod_text[0],font18,233,233,187,60,30,-0.5,false, hmUI.show_level.ONAL_AOD,220);
				
					const step = hmSensor.createSensor(hmSensor.id.STEP)
					show_arc_text(step.current+'',fontDop,233,233,213,150,30,-0.5,false,hmUI.show_level.ONAL_AOD,220);
					show_arc_text(aod_text[1],font18,233,233,187,150,30,-0.5,false,hmUI.show_level.ONAL_AOD,220);
					
					
//					if(!isNaN(cur_bpm) && cur_bpm>10){
					if(!isNaN(heart_rate.last) && heart_rate.last>10){	
						let hr='h'+heart_rate.last;
						show_arc_text(hr,fontDop,233,233,213,210,30,-0.5,true,hmUI.show_level.ONLY_AOD,220);
						show_arc_text(aod_text[2],font18,233,233,187,210,30,-0.5,true,hmUI.show_level.ONAL_AOD,220);
					}
				}

			}
			
			function show_arc_text(str,font,center_x,center_y,radius,begin_angle,width_angle,compress,clockwise,show_level,alpha){
				
			/*
				str - отрисовываемая строка
				ПРОБЕЛ в str соответсвует 1/3 ширины изображения (img_w). Если нужен полный "пропуск" ставим 3 пробела
				font - 	шрифт
				center_x,center_y - центр окружности вдоль которой присходит отрисовка
				radius - радиус окружности
				begin_angle - начальный угол
				width_angle - количество градусов до завершения, дальше обрезается
				compress - сжимать текст или раздвигать ("-Х" сжимает, "Х" раздвигает, "0" - ничего не делает
				clockwise - отображение по часовой стрелке (true|false)
				show_level - AOD, NORMAL и др. (hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD)
				alpha: прозрачность
			*/
				
				compress=compress?compress:0;
				clockwise=(typeof clockwise == "boolean")?clockwise:true;
				show_level=show_level?show_level:hmUI.show_level.ONLY_NORMAL;
				alpha=alpha?alpha:255;
				
				let scrtype=hmSetting.getScreenType();
				if(show_level != scrtype && show_level != (hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD)){
//					return;
				}
				
				// расчет начала отрисовки если установлн не 0 width_angle
				if(width_angle!==0){
					let pw=0;
					let pl=0;
					for(var i=0;i<str.length;i++){
						let tw=0;
						let tw_=0;
						if(Array.isArray(font.width)){
							tw=font.width[font.index.indexOf(str[i])];
							tw_=font.width[0]/3;
						}else{
							tw=font.width;
							tw_=font.width/3;
						}
						let newa = 90-Math.atan(radius/tw)*180/Math.PI+(i<str.length-1?compress:0);
						if(str[i]==' '){
							newa = 90-Math.atan(radius/tw_)*180/Math.PI;
						}
						if(pw+newa+(i<str.length-1?compress:0)<width_angle){
							pw+=newa;
							pl++;
						}else{
							break;
						}
					}
					if(clockwise) begin_angle+=(width_angle-pw)/2;
					else begin_angle-=(width_angle-pw)/2;
					str=str.substring(0,pl);
				}
				// конец расчета с установленным width_angle не равным 0
				
				
				let ln=str.length;
				let curangle=begin_angle;
				let tw=0;
				let th=0;

				// расчет сдвига первого символа
				if(Array.isArray(font.width)){
					tw=font.width[font.index.indexOf(str[0])];
					th=font.height;
				}else{
					tw=font.width;
					th=font.height;						
				}
				if(clockwise) curangle+=90-Math.atan(radius/(tw/2.5))*180/Math.PI;
				else curangle-=90-Math.atan(radius/(tw/2.5))*180/Math.PI;

				for(var i=0;i<ln;i++){
					let twn=0;
					let img='';
					let indx=font.index.indexOf(str[i]);
					if(Array.isArray(font.width)){
						if(indx==-1){
							tw=font.width[0]
						}else{
							tw=font.width[indx];
						}
						if(i+1<ln){
							if(str[i+1]==' '){
								twn=font.width[0]/3;
							}else{
								twn=font.width[font.index.indexOf(str[i+1])];
							}
						}
					}else{
						tw=font.width;
						if(i+1<ln){
							if(str[i+1]==' '){
								twn=tw/3;
							}else{
								twn=tw;
							}
						}							
					}
					img=font.path+font.files[indx];

					let newa = 90-Math.atan(radius/((tw+twn)/2))*180/Math.PI;
					if(str[i]!=' '){
						let rangle=clockwise?90:270;
						let fw=Math.sqrt(tw*tw+th*th);
						x=radius*Math.cos(curangle* Math.PI / 180)+center_x-/*Math.round*/(fw/2);
						y=radius*Math.sin(curangle* Math.PI / 180)+center_y-/*Math.round*/(fw/2);	
						if(img.length>0){
							curv_groupi.push(curv_group.createWidget(hmUI.widget.IMG,{
								x: x,
								y: y,
								w: fw,
								h: fw,
								src: img,
								angle: Math.abs(curangle)+rangle,
								center_x: fw/2,
								center_y: fw/2,
								pos_x: (fw-tw)/2,
								pos_y: (fw-th)/2,
								show_level: show_level,
								alpha: alpha,
							}));
						}
	/*					curv_groupi.push(hmUI.createWidget(hmUI.widget.STROKE_RECT, {
						  x: x,
						  y: y,
						  w: fw,
						  h: fw,
						  color: 0xFF0000,
						}));
						curv_groupi.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
						  x: x+fw/2-1,
						  y: y+fw/2-1,
						  w: 3,
						  h: 3,
						  color: 0x00FF00,
						}));*/	
					}						
					if(clockwise){
						curangle+=newa+compress;
					}else{
						curangle-=newa+compress;
					}

				}
			}
			
			
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
				animation_call();
                checkConnection();
                stopVibro();
//				showarrow=true;
				show_hide_arrow(showarrow);
				setLang();
				setTextData();
				setWeatherText();
				show_all_arc_text();
              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}