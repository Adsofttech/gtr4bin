﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 391,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'x%.png',
              unit_tc: 'x%.png',
              unit_en: 'x%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 391,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 391,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 393,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 348,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 350,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 348,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Sep.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 349,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 348,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 349,
              src: 'Pasos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 61,
              image_array: ["moon_0.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 57,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 60,
              src: 'UV.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 91,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'x%.png',
              unit_tc: 'x%.png',
              unit_en: 'x%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 97,
              src: 'HU.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 223,
              y: 82,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 303,
              month_startY: 51,
              month_sc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_tc_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_en_array: ["M1.png","M10.png","M11.png","M12.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 272,
              day_startY: 57,
              day_sc_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_tc_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_en_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 141,
              y: 424,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 16,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'white_small_du.png',
              unit_tc: 'white_small_du.png',
              unit_en: 'white_small_du.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 8,
              image_array: ["c41.png","c42.png","c43.png","c44.png","c45.png","c46.png","c47.png","c48.png","c49.png","c50.png","c51.png","c52.png","c53.png","c54.png","c55.png","c56.png","c57.png","c58.png","c59.png","c60.png","c61.png","c62.png","c63.png","c64.png","c65.png","c66.png","c67.png","c68.png","c69.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 242,
              src: 'candado.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 248,
              src: '0069.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 29,
              y: 192,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 416,
              y: 247,
              src: '0067.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 396,
              am_y: 218,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 396,
              pm_y: 218,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 174,
              hour_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 174,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 399,
              second_startY: 189,
              second_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 184,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 178,
              w: 50,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 413,
              y: 241,
              w: 50,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 61,
              w: 100,
              h: 70,
              src: 'transparent.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 9,
              w: 120,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 391,
              w: 100,
              h: 40,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 339,
              w: 130,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 391,
              font_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'x%.png',
              unit_tc: 'x%.png',
              unit_en: 'x%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 391,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 223,
              y: 82,
              week_en: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_tc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              week_sc: ["dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png","dia7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 272,
              day_startY: 57,
              day_sc_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_tc_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_en_array: ["PEQ0.png","PEQ1.png","PEQ2.png","PEQ3.png","PEQ4.png","PEQ5.png","PEQ6.png","PEQ7.png","PEQ8.png","PEQ9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 242,
              src: 'candado.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 248,
              src: '0069.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 29,
              y: 192,
              src: 'BT3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 416,
              y: 247,
              src: '0067.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 396,
              am_y: 218,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 396,
              pm_y: 218,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 174,
              hour_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 174,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 184,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
