﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */
// Experimental 466 custom version for GTR4

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
		let MainTimer= null;
		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let Pendulum;
		
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''		
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''		
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_wind_icon_img = ''
        let normal_wind_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''

        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''		
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_icon_img = ''
        let idle_humidity_image_progress_img_level = ''
        let idle_wind_icon_img = ''
        let idle_wind_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''		
		let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''

		let animate;
		let animate2;		
		let Xsecond;
		let heart = hmSensor.createSensor(hmSensor.id.HEART)
		let nFramesP=0;
		let nTypeGlare=0;
		let nPrevMin=-1;
		let nFrameSpark=0;

	function PaintMain(){ // Called every 10msec
		let mod=heart.last;
		if(mod>160) mod=160;
		if(mod<30) mod=30;
		let HR=mod;
		let img='PenduloGold.png';
		if(HR>100) img='PenduloGoldB.png';
		if(HR>130) img='PenduloGoldR.png';
		mod=(mod/2)*1000/60;
		mod=mod*mod;
		let maxval=(160/2)*1000/60;
		maxval=maxval*maxval;
		let a=(now.utc % 1000)/1000; // 0.0.9999
		a=180+Math.sin(a*2*Math.PI)*(120*(mod/maxval)); 

		if(nFramesP==0)	{
			if((now.utc % 67) ==0){
				nFramesP=1;
				nTypeGlare=(now.utc % 6) + 1;
				}
			}
		else{
			if(img=='PenduloGold.png') img='PenduloGoldG' + parseInt(nTypeGlare) + '.png';
			nFramesP=nFramesP-1;
		}
		// melopinte 8-)
		if(nFrameSpark>0) img='Spark' + parseInt(nFrameSpark) + '.png';
		Pendulum.setProperty(hmUI.prop.MORE, {
		  src: img,
		  center_x: 233,
		  center_y: 233,
		  pos_x: 233-68,
		  pos_y: 0,
		  x:0,
		  y:0,
		  w:466,
		  h:466,
		  angle:a,
		  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		if(nFrameSpark>0){
			nFrameSpark=nFrameSpark+1;
			if(nFrameSpark==24) nFrameSpark=0;	
		}
		if(now.minute!=nPrevMin){
			   animate2.setProperty(hmUI.prop.VISIBLE, true);
               animate2.setProperty(hmUI.prop.MORE, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "Thunder",
                    anim_ext: "png",
                    anim_fps: 20,
                    anim_size: 23,
                    anim_repeat: false,
                    repeat_count: 1,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
			   nFrameSpark=1;
		}
		nPrevMin=now.minute;
	}
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
            let screenType = hmSetting.getScreenType();
			
	        // animate
            if (screenType != hmSetting.screen_type.AOD) {
               animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "Gears",
                    anim_ext: "png",
                    anim_fps: 20,
                    anim_size: 30,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
               animate2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "Thunder",
                    anim_ext: "png",
                    anim_fps: 20,
                    anim_size: 23,
                    anim_repeat: false,
                    repeat_count: 1,
                    anim_status: hmUI.anim_status.STOP,
                    display_on_restart: false,
	           });
			   animate2.setProperty(hmUI.prop.VISIBLE, false);
  
       	    }  
			
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fongdo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			Pendulum= hmUI.createWidget(hmUI.widget.IMG, {
			  src: 'PenduloGold.png',
              center_x: 233,
              center_y: 233,
              pos_x: 233-68,
              pos_y: 0,
			  x:0,
			  y:0,
			  w:466,
			  h:466,
			  angle:0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 169,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'SNKm.png',
              unit_tc: 'SNKm.png',
              unit_en: 'SNKm.png',
              dot_image: 'SNDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 268,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 264,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 366,
              month_startY: 262,
              month_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 262,
              day_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: 'SNMinus.png',
              day_unit_tc: 'SNMinus.png',
              day_unit_en: 'SNMinus.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 315,
              y: 214,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 217,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 96,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 110,
              src: 'Humedad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 126,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 110,
              src: 'Wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 126,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 164,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'digital3_3Deg.png',
              unit_tc: 'digital3_3Deg.png',
              unit_en: 'digital3_3Deg.png',
              negative_image: 'SNMinus.png',
              invalid_image: 'SNMinus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 78,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 16,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 30,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 14,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 29,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 62,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 63,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'GHour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 18,
              hour_posY: 121,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'GMinute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'GSecond.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fongdo3.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 169,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'SNKm.png',
              unit_tc: 'SNKm.png',
              unit_en: 'SNKm.png',
              dot_image: 'SNDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 268,
              src: 'heart.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 264,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 366,
              month_startY: 262,
              month_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 262,
              day_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: 'SNMinus.png',
              day_unit_tc: 'SNMinus.png',
              day_unit_en: 'SNMinus.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 315,
              y: 214,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 217,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 96,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 110,
              src: 'Humedad.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 126,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 110,
              src: 'Wind.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 126,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 164,
              font_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'digital3_3Deg.png',
              unit_tc: 'digital3_3Deg.png',
              unit_en: 'digital3_3Deg.png',
              negative_image: 'SNMinus.png',
              invalid_image: 'SNMinus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 78,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 16,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 30,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 14,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 29,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 62,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 63,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });
			
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'GHour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 18,
              hour_posY: 121,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'GMinute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 17,
              minute_posY: 209,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'GSecond.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 22,
              second_posY: 230,
              show_level: hmUI.show_level.ONAL_AOD,
            });





			MainTimer = timer.createTimer(20, 20, PaintMain, {}); 
				
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				animate2.setProperty(hmUI.prop.VISIBLE, false);
				nPrevMin=now.minute; // Avoid anim on resume screen. Thunders are for minute change on display only.
				PaintMain();
				if(MainTimer==null) MainTimer = timer.createTimer(20, 20, PaintMain, {}); // Watchface timer
              }),
			  pause_call: (function () {
				animate2.setProperty(hmUI.prop.VISIBLE, false);
				timer.stopTimer(MainTimer);
				MainTimer=null;
             }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
  			if(MainTimer) timer.stopTimer(MainTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  