﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        let Escala_img = ''
        let MinutosBar_img = ''
        let DIG1_img = ''
        let DIG2_img = ''
		
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
		
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''

		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let hsTimer=null;
		let lastMin=-1;
		let lastSec=-1;
		
        //dynamic modify end

	// Returns RGB string in the form: '0xFFRRGGBB'
	function CalcRGB(R,G,B){
		let cR='0xFF';
		let temp='0'+Math.floor(R).toString(16).toUpperCase();
		cR=cR+temp.substring(temp.length-2);		
		temp='0'+Math.floor(G).toString(16).toUpperCase();
		cR=cR+temp.substring(temp.length-2);		
		temp='0'+Math.floor(B).toString(16).toUpperCase();
		cR=cR+temp.substring(temp.length-2);
		return cR;
	}
	
    function PaintData() {
		let s = now.second;
		let h = now.hour;
		let m = now.minute;	
			
		let MINY=28;
		let MAXY=448;
		let HY=(MAXY-MINY)/60; // Espacio para cada escalon en pixels
		let HX=24; // Anchura de la barra
		let POSX=183+((100-HX)/2); // Posicion en X de la barra centrada
		
		if(m!=lastMin) 
		{
			lastMin=m;
			// Parece ser que se aprecia mejor si ocultamos la parte que no hay que resaltar
			/*
            MinutosBar_img.setProperty(hmUI.prop.MORE, {
              x: POSX,
              y: MINY,
              w: HX,
              h: (60-m)*HY,
              color: CalcRGB(255,0,0),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			*/
            MinutosBar_img.setProperty(hmUI.prop.MORE, {
              x: POSX,
              y: MINY+((60-m)*HY),
              w: HX,
              h: HY*m,
              color: CalcRGB(255,0,0),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}
		if(s!=lastSec) 
		{
			lastSec=s;
			let d1=0;
			let d2=0;
			// Pintar Horas o minutos, segun los segundos sean par o impar
            if(s%2==0)
			{
				//horas
				d1=parseInt(h/10);
				d2=h % 10;
				DIG1_img.setProperty(hmUI.prop.MORE, {
				  x: 60,
				  y: 98,
				  src: 'NG' + d1 + '.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				DIG2_img.setProperty(hmUI.prop.MORE, {
				  x: 60+120+100,
				  y: 98,
				  src: 'NG' + d2 + '.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
			}
			else
			{
				//minutos
				d1=parseInt(m/10);
				d2=m % 10;
				DIG1_img.setProperty(hmUI.prop.MORE, {
				  x: 60,
				  y: 98,
				  src: 'NNG' + d1 + '.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				DIG2_img.setProperty(hmUI.prop.MORE, {
				  x: 60+120+100,
				  y: 98,
				  src: 'NNG' + d2 + '.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
			}
		}
 	}

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BackGround.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 370,
              month_sc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_tc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_en_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 370,
              day_sc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_tc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_en_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'WLCDSmDot.png',
              day_unit_tc: 'WLCDSmDot.png',
              day_unit_en: 'WLCDSmDot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 114,
              y: 402,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 6,
              y: 176,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 175,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 225,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 144,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 199,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 297,
              second_startY: 371,
              second_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 48,
              font_array: ["PersSm0.png","PersSm1.png","PersSm2.png","PersSm3.png","PersSm4.png","PersSm5.png","PersSm6.png","PersSm7.png","PersSm8.png","PersSm9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'SmSilverNDeg.png',
              unit_tc: 'SmSilverNDeg.png',
              unit_en: 'SmSilverNDeg.png',
              negative_image: 'PersSmM.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 20,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            MinutosBar_img = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 183+20,
              y: 460,
              w: 0,
              h: 0,
              color: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Escala_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 20,
              src: 'Scale60.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            DIG1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 98,
              src: 'NG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            DIG2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60+120+100,
              y: 98,
              src: 'NG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			hsTimer = timer.createTimer(50, 50, PaintData, {})

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'BackGround.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 370,
              month_sc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_tc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_en_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 370,
              day_sc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_tc_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_en_array: ["WLCDSm0.png","WLCDSm1.png","WLCDSm2.png","WLCDSm3.png","WLCDSm4.png","WLCDSm5.png","WLCDSm6.png","WLCDSm7.png","WLCDSm8.png","WLCDSm9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'WLCDSmDot.png',
              day_unit_tc: 'WLCDSmDot.png',
              day_unit_en: 'WLCDSmDot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 114,
              y: 402,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 6,
              y: 176,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 175,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 225,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 144,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 199,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 49,
              hour_startY: 97,
              hour_array: ["LNG0.png","LNG1.png","LNG2.png","LNG3.png","LNG4.png","LNG5.png","LNG6.png","LNG7.png","LNG8.png","LNG9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 97,
              minute_array: ["LNG0.png","LNG1.png","LNG2.png","LNG3.png","LNG4.png","LNG5.png","LNG6.png","LNG7.png","LNG8.png","LNG9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 297,
              second_startY: 371,
              second_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 48,
              font_array: ["PersSm0.png","PersSm1.png","PersSm2.png","PersSm3.png","PersSm4.png","PersSm5.png","PersSm6.png","PersSm7.png","PersSm8.png","PersSm9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'SmSilverNDeg.png',
              unit_tc: 'SmSilverNDeg.png',
              unit_en: 'SmSilverNDeg.png',
              negative_image: 'PersSmM.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 20,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
					if(!hsTimer) hsTimer = timer.createTimer(50, 50, PaintData, {})
               }),
              pause_call: (function () {
			  		if(hsTimer) timer.stopTimer(hsTimer);
					hsTimer=null;
             }),			  
            });
                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
			  	if(hsTimer) timer.stopTimer(hsTimer);
				hsTimer=null;					
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}