﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_pai_linear_scale = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''


		let normal_background_bg_img = ''
		let normal_widget_togle_color = ''
		let bg_color_cur = 0
		//let bg_color = ['0xFFCFF0F3','0xFFA9ADA8','0xFF00EACD','0xFFA4F780','0xFFF3E016']
		let bg_color = [0x4bd9da, 0xbfff03, 0x00bef0, 0xeb212d, 0xff7800, 0xffd700, 0x37ffc8, 0x088683, 0xff3859, 0x7438ff, 0x38ff38, 0xff38c4, 0x3883ff, 0xffffff, 0x0538f8, 0x999999];
		let dist_pai_kal_button_block = ''
		let ta_cur = 0
		const lang = DeviceRuntimeCore.HmUtils.getLanguage()
		let sr_ss= 'us_sr_ss.png';
		let bpm = 'us_bpm.png';
		let weekday=["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"];
		let month=["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"];
		let steps='us_steps.png';
		let dist='icon_distance.png';
		let calor='icon_calories.png';
		
		if(lang=='uk-UA'){
			sr_ss='ua_sr_ss.png';
			bpm = 'ua_bpm.png';
			weekday=["weekday_ua_01.png","weekday_ua_02.png","weekday_ua_03.png","weekday_ua_04.png","weekday_ua_05.png","weekday_ua_06.png","weekday_ua_07.png"];
			month=["Month_ua_01.png","Month_ua_02.png","Month_ua_03.png","Month_ua_04.png","Month_ua_05.png","Month_ua_06.png","Month_ua_07.png","Month_ua_08.png","Month_ua_09.png","Month_ua_10.png","Month_ua_11.png","Month_ua_12.png"];
			steps='ua_steps.png';
			dist='icon_distance_ua.png';
			calor='icon_calories_ua.png';
		}
		if(lang=='ru-RU'){
			sr_ss='ru_sr_ss.png';
			bpm = 'ua_bpm.png';
			weekday=["weekday_ua_01.png","weekday_ua_02.png","weekday_ua_03.png","weekday_ua_04.png","weekday_ua_05.png","weekday_ua_06.png","weekday_ru_07.png"];
			month=["Month_ru_01.png","Month_ru_02.png","Month_ru_03.png","Month_ru_04.png","Month_ru_05.png","Month_ru_06.png","Month_ru_07.png","Month_ru_08.png","Month_ru_09.png","Month_ru_10.png","Month_ru_11.png","Month_ru_12.png"];
			steps='ru_steps.png';
			dist='icon_distance_ua.png';
			calor='icon_calories_ua.png';
		}		

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFCFF0F3',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			// перенести после создания
			let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
			  normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
			  normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };
			// добавить после создания
			normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 85,
              // start_y: 126,
              // color: 0xFF7F7F7F,
              // lenght: 333,
              // line_width: 17,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 340,
              font_array: ["DOWN_W_DISTANCE_Numb_00.png","DOWN_W_DISTANCE_Numb_01.png","DOWN_W_DISTANCE_Numb_02.png","DOWN_W_DISTANCE_Numb_03.png","DOWN_W_DISTANCE_Numb_04.png","DOWN_W_DISTANCE_Numb_05.png","DOWN_W_DISTANCE_Numb_06.png","DOWN_W_DISTANCE_Numb_07.png","DOWN_W_DISTANCE_Numb_08.png","DOWN_W_DISTANCE_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 334,
              src: 'icon_PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 85,
              // start_y: 126,
              // color: 0xFF7F7F7F,
              // lenght: 333,
              // line_width: 17,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 339,
              font_array: ["DOWN_W_Numb_00.png","DOWN_W_Numb_01.png","DOWN_W_Numb_02.png","DOWN_W_Numb_03.png","DOWN_W_Numb_04.png","DOWN_W_Numb_05.png","DOWN_W_Numb_06.png","DOWN_W_Numb_07.png","DOWN_W_Numb_08.png","DOWN_W_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 261,
              y: 334,
              src: 'icon_calories_ua.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 341,
              font_array: ["DOWN_W_DISTANCE_Numb_00.png","DOWN_W_DISTANCE_Numb_01.png","DOWN_W_DISTANCE_Numb_02.png","DOWN_W_DISTANCE_Numb_03.png","DOWN_W_DISTANCE_Numb_04.png","DOWN_W_DISTANCE_Numb_05.png","DOWN_W_DISTANCE_Numb_06.png","DOWN_W_DISTANCE_Numb_07.png","DOWN_W_DISTANCE_Numb_08.png","DOWN_W_DISTANCE_Numb_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'DOWN_W_DISTANCE_Numb_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 261,
              y: 334,
              src: 'icon_distance_ua.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 223,
              src: 'icon_bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 91,
              src: 'ua_sr_ss.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 61,
              font_array: ["UP_SRSS_Numb_00.png","UP_SRSS_Numb_01.png","UP_SRSS_Numb_02.png","UP_SRSS_Numb_03.png","UP_SRSS_Numb_04.png","UP_SRSS_Numb_05.png","UP_SRSS_Numb_06.png","UP_SRSS_Numb_07.png","UP_SRSS_Numb_08.png","UP_SRSS_Numb_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'UP_SRSS_Numb_column.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 91,
              src: 'ua_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 61,
              font_array: ["UP_SRSS_Numb_00.png","UP_SRSS_Numb_01.png","UP_SRSS_Numb_02.png","UP_SRSS_Numb_03.png","UP_SRSS_Numb_04.png","UP_SRSS_Numb_05.png","UP_SRSS_Numb_06.png","UP_SRSS_Numb_07.png","UP_SRSS_Numb_08.png","UP_SRSS_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 190,
              font_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'icon_percent.png',
              unit_tc: 'icon_percent.png',
              unit_en: 'icon_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 162,
              image_array: ["0002.png","0003.png","0004.png","0005.png","0006.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 372,
              src: 'ua_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };*/

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 85,
              // start_y: 126,
              // color: 0xFF7F7F7F,
              // lenght: 333,
              // line_width: 17,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 341,
              font_array: ["DOWN_W_DISTANCE_Numb_00.png","DOWN_W_DISTANCE_Numb_01.png","DOWN_W_DISTANCE_Numb_02.png","DOWN_W_DISTANCE_Numb_03.png","DOWN_W_DISTANCE_Numb_04.png","DOWN_W_DISTANCE_Numb_05.png","DOWN_W_DISTANCE_Numb_06.png","DOWN_W_DISTANCE_Numb_07.png","DOWN_W_DISTANCE_Numb_08.png","DOWN_W_DISTANCE_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 156,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 183,
              week_en: ["weekday_ua_01.png","weekday_ua_02.png","weekday_ua_03.png","weekday_ua_04.png","weekday_ua_05.png","weekday_ua_06.png","weekday_ua_07.png"],
              week_tc: ["weekday_ua_01.png","weekday_ua_02.png","weekday_ua_03.png","weekday_ua_04.png","weekday_ua_05.png","weekday_ua_06.png","weekday_ua_07.png"],
              week_sc: ["weekday_ua_01.png","weekday_ua_02.png","weekday_ua_03.png","weekday_ua_04.png","weekday_ua_05.png","weekday_ua_06.png","weekday_ua_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 131,
              month_startY: 153,
              month_sc_array: ["Month_ua_01.png","Month_ua_02.png","Month_ua_03.png","Month_ua_04.png","Month_ua_05.png","Month_ua_06.png","Month_ua_07.png","Month_ua_08.png","Month_ua_09.png","Month_ua_10.png","Month_ua_11.png","Month_ua_12.png"],
              month_tc_array: ["Month_ua_01.png","Month_ua_02.png","Month_ua_03.png","Month_ua_04.png","Month_ua_05.png","Month_ua_06.png","Month_ua_07.png","Month_ua_08.png","Month_ua_09.png","Month_ua_10.png","Month_ua_11.png","Month_ua_12.png"],
              month_en_array: ["Month_ua_01.png","Month_ua_02.png","Month_ua_03.png","Month_ua_04.png","Month_ua_05.png","Month_ua_06.png","Month_ua_07.png","Month_ua_08.png","Month_ua_09.png","Month_ua_10.png","Month_ua_11.png","Month_ua_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 365,
              month_startY: 168,
              month_sc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_tc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_en_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: 168,
              day_sc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_tc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_en_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 419,
              font_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png"],
              padding: false,
              h_space: 0,
              negative_image: 'battery_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 412,
              image_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 49,
              am_y: 244,
              am_sc_path: 'icon_AM.png',
              am_en_path: 'icon_AM.png',
              pm_x: 49,
              pm_y: 244,
              pm_sc_path: 'icon_AM.png',
              pm_en_path: 'icon_AM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 233,
              hour_array: ["B_Numb_00.png","B_Numb_01.png","B_Numb_02.png","B_Numb_03.png","B_Numb_04.png","B_Numb_05.png","B_Numb_06.png","B_Numb_07.png","B_Numb_08.png","B_Numb_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 237,
              minute_startY: 233,
              minute_array: ["B_Numb_00.png","B_Numb_01.png","B_Numb_02.png","B_Numb_03.png","B_Numb_04.png","B_Numb_05.png","B_Numb_06.png","B_Numb_07.png","B_Numb_08.png","B_Numb_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 361,
              second_startY: 279,
              second_array: ["L_Numb_00.png","L_Numb_01.png","L_Numb_02.png","L_Numb_03.png","L_Numb_04.png","L_Numb_05.png","L_Numb_06.png","L_Numb_07.png","L_Numb_08.png","L_Numb_09.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AOD_BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 401,
              src: 'icon_bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 84,
              hour_startY: 232,
              hour_array: ["AOD_B_Numb_00.png","AOD_B_Numb_01.png","AOD_B_Numb_02.png","AOD_B_Numb_03.png","AOD_B_Numb_04.png","AOD_B_Numb_05.png","AOD_B_Numb_06.png","AOD_B_Numb_07.png","AOD_B_Numb_08.png","AOD_B_Numb_09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 232,
              minute_array: ["AOD_B_Numb_00.png","AOD_B_Numb_01.png","AOD_B_Numb_02.png","AOD_B_Numb_03.png","AOD_B_Numb_04.png","AOD_B_Numb_05.png","AOD_B_Numb_06.png","AOD_B_Numb_07.png","AOD_B_Numb_08.png","AOD_B_Numb_09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 225,
              w: 50,
              h: 95,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 56,
              w: 103,
              h: 60,
              src: 'click_e.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 426,
              y: 151,
              w: 100,
              h: 172,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 56,
              w: 100,
              h: 60,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 335,
              w: 120,
              h: 62,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 225,
              w: 101,
              h: 95,
              src: 'click_e.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 225,
              w: 101,
              h: 95,
              src: 'click_e.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 85;
                  let start_y_normal_pai = 126;
                  let lenght_ls_normal_pai = 333;
                  let line_width_ls_normal_pai = 17;
                  let color_ls_normal_pai = 0xFF7F7F7F;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = lenght_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = line_width_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    lenght_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_x_normal_pai_draw = start_x_normal_pai - lenght_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 85;
                  let start_y_normal_calorie = 126;
                  let lenght_ls_normal_calorie = 333;
                  let line_width_ls_normal_calorie = 17;
                  let color_ls_normal_calorie = 0xFF7F7F7F;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 85;
                  let start_y_normal_step = 126;
                  let lenght_ls_normal_step = 333;
                  let line_width_ls_normal_step = 17;
                  let color_ls_normal_step = 0xFF7F7F7F;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

           function toggleColor() {
				bg_color_cur = (bg_color_cur + 1) % bg_color.length;
				
				normal_background_bg.setProperty(hmUI.prop.MORE, {
    				x: 0,
    				y: 0,
    				w: 466,
    				h: 466,
    				color: bg_color[bg_color_cur],
    				show_level: hmUI.show_level.ONLY_NORMAL,
    			});
				
//				normal_background_bg.setProperty(hmUI.prop.MORE, {color: bg_color[bg_color_cur]});
//				hmUI.showToast({text: "bg_color="+bg_color[bg_color_cur]});
			}
			
			normal_widget_togle_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 400,
              w: 90,
              h: 90,
			  text: '',
              normal_src: 'click_e.png',
			  press_src: 'click_e.png',
			  click_func: () => {
			  	toggleColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
						// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 150,
              w: 45,
              h: 150,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});			
			// погода
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 405,
              w: 110,
              h: 60,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'WeatherScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});					
			// музыка
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 405,
              w: 110,
              h: 60,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'PhoneMusicCtrlScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});				

			function togleActivity(){
				ta_cur = (ta_cur + 1) % 3;
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				
				if(ta_cur == 0){
					normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
				}
				if(ta_cur == 1){
					normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);					
				}			
				if(ta_cur == 2){
					normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);	
					normal_pai_linear_scale.setProperty(hmUI.prop.VISIBLE, true);					
				}				
			}
			togleActivity();
			dist_pai_kal_button_block = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 242,
              y: 332,
              w: 109,
              h: 65,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				togleActivity();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});			


            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
