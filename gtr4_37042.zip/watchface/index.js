﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
      // let normal_fat_burning_pointer_progress_img_pointer = ''
        //let normal_background_bg = ''
       //let normal_moon_pointer_progress_img_pointer = '' 
   
       let i_tap_bg_img = '' 
         let Tap_zona_0 = ''
         let Tap_zona_1 = ''
         let Tap_zona_2 = ''
         let Tap_zona_3 = ''
         let Tap_zona_4 = ''
         let Tap_zona_5 = ''
         let groupVremya = ''
         let groupTap = ''         
         let groupPogoda = '' 
        //let timer_1;        
     // let normal_image_img = ''  
      
      
       
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
            let stopVibro_Timer = null;

            function vibro(scene = 25) {
                let stopDelay = 50;
                vibrate.stop();
                vibrate.scene = scene;
                if (scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }

            function stopVibro() {
                vibrate.stop();
                timer.stopTimer(stopVibro_Timer);
            }        
        
        
         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }            

         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,

          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }   
               
   		//переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
    		let weatherTxtImgArray = []
    		let weatherTxtImgArrayN = []
    		let pointred = new Array(6);
    		let pointblue = new Array(5);
    		let linered = new Array(6);
    		let lineblue = new Array(5);
    		let yArrH = new Array(6);
    		let yArrL = new Array(5);
    		let y_pogodaH = new Array(6);
    		let y_pogodaL = new Array(5);
    		let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
    		let week_weater_img = []
    		let day_weater_img = []
    		const ROOTPATH = "images/"

    		//let normal_city_name_text = ''
            let curTime = hmSensor.createSensor(hmSensor.id.TIME);

			
			
    			//-------------------------------- 
		 
  		//массив иконок для графика       
    		for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28

    		}

    		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
    		let weatherData = weather.getForecastWeather();
    		let forecastData = weatherData.forecastData;


    		//обновление для   графика           
    		function updateGrafik() {
				
//       weatherData = weather.getForecastWeather();
//       forecastData = weatherData.forecastData;
      // normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
				
				
				
				
    			if (forecastData.count == 0) {
    				for (let i = 0; i < 6; i++) {
    					var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");

    				}
    			} else {
    				let weekDay = curTime.week - 1;
    				for (let i = 0; i < 6; i++) {
    					yArrH[i] = forecastData.data[i].high;
    					let element = forecastData.data[i];
    					let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
    					let date = new Date(curTime.utc + 86400000 * i);
    					let data = date.getDate();
    					let week = week_weater[weekDay];
    					week_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: week,
    					});
    					day_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: data,
    					});
    					weekDay = (weekDay + 1) % 7;
    				}
    			}


    			for (let i = 0; i < 5; i++) {
    				yArrL[i] = forecastData.data[i].low;
    			}
    			let maxH = Math.max(...yArrH)
    			let maxL = Math.min(...yArrL)
    			var shag = 46;
    			var x0 = 119;
    			for (let i = 0; i < 6; i++) {
    				pointred[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + shag * [i] - 5,
    					y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFFFF0000,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 5; i++) {
    				yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					linered[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i,
    						h: 466,
    						pos_x: -31 + shag * i,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_red.png',
    					});
    			};
    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 4; i++) {
    				yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					lineblue[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i + 23,
    						h: 466,
    						pos_x: -31 + shag * i + 23,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i + 23,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_blue.png',
    					});
    			};

    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 6; i++) {
    				y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
    				weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + i * 45 * 1.02,
    					y: y_pogodaH[i] - 38, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrH[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}

    			for (let i = 0; i < 5; i++) {
    				y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
    				weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + 23 + i * 45 * 1.02,
    					y: y_pogodaL[i] - 1, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrL[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}
    		}		
        // end user_functions.js

        let normal_stress_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 73;
        let normal_timerTextUpdate = undefined;
        let normal_pai_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 29;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 21;
        let normal_heart_rate_TextRotate_unit = null;
        let normal_heart_rate_TextRotate_unit_width = 26;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 21;
        let normal_step_TextRotate_unit = null;
        let normal_step_TextRotate_unit_width = 32;
        let normal_calorie_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 28,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 122,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 103,
              // y: 278,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -22,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 103,
                center_y: 278,
                pos_x: 103,
                pos_y: 278,
                angle: -22,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 11,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 153,
              minute_startY: 372,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 367,
              // y: 263,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -22,
              // unit_en: 'dig_a_pr.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 367,
                center_y: 263,
                pos_x: 367,
                pos_y: 263,
                angle: -22,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 367,
              center_y: 263,
              pos_x: 367,
              pos_y: 263,
              angle: -22,
              src: 'dig_a_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 266,
              // y: 306,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -22,
              // unit_en: 'dig_a_puls.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 266,
                center_y: 306,
                pos_x: 266,
                pos_y: 306,
                angle: -22,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 266,
              center_y: 306,
              pos_x: 266,
              pos_y: 306,
              angle: -22,
              src: 'dig_a_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 182,
              // y: 338,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -22,
              // unit_en: 'dig_a_step.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 182,
                center_y: 338,
                pos_x: 182,
                pos_y: 338,
                angle: -22,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 182,
              center_y: 338,
              pos_x: 182,
              pos_y: 338,
              angle: -22,
              src: 'dig_a_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 322,
              src: 'dig_a_rn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 319,
              y: 276,
              src: 'dig_a_rv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 52,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 40,
              hour_posY: 143,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 21,
              second_posY: 217,
              second_cover_path: 'bezel.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 52,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 40,
              hour_posY: 143,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js
bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 src: 'tap/bg_edit.png',
 show_level: hmUI.show_level.ONLY_EDIT,
});


groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: 466,
 h: 466,
}); // 


groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: 466,
 h: 466,
});

i_tap_bg_img = groupTap.createWidget(hmUI.widget.IMG, {
 x: 0,
 y: 0,
 w: 466,
 h: 466,
 src: 'tap/i_tap_bg.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});


Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 src: apps[tap_2_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 src: apps[tap_3_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 src: apps[tap_4_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 src: apps[tap_5_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});

Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 src: apps[tap_6_select][2],
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[0][0],
 y: tap_x_y[0][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_1_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[1][0],
 y: tap_x_y[1][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_2_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[2][0],
 y: tap_x_y[2][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_3_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[3][0],
 y: tap_x_y[3][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_4_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[4][0],
 y: tap_x_y[4][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_5_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: tap_x_y[5][0],
 y: tap_x_y[5][1],
 text: '',
 w: 113,
 h: 113,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  hmApp.startApp({
   url: apps[tap_6_select][1],
   native: true
  });
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 0,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_run();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
 x: 183, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  click_Pogoda_on();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_on();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
 x: 183,
 y: 183,
 text: '',
 w: 100,
 h: 100,
 normal_src: '0_Empty.png',
 press_src: '0_Empty.png',
 click_func: () => {
  vibro();
  tap_zona_exit();
 },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


//---------------------------    погода
groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
 x: 0,
 y: 0,
 w: 466,
 h: 466,
});

// фон
groupPogoda.createWidget(hmUI.widget.IMG, {
 x: 62,
 y: 71,
 w: 343,
 h: 323,
 src: ROOTPATH + 'Grafik/Grafik_bg.png',
 //alpha: 153,
 show_level: hmUI.show_level.ONLY_NORMAL,
});


for (var i = 0; i < 6; i++) {
 week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
  y: 295 - 21 + 2,
  w: 50,
  h: 50,
  char_space: 0, //-1
  line_space: 0,
  color: "0xFFffffff",
  text: week_weater[i],
  text_size: 22,
  text_style: hmUI.text_style.NONE,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
 });

 hmUI.deleteWidget(day_weater_img[i]);

 day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
  x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
  y: 295 - 21 + 2 + 20,
  w: 50,
  h: 50,
  char_space: 0, //-1
  line_space: 0,
  color: "0xFFffffff",
  text: 31,
  text_size: 22,
  text_style: hmUI.text_style.NONE,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
 });

 weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
  x: 98 + i * 45 * 1.02,
  y: 78,
  w: 40,
  h: 40,
  // src: weatherArray[i],
  shortcut: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
 });

}


for (var i = 0; i < 6; i++) {
 hmUI.deleteWidget(linered[i]);
 linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
 hmUI.deleteWidget(pointred[i]);
 pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
 hmUI.deleteWidget(weatherTxtImgArray[i]);
 weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
}
for (var i = 0; i < 5; i++) {
 hmUI.deleteWidget(lineblue[i]);
 lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
 hmUI.deleteWidget(pointblue[i]);
 pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
 hmUI.deleteWidget(weatherTxtImgArrayN[i]);
 weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
}


btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
 x: 183, //x кнопки
 y: 183, //y кнопки
 text: '',
 w: 100, //ширина кнопки
 h: 100, //высота кнопки
 normal_src: '0_Empty.png',
 press_src: 'press_100.png',
 click_func: () => {
  vibro(); //имя вызываемой функции
  click_Pogoda_off();
 },
 //           longpress_func: () => {
 //            vibro();
 //			   blok_btn_off();
 //           },
 show_level: hmUI.show_level.ONLY_NORMAL,
});


//Button_1.setProperty(hmUI.prop.VISIBLE, false); //screen_mode

groupVremya.setProperty(hmUI.prop.VISIBLE, true);
groupTap.setProperty(hmUI.prop.VISIBLE, false);
groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            // end user_script_beforeShortcuts.js

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 103 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 367 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 367 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 266 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_heart_rate_TextRotate_unit.setProperty(hmUI.prop.POS_X, 266 + img_offset);
                  normal_heart_rate_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 182 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.POS_X, 182 + img_offset);
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js
                            stopVibro();
                            updateGrafik();


                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js
                            stopVibro();
            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
           groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false); 


                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}