﻿    /*
    ** 
    ** 
    ** 
    */

    try {
    (()=>{
            //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

hmBle.removeListener;
hmBle.addListener(function (status) {
	if(!status) {
		hmUI.showToast({text: "Где телефон?"});
		vibro(9);
	}
})


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
              
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'ol_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 102,
              image_array: ["b-01.png","b-02.png","b-03.png","b-04.png","b-05.png","b-06.png","b-07.png","b-08.png","b-09.png","b-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 327,
              src: 'bt3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 344,
              font_array: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png","Day_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'C.png',
              unit_tc: 'C.png',
              unit_en: 'C.png',
              negative_image: 'D_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 244,
              y: 74,
              week_en: ["W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_6.png","W_7.png"],
              week_tc: ["W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_6.png","W_7.png"],
              week_sc: ["W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_6.png","W_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 143,
              day_startY: 72,
              day_sc_array: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png","Day_10.png"],
              day_tc_array: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png","Day_10.png"],
              day_en_array: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png","Day_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 171,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 171,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 195,
              second_startY: 177,
              second_array: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png","D_10.png"],
              second_zero: 0,
              second_space: -76,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'ol_2.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 233,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 131,
              src: 'bt3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 171,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 171,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 195,
              second_startY: 177,
              second_array: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png","D_10.png"],
              second_zero: 0,
              second_space: -76,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 305,
              y: 293,
              w: 100,
              h: 100,
              select_image: 'un2.png',
              un_select_image: 'un1.png',
              default_type: hmUI.edit_type.DATE,
              optional_types: [
                { type: hmUI.edit_type.DATE, preview: 'ez(1)_DATE.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
              ],
              count: 2,
              tips_BG: '.png',
              tips_x: -152,
              tips_y: 26,
              tips_width: 135,
              tips_margin: 6,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 306,
                  day_startY: 310,
                  day_sc_array: ["zero_1.png","zero_2.png","zero_3.png","zero_4.png","zero_5.png","zero_6.png","zero_7.png","zero_8.png","zero_9.png","zero_10.png"],
                  day_tc_array: ["zero_1.png","zero_2.png","zero_3.png","zero_4.png","zero_5.png","zero_6.png","zero_7.png","zero_8.png","zero_9.png","zero_10.png"],
                  day_en_array: ["zero_1.png","zero_2.png","zero_3.png","zero_4.png","zero_5.png","zero_6.png","zero_7.png","zero_8.png","zero_9.png","zero_10.png"],
                  day_zero: 0,
                  day_space: 0,
                  day_align: hmUI.align.LEFT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 306,
                  y: 310,
                  font_array: ["sm_0.png","sm_1.png","sm_2.png","sm_3.png","sm_4.png","sm_5.png","sm_6.png","sm_7.png","sm_8.png","sm_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'xsm.png',
                  unit_tc: 'xsm.png',
                  unit_en: 'xsm.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 169,
              w: 121,
              h: 112,
              src: 'zero.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 167,
              w: 140,
              h: 112,
              src: 'zero.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 334,
              w: 112,
              h: 89,
              src: 'zero.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 196,
				  y: 41,
				  text: '',
				  w: 100,
				  h: 100,
				  normal_src: 'zero.png',
				  press_src: 'zero.png',
				  click_func: () => {
					hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					hmBle.removeListener;
					hmBle.addListener(function (status) {
						if(!status) {
							hmUI.showToast({text: "Где телефон?"});
							vibro(9);
						}
					})
		
				
				}),
				pause_call: (function () {
				}),
			});


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
