﻿
    /*
	AMetal (C) Magonegro 2022
    Thanks to CashaCX75 for his awesome tool: Watch_Face_Editor	3
	Graphics found on the net, rest of resources developed with several freeware apps.
	Thanks to the Amazfit team who developed these fantastic mini computer watches.
	All programming, development, headaches, sleepless nights and lack of health are my tributes to the cause.
	I developed this while in bed with a severe illness. Time spent playing with this toys have been a pleasant
	experience and have given me very good and funny moments that helped me to not becoming mad with my health.
	I encourage all of you developers to keep making those wonderful watchfaces that always keep me looking forward
	and wondering what this guys are capable of... Thanks to you all for your inspiration.
	Use this code as a sandbox, it is not very clean as it has been developed as an amusement,
	but it has been more than that at the end.
	
	Cheers.

	*/


    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		// Conversion factor to ease conversions 454 GTR3(454/480), 466 GTR4, 480 GTR3Pro
		// Coordinates for original version are for GTR3Pro, so multiplying for the ratio is enough
		let GTRRatio=466/480; // 480 is fixed, so ratio is (desired resolution)/480;

        let normal_background_bg_img = ''

		let normal_battery_icon_img = ''
		let normal_battery_image_progress_img_level = ''

        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''

        let normal_date_img_date_week_img = ''

        let normal_heart_rate_text_separator_img = ''

        let normal_moon_image_progress_img_level = ''

        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_wind_icon_img = ''
        let normal_wind_image_progress_img_level = ''

        let normal_digital_clock_hour_separator_img = ''

        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''

		
		let btnmenu
		let btncrono
		let btncounter
		let btnbackgroundP
		let btnbackgroundN
		let btnforeP
		let btnforeN		
		let btnmusic
		let btnAbout
		let btnTools
		let btnAtom
		let btnRes4
		let currentmenu = 0
		let numerotest = 0
		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let Numfondo = 0
			
		let bigNumObject = new Array(8)
        let HoursObject = new Array(4)
		let flag = true
		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let lastTime = 0
		let lastMark = 0
		let tmpMark = 0
		let diffTime
		let minutes
		let milis = 0
		let seconds
		let hours
		let hsTimer = null
		let green_red_btn
		let clear

		let CounterObj = new Array(6)
		let CounterVal = new Array(3)
		let btnCAdd = new Array(3)
		let btnCSub = new Array(3)
		let resetCount
		let lResetPos = false
		let imgabout
		const music = hmSensor.createSensor(hmSensor.id.MUSIC)
		let lPlaying=false
		
		let MiniTime = new Array(8)
		let MiniTimeSeconds=100
		let MiniTimeBack
		let lMiniTimeVisible = false
		
		let nLang = 0 // 0-ES 1-EN ... button selectable (I hope)
		let MainTimer // Main timer used for drawing watchface
		let MainSeconds=100 // Force paint on first timer call
		let MainMinutes=100 // Force paint on first timer call
		let MainHours=100 // Force paint on first timer call
	
		let btnLang
		let NumLetras = 0
		
		// Watchface objects
		let WFTimeObj = new Array(6) //HHMMSS
		const BatterySensor = hmSensor.createSensor(hmSensor.id.BATTERY)
		let WFDateObj = new Array(5) 
		let WFHRObj = new Array(3)
		const heart = hmSensor.createSensor(hmSensor.id.HEART)
		const distance = hmSensor.createSensor(hmSensor.id.DISTANCE)
		let WFDistObj = new Array(6) 
		let WFBatObj = new Array(4)
		let lVibrate = false
		let btnVibrate
		let btnBroken
		let lWFActive=true

		let btnRandom
		let broken
		let idle_broken
		let idle_broken2
		let nBroken=0
		
		let rndBallX = 240*GTRRatio;
		let rndBallY = 240*GTRRatio;
		let rndBall
		let rndBallDir=0 // Angle
		let rnd2BallX = 240*GTRRatio;
		let rnd2BallY = 240*GTRRatio;
		let rnd2Ball
		let rnd2BallDir=0 // Angle
		let PartTimer
		let RandIterations=0;
		let rndHold=0 // Hold some frames so explosion can be seen.
		let lAtom=false
		let speed1=10;
		let speed2=10;

		let nAnimFrameSec=-1
		let nAnimFrameMin=-1
		let nAnimFrameHour=-1
		let lAnimSec=false
		let btnScroll
		let lRedrawTime=true
		

        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let btnAnalog
		let nAnalog=0;
		let AnalogDial
		let lDigital=true;
		let btnDigital
		let btnOther
		let lOther=true;
		
		let Xsecond;
		let Xminute;
		let Xhour;
		let Xcenter;
		let XnAnimSec=0;
		let XnAnimMin=10;
		let XnAnimHour=20;
		
		let nPaintBatt=0; // Counter to not paint battery data very often loosing time for other processes.
		
		let btnPreset1;	// buttons for presets, 3 avilable. Pressing a button retrieves preset.
		let btnPreset2;
		let btnPreset3;
		let btnStoreFlag; // Activates store flag for presets.
		let lStoreFlag=false;
		let Presets = new Array(3)

		let nRetOther=0;
		
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		
	function img(src) {
		return parseInt(NumLetras) + '-' + src;
	}

	function DrawLasers(){
		// Los segundos son segundos x 6º de arco mas la prop de 6º a 1000 milesimas osea 6*milis/1000
		 let a=now.second*6+6*(now.utc % 1000)/1000;
		 Xsecond.setProperty(hmUI.prop.MORE, {
              src: 'SB' + parseInt(XnAnimSec) + '.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: 240*GTRRatio-25*GTRRatio,
              pos_y: 20*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:a,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			XnAnimSec=(XnAnimSec+1) % 32;
		 a=now.minute*6;
		 Xminute.setProperty(hmUI.prop.MORE, {
              src: 'MG' + parseInt(XnAnimMin) + '.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: 240*GTRRatio-35*GTRRatio,
              pos_y: 50*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:a,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			XnAnimMin=(XnAnimMin+1) % 32;
			
		 a=((now.hour % 12)*60+now.minute)/2;
		 Xhour.setProperty(hmUI.prop.MORE, {
              src: 'HR' + parseInt(XnAnimHour) + '.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: 240*GTRRatio-40*GTRRatio,
              pos_y: 100*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:a,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			XnAnimHour=(XnAnimHour+1) % 32;	
	}

	// Called every 1/20 second, at least for seconds, maybe slower with a counter for the rest.
	function PaintMain(){
		PaintTime();
		if(currentmenu>0) return;
		if(nAnalog==4) DrawLasers();

		nPaintBatt=nPaintBatt+1;
		if(nPaintBatt>20){ // Paints battery data once a second
			let batindex=BatterySensor.current;
			if(batindex>99) batindex=99;
			if(batindex>0) batindex=batindex-1;
			batindex=(batindex / 10);
			normal_battery_image_progress_img_level.setProperty(hmUI.prop.SRC, img("Bat" + parseInt(batindex) + ".png"));
			nPaintBatt=0;
		}
		
		if(!lDigital && !lOther) return;
		
		let s = now.second;
		let h = now.hour;
		let m = now.minute;

		if(MainSeconds==s && MainMinutes==m && MainHours==h && 
			nAnimFrameSec<0 && nAnimFrameMin<0 && nAnimFrameHour<0) return;
		
		let mon = now.month;
		let day = now.day;
		let HR=heart.last;
		if(HR==NaN) HR=0;
		let Dist=distance.current;
		if(Dist==NaN) Dist=0;
		Dist=Dist/10; // Distance comes in meters
		if(Dist>9999) Dist=9999;

		if(lDigital){
			if(lAnimSec){
				if(MainSeconds!=s && nAnimFrameSec<0) nAnimFrameSec=3;
				if(MainMinutes!=m && nAnimFrameMin<0) nAnimFrameMin=3;
				if(MainHours!=h && nAnimFrameHour<0) nAnimFrameHour=3;
			}
			
			if(nAnimFrameSec<0 || lRedrawTime) {
				let xx=382*GTRRatio;
				let yy=246*GTRRatio;
				let nspc=0; // Secs, 43x60 font
				WFTimeObj[1].setProperty(hmUI.prop.MORE, {
						x: xx+0*43*GTRRatio, y: yy, w: 43*GTRRatio, h: 60*GTRRatio,
						src: img("SilverSm" + parseInt(s / 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});
				WFTimeObj[0].setProperty(hmUI.prop.MORE, {
						x: xx+1*43*GTRRatio+nspc, y: yy, w: 43*GTRRatio, h: 60*GTRRatio,
						src: img("SilverSm" + parseInt(s % 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});
				MainSeconds=s;
				nAnimFrameSec=-1;
			}
			else
			{
				let xx=382*GTRRatio;
				let yy=246*GTRRatio;
				let nspc=0; // Secs, 43x60 font
				if(Math.floor(s / 10)!=Math.floor(MainSeconds / 10))
					WFTimeObj[1].setProperty(hmUI.prop.MORE, {
						x: xx+0*43*GTRRatio, y: yy+nAnimFrameSec*15*GTRRatio, w: 43*GTRRatio, h: 60*GTRRatio-(nAnimFrameSec*15*GTRRatio),
						src: img("SilverSm" + parseInt(s / 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});

				if(Math.floor(s % 10)!=Math.floor(MainSeconds % 10))
					WFTimeObj[0].setProperty(hmUI.prop.MORE, {
						x: xx+1*43*GTRRatio+nspc, y: yy+nAnimFrameSec*15*GTRRatio, w: 43*GTRRatio, h: 60*GTRRatio-(nAnimFrameSec*15*GTRRatio),
						src: img("SilverSm" + parseInt(s % 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});
				nAnimFrameSec=nAnimFrameSec-1;
				if(nAnimFrameSec<0) MainSeconds=s;
			}

			if(nAnimFrameMin<0  || lRedrawTime) {
				let xx=214*GTRRatio;
				let yy=168*GTRRatio;
				let nspc=5*GTRRatio;
				WFTimeObj[3].setProperty(hmUI.prop.MORE, {
					x: xx+0*80*GTRRatio, y: yy, w: 80*GTRRatio, h: 140*GTRRatio,
					src: img("SilverN" + parseInt(m / 10) + ".png"),
					show_level: hmUI.show_level.ONLY_NORMAL});
				WFTimeObj[2].setProperty(hmUI.prop.MORE, {
					x: xx+1*80*GTRRatio+nspc, y: yy, w: 80*GTRRatio, h: 140*GTRRatio,
					src: img("SilverN" + parseInt(m % 10) + ".png"),
					show_level: hmUI.show_level.ONLY_NORMAL});
				MainMinutes=m;
				nAnimFrameMin=-1;
			}
			else
			{
				let xx=214*GTRRatio;
				let yy=168*GTRRatio;
				let nspc=5*GTRRatio;

				if(Math.floor(m / 10)!=Math.floor(MainMinutes / 10))
					WFTimeObj[3].setProperty(hmUI.prop.MORE, {
						x: xx+0*80*GTRRatio, y: yy+nAnimFrameMin*35*GTRRatio, w: 80*GTRRatio, h: 140*GTRRatio-(nAnimFrameMin*35*GTRRatio),
						src: img("SilverN" + parseInt(m / 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});

				if(Math.floor(m % 10)!=Math.floor(MainMinutes % 10))
					WFTimeObj[2].setProperty(hmUI.prop.MORE, {
						x: xx+1*80*GTRRatio+nspc, y: yy+nAnimFrameMin*35*GTRRatio, w: 80*GTRRatio, h: 140*GTRRatio-(nAnimFrameMin*35*GTRRatio),
						src: img("SilverN" + parseInt(m % 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});
				nAnimFrameMin=nAnimFrameMin-1;
				if(nAnimFrameMin<0) MainMinutes=m;
			}

			if(nAnimFrameHour<0  || lRedrawTime) {
				let xx=12*GTRRatio;
				let yy=168*GTRRatio;
				let nspc=5*GTRRatio;
				WFTimeObj[5].setProperty(hmUI.prop.MORE, {
					x: xx+0*80*GTRRatio, y: yy, w: 80*GTRRatio, h: 140*GTRRatio,
					src: img("SilverN" + parseInt(h / 10) + ".png"),
					show_level: hmUI.show_level.ONLY_NORMAL});
				WFTimeObj[4].setProperty(hmUI.prop.MORE, {
					x: xx+1*80*GTRRatio+nspc, y: yy, w: 80*GTRRatio, h: 140*GTRRatio,
					src: img("SilverN" + parseInt(h % 10) + ".png"),
					show_level: hmUI.show_level.ONLY_NORMAL});
				MainHours=h;
				nAnimFrameHour=-1;
			}
			else
			{
				let xx=12*GTRRatio;
				let yy=168*GTRRatio;
				let nspc=5*GTRRatio;

				if(Math.floor(h / 10)!=Math.floor(MainHours / 10))
					WFTimeObj[5].setProperty(hmUI.prop.MORE, {
						x: xx+0*80*GTRRatio, y: yy+nAnimFrameHour*35*GTRRatio, w: 80*GTRRatio, h: 140*GTRRatio-(nAnimFrameHour*35*GTRRatio),
						src: img("SilverN" + parseInt(h / 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});

				if(Math.floor(h % 10)!=Math.floor(MainHours % 10))
					WFTimeObj[4].setProperty(hmUI.prop.MORE, {
						x: xx+1*80*GTRRatio+nspc, y: yy+nAnimFrameHour*35*GTRRatio, w: 80*GTRRatio, h: 140*GTRRatio-(nAnimFrameHour*35*GTRRatio),
						src: img("SilverN" + parseInt(h % 10) + ".png"),
						show_level: hmUI.show_level.ONLY_NORMAL});
				nAnimFrameHour=nAnimFrameHour-1;
				if(nAnimFrameHour<0) MainHours=h;
			}
			if(nAnimFrameSec<0 && nAnimFrameMin<0 && nAnimFrameHour<0) lRedrawTime = false;
	}
		
	if(lOther)
	{
		nRetOther=nRetOther+1;
		if(nRetOther>20){
			nRetOther=0;
			WFDateObj[4].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(day / 10) + ".png"));
			WFDateObj[3].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(day % 10) + ".png"));

			WFDateObj[1].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(mon / 10) + ".png"));
			WFDateObj[0].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(mon % 10) + ".png"));

			if(HR>99){
				WFHRObj[2].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(HR / 100) + ".png"));
				WFHRObj[1].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt((HR % 100)/10) + ".png"));
				WFHRObj[0].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(HR % 10) + ".png"));
			}
			else
			{
				WFHRObj[2].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(HR / 10) + ".png"));
				WFHRObj[1].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(HR % 10) + ".png"));
				WFHRObj[0].setProperty(hmUI.prop.SRC, img("NO_IMAGE_AV.png")); // clear image
			}

			if((Dist/1000)>=1)
				WFDistObj[5].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(Dist / 1000) + ".png"))
			else
				WFDistObj[5].setProperty(hmUI.prop.SRC, img("NO_IMAGE_AV.png"));
				
			WFDistObj[4].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt((Dist % 1000)/100) + ".png"));
			WFDistObj[2].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt((Dist % 100)/10) + ".png"));
			WFDistObj[1].setProperty(hmUI.prop.SRC, img("SSilverSm" + parseInt(Dist % 10) + ".png"));
			
			batindex=BatterySensor.current;
			if(batindex>99)
				WFBatObj[3].setProperty(hmUI.prop.SRC, img("LCDSm1.png"))
			else
				WFBatObj[3].setProperty(hmUI.prop.SRC, img("NO_IMAGE_AV.png"));

			if(batindex>9)
				WFBatObj[2].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt((batindex % 100)/ 10) + ".png"))
			else
				WFBatObj[2].setProperty(hmUI.prop.SRC, img("NO_IMAGE_AV.png"));

			WFBatObj[1].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(batindex % 10) + ".png"))

			PaintWeekDay();
			
		}
	}

	}

	function UpdateLayout(){
			MainSeconds=100; // force paint on timer
			MainMinutes=100;
			MainHours=100;
			normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, img("SilverNS.png"));
			WFDateObj[2].setProperty(hmUI.prop.SRC, img("SSilverSmM.png"));
			normal_battery_icon_img.setProperty(hmUI.prop.SRC,img('BatBK.png'));
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.SRC, img('heart.png'));
			WFDistObj[3].setProperty(hmUI.prop.SRC,img('punto.png'));
			WFDistObj[0].setProperty(hmUI.prop.SRC,img('Km.png'));
			WFBatObj[0].setProperty(hmUI.prop.SRC, img("percent.png"));
			MiniTimeBack.setProperty(hmUI.prop.SRC,img('LCDSmBack.png'));
			lRedrawTime=true;
	}

	// Tried everything I could think but nothing worked to instantly change a weekday widget to show another lang.
	// Ended programming a timer and make my own control for the widget. This way I can paint whatever I want whenever I want.
	// This seems to be the way to go when you want to have multiple watchfaces or wf layers runtime selectable, like font
	// changes or swap elements in runtime. A createwidget/destroywidget didn't work for me without a screen blanking.
	// That worked but was a odd job. This works flawlessly and gives a lot of possibilities but requires a bit of work. 
	function PaintWeekDay(){
		let nDiatmp=now.week-1;
		if(nLang==0)
			normal_date_img_date_week_img.setProperty(hmUI.prop.SRC, img("dia" + parseInt(nDiatmp) + ".png"));
		if(nLang==1)
			normal_date_img_date_week_img.setProperty(hmUI.prop.SRC, img("diaen" + parseInt(nDiatmp) + ".png"));
	}

	function click_Lang(){
		click_Vibrate();
		nLang=(nLang+1) % 2
		PaintWeekDay();
		if(nLang==0) hmUI.showToast({text: 'Lang: 0-Spanish'});
		if(nLang==1) hmUI.showToast({text: 'Lang: 1-English'});
	}

	function UpdateVib(){
		if(lVibrate)
			btnVibrate.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnVibON.png',
			  press_src: 'btnVibON.png',
			  click_func: () => {
				click_VIBONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnVibrate.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnVibOFF.png',
			  press_src: 'btnVibOFF.png',
			  click_func: () => {
				click_VIBONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}


	function UpdateAnalog(){
		if(nAnalog==1){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON.png',
			  press_src: 'AnalogON.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'Mhour.png',
              hour_centerX: 241*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 109*GTRRatio,
              hour_posY: 206*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'Mmin.png',
              minute_centerX: 241*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 95*GTRRatio,
              minute_posY: 240*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'Msec.png',
              second_centerX: 241*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 165*GTRRatio,
              second_posY: 227*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		}

		if(nAnalog==2){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON2.png',
			  press_src: 'AnalogON2.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDDk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 't_hour.png',
              hour_centerX: 240*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 19*GTRRatio,
              hour_posY: 171*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 't_min.png',
              minute_centerX: 240*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 27*GTRRatio,
              minute_posY: 232*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 't_sec.png',
              second_centerX: 240*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 26*GTRRatio,
              second_posY: 239*GTRRatio,
              second_cover_path: 't_over.png',
              second_cover_x: 229*GTRRatio,
              second_cover_y: 228*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}

		if(nAnalog==3){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON3.png',
			  press_src: 'AnalogON3.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'MGHour.png',
              hour_centerX: 240*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 31*GTRRatio,
              hour_posY: 133*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'MGMin.png',
              minute_centerX: 240*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 22*GTRRatio,
              minute_posY: 204*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'MGsecond.png',
              second_centerX: 240*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 22*GTRRatio,
              second_posY: 211*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDD2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}

		if(nAnalog==5){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON5.png',
			  press_src: 'AnalogON5.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'Xhour1.png',
              hour_centerX: 240*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 31*GTRRatio,
              hour_posY: 165*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'Xminute1.png',
              minute_centerX: 240*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 30*GTRRatio,
              minute_posY: 214*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'Xsec1.png',
              second_centerX: 240*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 11*GTRRatio,
              second_posY: 207*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDD3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}

		if(nAnalog==6){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON6.png',
			  press_src: 'AnalogON6.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'XXHour.png',
              hour_centerX: 240*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 21*GTRRatio,
              hour_posY: 143*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'XXMin.png',
              minute_centerX: 240*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 20*GTRRatio,
              minute_posY: 202*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'XXSec.png',
              second_centerX: 240*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 11*GTRRatio,
              second_posY: 213*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDD4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}


		if(nAnalog==4){
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogON4.png',
			  press_src: 'AnalogON4.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			AnalogDial.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}


		if(nAnalog==0)
			btnAnalog.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogOFF.png',
			  press_src: 'AnalogOFF.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}

	function UpdateDigital(){
		if(lDigital)
			btnDigital.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnDigitalON.png',
			  press_src: 'btnDigitalON.png',
			  click_func: () => {
				click_Digital();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnDigital.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnDigitalOFF.png',
			  press_src: 'btnDigitalOFF.png',
			  click_func: () => {
				click_Digital();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}

	function UpdateOther(){
		if(lOther)
			btnOther.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnOtherON.png',
			  press_src: 'btnOtherON.png',
			  click_func: () => {
				click_Other();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnOther.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnOtherOFF.png',
			  press_src: 'btnOtherOFF.png',
			  click_func: () => {
				click_Other();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}

	function UpdateBroken(){
		if(nBroken==2){
			btnBroken.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBrokON2.png',
			  press_src: 'btnBrokON2.png',
			  click_func: () => {
				click_BrokONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
			broken.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'dropped.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}
		if(nBroken==1){
			btnBroken.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBrokON.png',
			  press_src: 'btnBrokON.png',
			  click_func: () => {
				click_BrokONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
			broken.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'bglass2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}
		if(nBroken==0){
			btnBroken.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBrokOFF.png',
			  press_src: 'btnBrokOFF.png',
			  click_func: () => {
				click_BrokONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		}
		if(idle_broken) idle_broken.setProperty(hmUI.prop.VISIBLE, (nBroken==1));
		if(idle_broken2) idle_broken2.setProperty(hmUI.prop.VISIBLE, (nBroken==2));
	}


	function ShowTools(lVisible){
		btnbackgroundP.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnbackgroundN.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnLang.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnforeP.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnforeN.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnVibrate.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnBroken.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnRandom.setProperty(hmUI.prop.VISIBLE, lVisible);
		ShowMiniTime(lVisible);
	}
	

	function ShowRes4(lVisible){
		ShowMiniTime(lVisible);
		UpdateAnalog();
		UpdateDigital();
		UpdateOther();
		lStoreFlag=false;
		UpdateStoreFlag();
		btnAnalog.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnDigital.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnOther.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnPreset1.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnPreset2.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnPreset3.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnStoreFlag.setProperty(hmUI.prop.VISIBLE, lVisible);
	}

	function click_VIBONOFF(){
		lVibrate=!lVibrate;
		click_Vibrate();
		UpdateVib();
		StoreTempData();
		if(lVibrate)
			hmUI.showToast({text: 'Vibration: ON'})
		else
			hmUI.showToast({text: 'Vibration: OFF'});
	}

	function click_BrokONOFF(){
		click_Vibrate();
		nBroken=(nBroken+1) % 3;
		UpdateBroken();
		StoreTempData();
		if(nBroken==2) hmUI.showToast({text: 'Broken: DROPS'});
		if(nBroken==1) hmUI.showToast({text: 'Broken: GLASS'});
		if(nBroken==0) hmUI.showToast({text: 'Broken: OFF'});
	}

	
	function click_Tools(){
		click_Vibrate();
		ShowMenu(false);
		currentmenu=5;
		ShowTools(true);
	}

	function UpdateAtom(){
		if(lAtom)
			btnAtom.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnAtomON.png',
			  press_src: 'btnAtomON.png',
			  click_func: () => {
				click_AtomONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnAtom.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnAtomOFF.png',
			  press_src: 'btnAtomOFF.png',
			  click_func: () => {
				click_AtomONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}

	function UpdateScroll(){
		if(lAnimSec)
			btnScroll.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnScrollON.png',
			  press_src: 'btnScrollON.png',
			  click_func: () => {
				click_ScrollONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnScroll.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnScrollOFF.png',
			  press_src: 'btnScrollOFF.png',
			  click_func: () => {
				click_ScrollONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
	}


	function click_AtomONOFF(){
		click_Vibrate();
		lAtom=!lAtom
		UpdateAtom();
		StoreTempData();
		if(lAtom)
			hmUI.showToast({text: 'Particles: ON'})
		else
			hmUI.showToast({text: 'Particles: OFF'});
	}

	function click_ScrollONOFF(){
		click_Vibrate();
		lAnimSec=!lAnimSec
		UpdateScroll();
		StoreTempData();
		if(lAnimSec)
			hmUI.showToast({text: 'Digit Scroll: ON'})
		else
			hmUI.showToast({text: 'Digit Scroll: OFF'});
	}

	function click_Res4(){
		click_Vibrate();
		ShowMenu(false);
		currentmenu=8;
		ShowRes4(true);
	}



	// Called every 1/10 second to assure perfect time sync.
	function PaintTime(){
		if(!lMiniTimeVisible) return;
		let s = now.second;
		if(MiniTimeSeconds==s) return; 
		let h = now.hour;
		let m = now.minute;
		
		// dont add img(... here this goes with its own background
		MiniTime[6].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(s / 10) + ".png"));
        MiniTime[7].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(s % 10) + ".png"));
        MiniTime[3].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(m / 10) + ".png"));
        MiniTime[4].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(m % 10) + ".png"));
        MiniTime[0].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(h / 10) + ".png"));
        MiniTime[1].setProperty(hmUI.prop.SRC, img("LCDSm" + parseInt(h % 10) + ".png"));
        MiniTime[2].setProperty(hmUI.prop.SRC, img('LCDSmSep.png'));
        MiniTime[5].setProperty(hmUI.prop.SRC, img('LCDSmSep.png'));
		MiniTimeSeconds=s;
	}

	function ShowMiniTime(lVisible){
		MiniTimeBack.setProperty(hmUI.prop.VISIBLE, lVisible);
		for (let i = 0; i < 8; i += 1) {
			MiniTime[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		}
		lMiniTimeVisible=lVisible;
		if(lVisible) MiniTimeSeconds=100;
	}
	
	function CreateMiniTime(){
		MiniTimeBack = hmUI.createWidget(hmUI.widget.IMG,{
					x: 0,
					y: 0,
					src: img('LCDSmBack.png'),
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
		MiniTimeBack.setProperty(hmUI.prop.VISIBLE, false);
		
		for (let i = 0; i < 8; i += 1) {
			MiniTime[i]=hmUI.createWidget(hmUI.widget.IMG,{
					x: 0,
					y: 0,
					src: img('LCDSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
			MiniTime[i].setProperty(hmUI.prop.VISIBLE, false);
		}
		lMiniTimeVisible=false;
	}
	
	// Call this only if a new location is required.
	function SetMiniTime(x,y){
		// font size: digits: 22x36, sep: 10*36
		let xx=x;
		MiniTimeBack.setProperty(hmUI.prop.MORE,{
					x: xx*GTRRatio-3*GTRRatio,
					y: y*GTRRatio-3*GTRRatio,
					src: img('LCDSmBack.png'),
					show_level: hmUI.show_level.ONLY_NORMAL,
					});

		for (let i = 0; i < 8; i += 1) {
			if(i==2 || i==5) {
				MiniTime[i].setProperty(hmUI.prop.MORE,{
					x: xx*GTRRatio,
					y: y*GTRRatio,
					src: img('LCDSmBack.png'),
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
			}
			else
				MiniTime[i].setProperty(hmUI.prop.MORE,{
					x: xx*GTRRatio,
					y: y*GTRRatio,
					src: img('LCDSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
					
			if(i==2 || i==5)
					xx=xx+10
				else
					xx=xx+22;
		}
	}

	function ShowMusic() {
 		if(lPlaying)
			btnmusic.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusicon.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music() 
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnmusic.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusic.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music() 
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
			UpdateMenu();
		}

	// Music control is a bit messy. Not even zepp OS itself displays the icon when it is needed or not.
	// Sometimes the play/stop state of the control desynchonizes. My workaround is to go to the zepp music widged
	// and start play, then return to the music control on the wf, stop and play. After this it works fine.
	function click_Music() {
		click_Vibrate();
		if(music.isPlaying) {
			music.audPause()
			lPlaying=false;
		}
		else {
			music.audPlay();
			lPlaying=true;
		}
		ShowMusic();
	}	

	function ShowAbout(lVisible){
		imgabout.setProperty(hmUI.prop.VISIBLE, lVisible);
		//if(lVisible) SetMiniTime(164,18);
		ShowMiniTime(lVisible);
	}

	function click_About() {
		click_Vibrate();
		ShowMenu(false);
		currentmenu=4;
		ShowAbout(true);
	}	


	function UpdateBackground(){
		normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "Back" + parseInt(Numfondo) + ".png");
	}

	function click_BackgroundP() {
		click_Vibrate();
		if(Numfondo==0) 
			Numfondo=6;
		else
			Numfondo=Numfondo-1;

		UpdateBackground();
		StoreTempData();
		//hmUI.showToast({text: 'Background: ' + parseInt(Numfondo)});
	}	

	function click_BackgroundN() {
		click_Vibrate();
		Numfondo=(Numfondo+1) % 7;
		UpdateBackground();
		StoreTempData();
		//hmUI.showToast({text: 'Background: ' + parseInt(Numfondo)});
	}	
		
	function click_foreP() {
		click_Vibrate();
		if(NumLetras==0) 
			NumLetras=9;
		else
			NumLetras=NumLetras-1;

		StoreTempData();
		UpdateLayout();
		hmUI.showToast({text: 'Foreground: ' + parseInt(NumLetras)});
	}	

	function click_foreN() {
		click_Vibrate();
		NumLetras=(NumLetras+1) % 10;
		StoreTempData();
		UpdateLayout();
		hmUI.showToast({text: 'Foreground: ' + parseInt(NumLetras)});
	}			
		
	function click_Random(){
		let u = now.utc;
		click_Vibrate();
		Numfondo = (u/100) % 7;
		UpdateBackground();
		NumLetras = u % 10;
		UpdateLayout();
		StoreTempData();		
		hmUI.showToast({text: 'Random: F:' + parseInt(NumLetras) + ' B:' +parseInt(Numfondo)});
	}	
		
	function click_Analog(){
		nAnalog=(nAnalog + 1) % 7;
		click_Vibrate();
		UpdateAnalog();
		lStoreFlag=false;
		UpdateStoreFlag();
		StoreTempData();
		hmUI.showToast({text: 'Analog: ' + parseInt(nAnalog)})
	}	

	function click_Other(){
		lOther=!lOther;
		click_Vibrate();
		UpdateOther();
		lStoreFlag=false;
		UpdateStoreFlag();
		StoreTempData();
		if(lOther)
			hmUI.showToast({text: 'Infos: ON'})
		else
			hmUI.showToast({text: 'Infos: OFF'});
	}	

	function click_Digital(){
		lDigital=!lDigital;
		click_Vibrate();
		UpdateDigital();
		lStoreFlag=false;
		UpdateStoreFlag();
		StoreTempData();
		if(lDigital)
			hmUI.showToast({text: 'Digital: ON'})
		else
			hmUI.showToast({text: 'Digital: OFF'});
	}	

	function StoreTempData() { // Data stored this way doesn't survive a watch reboot, but keeps data between wf changes
		// Some cookies for the watch 8-)
		hmFS.SysProSetInt('AMetal_Back_int', Numfondo);
		hmFS.SysProSetInt('AMetal_Fore_int', NumLetras);
		hmFS.SysProSetInt('AMetal_C1_int', CounterVal[0]);
		hmFS.SysProSetInt('AMetal_C2_int', CounterVal[1]);
		hmFS.SysProSetInt('AMetal_C3_int', CounterVal[2]);
		hmFS.SysProSetInt('AMetal_Lang_int',nLang);
		let nTmp=0
		if(lVibrate) nTmp=1;
		hmFS.SysProSetInt('AMetal_Vib_int',nTmp);
		hmFS.SysProSetInt('AMetal_Broken_int',nBroken);
		nTmp=0
		if(lAtom) nTmp=1;
		hmFS.SysProSetInt('AMetal_Atom_int',nTmp);
		nTmp=0
		if(lAnimSec) nTmp=1;
		hmFS.SysProSetInt('AMetal_Scroll_int',nTmp);

		hmFS.SysProSetInt('AMetal_Analog_int',nAnalog);

		nTmp=0
		if(lDigital) nTmp=1;
		hmFS.SysProSetInt('AMetal_Digital_int',nTmp);
		nTmp=0
		if(lOther) nTmp=1;
		hmFS.SysProSetInt('AMetal_Other_int',nTmp);

		hmFS.SysProSetChars('AMetal_Preset1_str',Presets[0]);
		hmFS.SysProSetChars('AMetal_Preset2_str',Presets[1]);
		hmFS.SysProSetChars('AMetal_Preset3_str',Presets[2]);
	}
	
	function LoadTempData() { // Take some cookies and check them for safety
		Numfondo = hmFS.SysProGetInt('AMetal_Back_int');
		if(Numfondo==NaN) Numfondo=0;
		if(Numfondo<0 || Numfondo>6) Numfondo=0;
		
		NumLetras = hmFS.SysProGetInt('AMetal_Fore_int');
		if(NumLetras==NaN) NumLetras=0;
		if(NumLetras<0 || NumLetras>9) NumLetras=0;

		CounterVal[0]=hmFS.SysProGetInt('AMetal_C1_int');
		if(CounterVal[0]==NaN) CounterVal[0]=0;
		if(CounterVal[0]<0 || CounterVal[0]>99) CounterVal[0]=0;
		CounterVal[1]=hmFS.SysProGetInt('AMetal_C2_int');
		if(CounterVal[1]==NaN) CounterVal[1]=0;
		if(CounterVal[1]<0 || CounterVal[1]>99) CounterVal[1]=0;
		CounterVal[2]=hmFS.SysProGetInt('AMetal_C3_int');
		if(CounterVal[2]==NaN) CounterVal[2]=0;
		if(CounterVal[2]<0 || CounterVal[2]>99) CounterVal[2]=0;
		nLang=hmFS.SysProGetInt('AMetal_Lang_int');
		if(nLang==NaN) nLang0;
		if(nLang<0 || nLang>2) nLang=0;
		lVibrate=false;
		let nTm=hmFS.SysProGetInt('AMetal_Vib_int');
		if(nTm==NaN) nTm=1;
		if(nTm>0) 
			lVibrate=true
		else
			lVibrate=false;
		
		nBroken=hmFS.SysProGetInt('AMetal_Broken_int');
		if(nBroken==NaN) nBroken=0;
		if(nBroken>2) nBroken=0;

		nTm=hmFS.SysProGetInt('AMetal_Atom_int');
		if(nTm==NaN) nTm=0;
		if(nTm>0) 
			lAtom=true
		else
			lAtom=false;

		nTm=hmFS.SysProGetInt('AMetal_Scroll_int');
		if(nTm==NaN) nTm=1;
		if(nTm>0) 
			lAnimSec=true
		else
			lAnimSec=false;
		
		nAnalog=hmFS.SysProGetInt('AMetal_Analog_int');
		if(nAnalog==NaN) nAnalog=0;
		if(nAnalog<0 || nAnalog>6) nAnalog=0;

		nTm=hmFS.SysProGetInt('AMetal_Digital_int');
		if(nTm==NaN) nTm=1;
		if(nTm>0) 
			lDigital=true
		else
			lDigital=false;

		nTm=hmFS.SysProGetInt('AMetal_Other_int');
		if(nTm==NaN) nTm=1;
		if(nTm>0) 
			lOther=true
		else
			lOther=false;
		
		Presets[0]=hmFS.SysProGetChars('AMetal_Preset1_str');
		Presets[1]=hmFS.SysProGetChars('AMetal_Preset2_str');
		Presets[2]=hmFS.SysProGetChars('AMetal_Preset3_str');
	}

    function CalcTime(mark) {
		diffTime = (mark + lastMark) / 10;
      	milis = (diffTime % 100);
        diffTime = (diffTime - milis ) / 100; // segundos
        seconds= diffTime % 60;
        minutes= ((diffTime - seconds) / 60) % 60;
        hours = (diffTime - (minutes*60) - seconds) / 3600;
    }

	// Painting the data on screen on demand
    function PaintData(t) {
        bigNumObject[6].setProperty(hmUI.prop.SRC, img("SilverSm" + parseInt(milis / 10) + ".png"));
        bigNumObject[7].setProperty(hmUI.prop.SRC, img("SilverSm" + parseInt(milis % 10) + ".png"));
        bigNumObject[3].setProperty(hmUI.prop.SRC, img("SilverN" + parseInt(seconds / 10) + ".png"));
        bigNumObject[4].setProperty(hmUI.prop.SRC, img("SilverN" + parseInt(seconds % 10) + ".png"));
        bigNumObject[0].setProperty(hmUI.prop.SRC, img("SilverN" + parseInt(minutes / 10) + ".png"));
        bigNumObject[1].setProperty(hmUI.prop.SRC, img("SilverN" + parseInt(minutes % 10) + ".png"));
        bigNumObject[2].setProperty(hmUI.prop.SRC, img("SilverNS.png"));
        HoursObject[2].setProperty(hmUI.prop.SRC, img("SmallN" + parseInt(hours % 10) + ".png"));
        HoursObject[1].setProperty(hmUI.prop.SRC, img("SmallN" + parseInt((hours/10) % 10) + ".png"));
        HoursObject[0].setProperty(hmUI.prop.SRC, img("SmallN" + parseInt((hours/100) % 10) + ".png"));
		HoursObject[3].setProperty(hmUI.prop.SRC, img("Hours.png"));
 	}

	// Convenient macro
    function DispData(t) {
		CalcTime(now.utc - lastTime)
		PaintData()
    }

	// Start up timers
    function timerSample() {
      hsTimer = timer.createTimer(10, 10, DispData, {})
    }
	
	// show/hide main WF, maybe I modify this to allow several layers in the same WF.
	function ShowAll(lVisible) {
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_lock_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_dnd_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		
		normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_wind_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		
		for(let i=0;i<6;i++) WFTimeObj[i].setProperty(hmUI.prop.VISIBLE, lVisible && lDigital);
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, lVisible && lDigital);
		for(let i=0;i<5;i++) WFDateObj[i].setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		for(let i=0;i<3;i++) WFHRObj[i].setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		for(let i=0;i<6;i++) WFDistObj[i].setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
		for(let i=0;i<4;i++) WFBatObj[i].setProperty(hmUI.prop.VISIBLE, lVisible && lOther);

        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog!=4);
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog!=4);
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog!=4);
		AnalogDial.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0);
		
		Xsecond.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog==4);
		Xminute.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog==4);
		Xhour.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog==4);
		Xcenter.setProperty(hmUI.prop.VISIBLE, lVisible && nAnalog>0 && nAnalog==4);
		
		broken.setProperty(hmUI.prop.VISIBLE, lVisible && (nBroken>0));
		rndBall.setProperty(hmUI.prop.VISIBLE, lVisible && lAtom);
		rnd2Ball.setProperty(hmUI.prop.VISIBLE, lVisible && lAtom);

        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, lVisible && lDigital);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, lVisible && lDigital);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, lVisible && lOther);
	}
	

	function UpdateMenu(){
		if(!flag || (CounterVal[0]>0 || CounterVal[1]>0 || CounterVal[2]>0) || lPlaying)
			btnmenu.setProperty(hmUI.prop.MORE,{
			  x: 190*GTRRatio,
			  y: 380*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenured.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnmenu.setProperty(hmUI.prop.MORE,{
			  x: 190*GTRRatio,
			  y: 380*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenu.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
	}
	
	// Menu system is a very spaguetti dish... No object oriented programming here heheh 8-)
	function ShowMenu(lVisible) {
		if(!flag)
			btncrono.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncronoon.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btncrono.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncrono.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

		btncrono.setProperty(hmUI.prop.VISIBLE, lVisible);

		if (CounterVal[0]==0 && CounterVal[1]==0 && CounterVal[2]==0 )
			btncounter.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounter.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		else
			btncounter.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounteron.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		
		btncounter.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnmusic.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnAbout.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnTools.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnAtom.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnAtom.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnScroll.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnRes4.setProperty(hmUI.prop.VISIBLE, lVisible);

		//if(lVisible) SetMiniTime(164,18) // not required. At this moment Minitime is always at the same location.
		
		ShowMiniTime(lVisible);
		ShowMusic();
	}

	// Show the stopwatch wit BIG numbers for my presbyopia, that is the reason I hate wfs with very little details/numbers :-)
	// I think an ideal watch for me should be at 2.2 inches diameter ;-)))
	function ShowCrono(lVisible) {
		green_red_btn.setProperty(hmUI.prop.VISIBLE, lVisible);  
		bigNumObject[0].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[1].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[2].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[3].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[4].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[6].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[7].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[0].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[1].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[2].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[3].setProperty(hmUI.prop.VISIBLE, lVisible);

		if (lVisible) 
			clear.setProperty(hmUI.prop.VISIBLE, flag)
		else
			clear.setProperty(hmUI.prop.VISIBLE, false);


		if(flag && lVisible) { // está apagado, repintar los numeros
			CalcTime(0)
			PaintData()
			}	
		//if(lVisible) SetMiniTime(164,18);
		ShowMiniTime(lVisible);
		}

	function CreateCounters(){
		let xoffNum = 180*GTRRatio;
		let yoffNum = 64*GTRRatio;
		let numWidth = 75*GTRRatio;
		let numHeight = 105*GTRRatio;
		let xoffBtnSub = 70*GTRRatio;
		let yoffBtnSub = 25*GTRRatio;
		let xoffBtnAdd = 0*GTRRatio; 
		
		 btnCSub[0] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnsuby.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[0].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[0].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[0]>0) CounterVal[0]=CounterVal[0]-1;
			PaintCounters();
		}));
		 btnCAdd[0] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnaddy.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[0].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[0].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[0]<99) CounterVal[0]=CounterVal[0]+1;
			PaintCounters();
		}));

		 CounterObj[0] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[0].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[1] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[1].setProperty(hmUI.prop.VISIBLE, false);
		
		 btnCSub[1] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub+numHeight,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnsubg.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[1].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[1].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[1]>0) CounterVal[1]=CounterVal[1]-1;
			PaintCounters();
		}));
		 btnCAdd[1] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub+numHeight,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnaddg.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[1].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[1].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[1]<99) CounterVal[1]=CounterVal[1]+1;
			PaintCounters();
		}));


		 CounterObj[2] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum+numHeight,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[2].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[3] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum+numHeight,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[3].setProperty(hmUI.prop.VISIBLE, false);


		 btnCSub[2] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub+numHeight*2,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnsubb.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[2].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[2].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[2]>0) CounterVal[2]=CounterVal[2]-1;
			PaintCounters();
		}));
		 btnCAdd[2] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub+numHeight*2,
		  w: 80*GTRRatio,
		  h: 80*GTRRatio,
		  src: 'btnaddb.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[2].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[2].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[2]<99) CounterVal[2]=CounterVal[2]+1;
			PaintCounters();
		}));



		 CounterObj[4] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum+numHeight*2,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[4].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[5] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum+numHeight*2,
			  src: img('BigN0.png'),
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[5].setProperty(hmUI.prop.VISIBLE, false);

		resetCount = hmUI.createWidget(hmUI.widget.IMG, {
		  x: 100*GTRRatio,
		  y: 400*GTRRatio,
		  w: 40*GTRRatio,
		  h: 40*GTRRatio,
		  src: 'Clearmini.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		resetCount.setProperty(hmUI.prop.VISIBLE, false);
		resetCount.addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			if(!lResetPos) {
				lResetPos=true;
				SetResetPos();
				return;
			}
			for (let i = 0; i < 3; i += 1) CounterVal[i]=0;
			PaintCounters();
			lResetPos=false;
			SetResetPos();
		}));

	}

		
    function PaintCounters() {
        CounterObj[0].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[0] / 10) + ".png"));
        CounterObj[1].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[0] % 10) + ".png"));
        CounterObj[2].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[1] / 10) + ".png"));
        CounterObj[3].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[1] % 10) + ".png"));
        CounterObj[4].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[2] / 10) + ".png"));
        CounterObj[5].setProperty(hmUI.prop.SRC, img("BigN" + parseInt(CounterVal[2] % 10) + ".png"));
		UpdateMenu();
		StoreTempData();
	}
	
	// Force push alternate buttons changing position in the screen, this makes very unlikely an accidental reset. 
	// Every other button push returns the reset button to the start of the reset sequence for increased security.
	// I don't want to loose data I have been counting for hours or days...
	function SetResetPos(){
		if(lResetPos)
			resetCount.setProperty(hmUI.prop.MORE, {
			  x: (480-100-40)*GTRRatio,
			  y: 400*GTRRatio,
			  w: 40*GTRRatio,
			  h: 40*GTRRatio,
			  src: 'Clearmini.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			})
		else
			resetCount.setProperty(hmUI.prop.MORE, {
			  x: 100*GTRRatio,
			  y: 400*GTRRatio,
			  w: 40*GTRRatio,
			  h: 40*GTRRatio,
			  src: 'Clearmini.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
	}
	
	function ShowCounter(lVisible) {
		  for (let i = 0; i < 6; i += 1) CounterObj[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  for (let i = 0; i < 3; i += 1) btnCAdd[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  for (let i = 0; i < 3; i += 1) btnCSub[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  lResetPos=false;
		  resetCount.setProperty(hmUI.prop.VISIBLE, lVisible);
		  if(lVisible) SetResetPos();
		  if (lVisible) PaintCounters();
		  //if(lVisible) SetMiniTime(164,18);
		  ShowMiniTime(lVisible);
	}

	function click_Crono() {
		click_Vibrate();
		ShowMenu(false);
		currentmenu=2;
		ShowCrono(true);

	}
	
	function click_Counter() {
		click_Vibrate();
		ShowMenu(false);
		ShowCounter(true);
		currentmenu=3;
	}

	function click_Menu(){ // menu button always visible, used to return to main screen too
		click_Vibrate();
		if(currentmenu==0) {
			ShowAll(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==1) {
			ShowMenu(false);
			ShowAll(true);
			currentmenu=0;
			return;
		}
		if(currentmenu==2) {
			ShowCrono(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==3) {
			ShowCounter(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==4) {
			ShowAbout(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==5) {
			ShowTools(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==8) {
			ShowRes4(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
	}

	// Button feedback
	function click_Vibrate() {
		if(!lVibrate) return;
		vibrate.stop();
		vibrate.scene = 24;
		vibrate.start();
	}

	function UpdateBall(){
		if(currentmenu>0 || !lAtom) return;
		if(rndHold>0)
		{
			rndHold=rndHold-1;
			return;
		}
		let maxradius=220;
		
		let nextX=rndBallX+Math.cos(rndBallDir)*speed1;
		let nextY=rndBallY+Math.sin(rndBallDir)*speed1;
		let radius=Math.sqrt((nextX-240)*(nextX-240)+
						(nextY-240)*(nextY-240));
		let nInd=radius-180;
		let sr=40;
		
		if(nInd>40) nInd=39;
		if(nInd<0)
			nInd=0
		else
			nInd=Math.floor(nInd/4); // 0..9
						
		if(radius>maxradius){
			let angulo=Math.asin((rndBallY-240)/radius); // angle between +pi/2 , -pi/2
			if((nextX-240)<0) angulo=Math.PI-angulo;
			let rang=(now.utc % 5) / 360; // some random magic...
			rndBallDir=rndBallDir+(Math.PI-2*(rndBallDir-angulo))+rang;
		}
		rndBallX=rndBallX+Math.cos(rndBallDir)*speed1;
		rndBallY=rndBallY+Math.sin(rndBallDir)*speed1;

		let nextX2=rnd2BallX+Math.cos(rnd2BallDir)*speed2;
		let nextY2=rnd2BallY+Math.sin(rnd2BallDir)*speed2;
		let radius2=Math.sqrt((nextX2-240)*(nextX2-240)+
						(nextY2-240)*(nextY2-240));
		let nInd2=radius2-180;
		let sr2=40;
		
		if(nInd2>40) nInd2=39;
		if(nInd2<0)
			nInd2=0
		else
			nInd2=Math.floor(nInd2/4); // 0..9
		

		if(radius2>maxradius){
			let angulo2=Math.asin((rnd2BallY-240)/radius2); // angle between +pi/2 , -pi/2
			if((nextX2-240)<0) angulo2=Math.PI-angulo2;
			let rang2=(now.utc % 5) / 360; // some random magic...
			rnd2BallDir=rnd2BallDir+(Math.PI-2*(rnd2BallDir-angulo2))-rang2;
		}
		rnd2BallX=rnd2BallX+Math.cos(rnd2BallDir)*speed2;
		rnd2BallY=rnd2BallY+Math.sin(rnd2BallDir)*speed2;

		// Simple interaction, we'll see magnetism later...
		let distp=(rndBallX-rnd2BallX)*(rndBallX-rnd2BallX)+(rndBallY-rnd2BallY)*(rndBallY-rnd2BallY);
		distp=Math.sqrt(distp);
		let distInter=300;
		let repulse=1;
		if(distp<distInter && distp>0)
		{
			// interaction active, color change particles
			nInd=9-Math.floor(distp/(distInter/10));
			nInd2=nInd;
			// Vector repulsive/attractive force, acts only on speed vector, not modulus.
			// this way we don't speed up/down particles
			// Deltas:
			let module=Math.sqrt(((distInter-distp)*(distInter-distp))/(distInter*distInter))*15;
			let vx=-module*(rndBallX-rnd2BallX)/distp; // normal vector force
			let vy=-module*(rndBallY-rnd2BallY)/distp;
			
			// Speed vector + delta
			let vx1=distp*Math.cos(rndBallDir)+vx*repulse;
			let vy1=distp*Math.sin(rndBallDir)+vy*repulse;
			// normalize
			let mm1=Math.sqrt((vx1*vx1)+(vy1*vy1));
			if(mm1>0) // Avoid indeterm.
			{
				vx1=vx1/mm1;
				vy1=vy1/mm1;
				// Get new angle
				let angle1=Math.asin(vy1);
				if(vx1<0) angle1=Math.PI-angle1;
				rndBallDir=angle1;
				speed1=5+((distInter-distp)*15)/distInter;
				if(speed1>20) speed1=20;
				if(speed1<2) speed1=2;
			}
			// Speed vector - delta, 2nd particle, opposite force, half mass
			let vx2=distp*Math.cos(rnd2BallDir)-vx*repulse;
			let vy2=distp*Math.sin(rnd2BallDir)-vy*repulse;
			// normalize
			let mm2=Math.sqrt((vx2*vx2)+(vy2*vy2));
			if(mm2>0) // avoid indetermination
			{
				vx2=vx2/mm2;
				vy2=vy2/mm2;
				// Get new angle
				let angle2=Math.asin(vy2);
				if(vx2<0) angle2=Math.PI-angle2;
				rnd2BallDir=angle2;
				speed2=5+((distInter-distp)*15)/distInter;
				if(speed2>20) speed2=20;
				if(speed2<2) speed2=2;
			}
		}

		if(nInd==7) sr=50;
		if(nInd==8) sr=60;
		if(nInd==9) sr=70;
		if(nInd2==7) sr2=50;
		if(nInd2==8) sr2=60;
		if(nInd2==9) sr2=70;

		RandIterations=RandIterations+1;
		let lExplode=false;
		if(distp<15 || distp>480 || (RandIterations>2000) || radius>245 || radius2>245)
		{
			nInd=10;
			nInd2=10;
			sr=150;
			sr2=150;
			lExplode=true;
			rndHold=2; // hold explossion 0.05sec so the eye can see it...
		}
		rnd2Ball.setProperty(hmUI.prop.MORE, {
              x: (rnd2BallX-sr2/2)*GTRRatio,
              y: (rnd2BallY-sr2/2)*GTRRatio,
              w: sr2*GTRRatio,
              h: sr2*GTRRatio,
              src: 'rnd2Ball' + parseInt(nInd2) +'.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		rndBall.setProperty(hmUI.prop.MORE, {
              x: (rndBallX-sr/2)*GTRRatio,
              y: (rndBallY-sr/2)*GTRRatio,
              w: sr*GTRRatio,
              h: sr*GTRRatio,
              src: 'rndBall' + parseInt(nInd) +'.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		if(lExplode) RandBall(); // Explode, new pair
	}

	function CreateWatch(){
		let xx;
		let yy;
		let nspc;
		
            let screenType = hmSetting.getScreenType();
		
			normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'Back0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			UpdateBackground();

			xx=12*GTRRatio;
			yy=168*GTRRatio;
			nspc=5*GTRRatio;
			// 80x140 font
			WFTimeObj[5]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*80*GTRRatio, y: yy, src: img('SilverN0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[4]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*80*GTRRatio+nspc, y: yy, src: img('SilverN0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

			xx=214*GTRRatio;
			yy=168*GTRRatio;
			nspc=5*GTRRatio;
			WFTimeObj[3]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*80*GTRRatio, y: yy, src: img('SilverN0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*80*GTRRatio+nspc, y: yy, src: img('SilverN0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

			xx=382*GTRRatio;
			yy=246*GTRRatio;
			nspc=0; // Secs, 43x60 font
			WFTimeObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*43*GTRRatio, y: yy, src: img('SilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*43*GTRRatio+nspc, y: yy, src: img('SilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185*GTRRatio,
              y: 168*GTRRatio,
              src: img('SilverNS.png'),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194*GTRRatio,
              y: 344*GTRRatio,
              src: img('BatBK.png'),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			xx=100*GTRRatio;
			yy=394*GTRRatio;
			nspc=0; // Bat percent, 22x36 font
			WFBatObj[3]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*22*GTRRatio, y: yy, src: img('LCDSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFBatObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*22*GTRRatio+nspc, y: yy, src: img('LCDSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFBatObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+2*22*GTRRatio+2*nspc, y: yy, src: img('LCDSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFBatObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+3*22*GTRRatio+3*nspc, y: yy, src: img('percent.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

			normal_battery_image_progress_img_level=hmUI.createWidget(hmUI.widget.IMG, {
					x: 198*GTRRatio, y: 347*GTRRatio, src: img('Bat0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432*GTRRatio,
              y: 210*GTRRatio,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392*GTRRatio,
              y: 210*GTRRatio,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392*GTRRatio,
              y: 174*GTRRatio,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432*GTRRatio,
              y: 176*GTRRatio,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG, {
				x: 297*GTRRatio,
				y: 383*GTRRatio,
				src: img('dia0.png'),
				show_level: hmUI.show_level.ONLY_NORMAL
			});

			xx=300*GTRRatio;
			yy=335*GTRRatio;
			nspc=0;
			// 29x40 font
			WFDateObj[4]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*29*GTRRatio, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDateObj[3]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*29*GTRRatio+nspc, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDateObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+2*29*GTRRatio+2*nspc-2, y: yy, src: img('SSilverSmM.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			xx=378*GTRRatio;
			yy=335*GTRRatio;
			nspc=0;
			// 29x40 font
			WFDateObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*29*GTRRatio, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDateObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*29*GTRRatio+nspc, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});

			xx=75*GTRRatio;
			yy=335*GTRRatio;
			nspc=0;
			// 29x40 font
			WFHRObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*29*GTRRatio, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFHRObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*29*GTRRatio+nspc, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFHRObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+2*29*GTRRatio+2*nspc, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});


			xx=30*GTRRatio;
			yy=122*GTRRatio;
			nspc=0;
			// 29x40 font
			WFDistObj[5]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*29*GTRRatio, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDistObj[4]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*29*GTRRatio+nspc, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDistObj[3]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+2*29*GTRRatio+2*nspc, y: yy, src: img('punto.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDistObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+3*29*GTRRatio+nspc-19, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDistObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+4*29*GTRRatio+nspc-19, y: yy, src: img('SSilverSm0.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFDistObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+5*29*GTRRatio+nspc-19, y: yy, src: img('Km.png'),
					show_level: hmUI.show_level.ONLY_NORMAL});
			// sub 19 because dot is only 10px
            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35*GTRRatio,
              y: 336*GTRRatio,
              src: img('heart.png'),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92*GTRRatio,
              y: 42*GTRRatio,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176*GTRRatio,
              y: 30*GTRRatio,
              src: 'Climaback.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197*GTRRatio,
              y: 46*GTRRatio,
              font_array: ["0-SSilverSm0.png","0-SSilverSm1.png","0-SSilverSm2.png","0-SSilverSm3.png","0-SSilverSm4.png","0-SSilverSm5.png","0-SSilverSm6.png","0-SSilverSm7.png","0-SSilverSm8.png","0-SSilverSm9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0-Grados.png',
              unit_tc: '0-Grados.png',
              unit_en: '0-Grados.png',
              negative_image: '0-SSilverSmM.png',
              invalid_image: '0-Err.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 322*GTRRatio,
              y: 64*GTRRatio,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251*GTRRatio,
              y: 90*GTRRatio,
              src: 'Humedad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255*GTRRatio,
              y: 108*GTRRatio,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194*GTRRatio,
              y: 90*GTRRatio,
              src: 'Wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 196*GTRRatio,
              y: 108*GTRRatio,
              image_array: ["WSpeed0.png","WSpeed1.png","WSpeed2.png","WSpeed3.png","WSpeed4.png"],
              image_length: 5,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Mhour.png',
              hour_centerX: 241*GTRRatio,
              hour_centerY: 240*GTRRatio,
              hour_posX: 109*GTRRatio,
              hour_posY: 206*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Mmin.png',
              minute_centerX: 241*GTRRatio,
              minute_centerY: 240*GTRRatio,
              minute_posX: 95*GTRRatio,
              minute_posY: 240*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Msec.png',
              second_centerX: 241*GTRRatio,
              second_centerY: 240*GTRRatio,
              second_posX: 165*GTRRatio,
              second_posY: 227*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			

	}		


	function CreateAOD(){
					idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432*GTRRatio,
              y: 210*GTRRatio,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392*GTRRatio,
              y: 210*GTRRatio,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392*GTRRatio,
              y: 174*GTRRatio,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432*GTRRatio,
              y: 176*GTRRatio,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12*GTRRatio,
              hour_startY: 168*GTRRatio,
              hour_array: ["2-SilverN0.png","2-SilverN1.png","2-SilverN2.png","2-SilverN3.png","2-SilverN4.png","2-SilverN5.png","2-SilverN6.png","2-SilverN7.png","2-SilverN8.png","2-SilverN9.png"],
              hour_zero: 1,
              hour_space: 5*GTRRatio,
              hour_unit_sc: '2-SilverNS.png',
              hour_unit_tc: '2-SilverNS.png',
              hour_unit_en: '2-SilverNS.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 214*GTRRatio,
              minute_startY: 168*GTRRatio,
              minute_array: ["2-SilverN0.png","2-SilverN1.png","2-SilverN2.png","2-SilverN3.png","2-SilverN4.png","2-SilverN5.png","2-SilverN6.png","2-SilverN7.png","2-SilverN8.png","2-SilverN9.png"],
              minute_zero: 1,
              minute_space: 5*GTRRatio,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 382*GTRRatio,
              second_startY: 246*GTRRatio,
              second_array: ["2-SilverSm0.png","2-SilverSm1.png","2-SilverSm2.png","2-SilverSm3.png","2-SilverSm4.png","2-SilverSm5.png","2-SilverSm6.png","2-SilverSm7.png","2-SilverSm8.png","2-SilverSm9.png"],
              second_zero: 1,
              second_space: 2*GTRRatio,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });
			
			idle_broken = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'bglass2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });
			idle_broken.setProperty(hmUI.prop.VISIBLE, (nBroken==1));

			idle_broken2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'dropped.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });
			idle_broken2.setProperty(hmUI.prop.VISIBLE, (nBroken==2));
	}
	
	function RandBall()
	{// no need for gtrratio, scaled in the draw function
		let randy=now.utc;
		rndBallX = 100;
		rndBallY = 240;
		rndBallDir= (randy % 360);
		rnd2BallX = 380;
		rnd2BallY = 240;
		rnd2BallDir= (randy / 360) % 360;
		RandIterations=0;
		speed1=10+randy % 5;
		speed2=10+(randy / 10) % 5;
	}

	// Calculate a string with current config
	function CalcConfig(){
		let cC='';
		let cT='';

		// 0-99 background
		cT='00'+parseInt(Numfondo); // At least 3 chars
		cT=cT.substr(cT.length-2)
		cC=cC+cT;

		// 0-16 Fore
		cT='00'+parseInt(NumLetras); // At least 3 chars
		cT=cT.substr(cT.length-2)
		cC=cC+cT;

		// 0-6 nAnalog
		cC=cC+parseInt(nAnalog); // 1 char

		// 0-1 digital
		if(lDigital)
			cT='1';
		else
			cT='0';
		cC=cC+cT; // 1 char

		// 0-1 other
		if(lOther)
			cT='1';
		else
			cT='0';
		cC=cC+cT; // 1 char

		// 0-1 scroll
		if(lAnimSec)
			cT='1';
		else
			cT='0';
		cC=cC+cT; // 1 char

		// 0-1 atoms
		if(lAtom)
			cT='1';
		else
			cT='0';
		cC=cC+cT; // 1 char

		return cC;
	}

	function ApplyPreset(nPreset){
		click_Vibrate();
		let cC=Presets[nPreset];
		if(cC=='' || cC==null){
			hmUI.showToast({text: 'EMPTY PRESET'});
			return;
		}
		if(cC.length!=9){
			hmUI.showToast({text: 'INVALID PRESET'});
			return;
		}
		
		Numfondo = Number(cC.substr(0,2));
		NumLetras = Number(cC.substr(2,2));
		nAnalog = Number(cC.substr(4,1));
		lDigital = (cC.substr(5,1)=='1');
		lOther = (cC.substr(6,1)=='1');
		lAnimSec = (cC.substr(7,1)=='1');
		lAtom = (cC.substr(8,1)=='1');
		
		UpdateBackground();
		UpdateLayout();
		UpdateAnalog();
		UpdateDigital();
		UpdateOther();
		UpdateAtom();
		UpdateScroll();
		hmUI.showToast({text: 'Preset ' + parseInt(nPreset+1) + ' applied.'});
	}

	function click_Preset(nPreset){
		click_Vibrate();
		if(lStoreFlag){
			Presets[nPreset-1]=CalcConfig();
			lStoreFlag=false;
			UpdateStoreFlag();
			hmUI.showToast({text: 'Preset ' + parseInt(nPreset) + ' STORED.'});
		}
		else{
			ApplyPreset(nPreset-1);
		}
		StoreTempData();	
	}

	function click_StorONOFF(){
		click_Vibrate();
		lStoreFlag=!lStoreFlag;
		UpdateStoreFlag();
	}
	
	function UpdateStoreFlag(){
		if(lStoreFlag){
			btnStoreFlag.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnStorON.png',
			  press_src: 'btnStorON.png',
			  click_func: () => {
				click_StorONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset1.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset1S.png',
			  press_src: 'btnPreset1S.png',
			  click_func: () => {
				click_Preset(1);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset2.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset2S.png',
			  press_src: 'btnPreset2S.png',
			  click_func: () => {
				click_Preset(2);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset3.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset3S.png',
			  press_src: 'btnPreset3S.png',
			  click_func: () => {
				click_Preset(3);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		}
		else{
			btnStoreFlag.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnStorOFF.png',
			  press_src: 'btnStorOFF.png',
			  click_func: () => {
				click_StorONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset1.setProperty(hmUI.prop.MORE, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset1.png',
			  press_src: 'btnPreset1.png',
			  click_func: () => {
				click_Preset(1);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset2.setProperty(hmUI.prop.MORE, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset2.png',
			  press_src: 'btnPreset2.png',
			  click_func: () => {
				click_Preset(2);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset3.setProperty(hmUI.prop.MORE, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset3.png',
			  press_src: 'btnPreset3.png',
			  click_func: () => {
				click_Preset(3);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		}

	}
	
        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
			LoadTempData();
			RandBall();

            let screenType = hmSetting.getScreenType();
//			if(screenType==hmSetting.screen_type.AOD) {
				CreateAOD();
//				return;
//				}
			  
  			for (let i = 0; i < 3; i += 1) CounterVal[i]=0;
			music.audInit();
			CreateWatch();

	imgabout = hmUI.createWidget(hmUI.widget.IMG, {
          x: ((480-350)/2)*GTRRatio,
          y: ((480-238)/2)*GTRRatio,
          src: 'about.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     imgabout.setProperty(hmUI.prop.VISIBLE, false);


	HoursObject[0] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 150*GTRRatio,
          y: 60*GTRRatio,
          src: img('SmallN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[0].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[1] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 200*GTRRatio,
          y: 60*GTRRatio,
          src: img('SmallN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[1].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[2] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 250*GTRRatio,
          y: 60*GTRRatio,
          src: img('SmallN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[2].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[3] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 295*GTRRatio,
          y: 60*GTRRatio,
          src: img('Hours.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[3].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[2] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 224*GTRRatio,
          y: 160*GTRRatio,
          src: img('SilverNS.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[2].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[0] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 46*GTRRatio,
          y: 168*GTRRatio,
          src: img('SilverN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[0].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[1] = hmUI.createWidget(hmUI.widget.IMG, {
          x: (46+80+10)*GTRRatio,
          y: 168*GTRRatio,
          src: img('SilverN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[1].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[3] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 260*GTRRatio,
          y: 168*GTRRatio,
          src: img('SilverN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[3].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[4] = hmUI.createWidget(hmUI.widget.IMG, {
          x: (260+80+10)*GTRRatio,
          y: 168*GTRRatio,
          src: img('SilverN0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[4].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[6] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 196*GTRRatio,
          y: 316*GTRRatio,
          src: img('SilverSm0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[6].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[7] = hmUI.createWidget(hmUI.widget.IMG, {
          x: (196+43+5)*GTRRatio,
          y: 316*GTRRatio,
          src: img('SilverSm0.png'),
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[7].setProperty(hmUI.prop.VISIBLE, false);

	

			// layout: 60-100-30-100-30-100-60
			btncrono = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncrono.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btncrono.setProperty(hmUI.prop.VISIBLE, false);

			btncounter = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounter.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btncounter.setProperty(hmUI.prop.VISIBLE, false);

			btnmusic = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusic.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			btnmusic.setProperty(hmUI.prop.VISIBLE, false);

			btnbackgroundP = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'backgroundP.png',
			  press_src: 'backgroundP.png',
			  click_func: () => {
				click_BackgroundP();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnbackgroundP.setProperty(hmUI.prop.VISIBLE, false);
			btnbackgroundN = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'backgroundN.png',
			  press_src: 'backgroundN.png',
			  click_func: () => {
				click_BackgroundN();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnbackgroundN.setProperty(hmUI.prop.VISIBLE, false);


			btnforeP = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'foregroundP.png',
			  press_src: 'foregroundP.png',
			  click_func: () => {
				click_foreP();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnforeP.setProperty(hmUI.prop.VISIBLE, false);
			btnforeN = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'foregroundN.png',
			  press_src: 'foregroundN.png',
			  click_func: () => {
				click_foreN();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnforeN.setProperty(hmUI.prop.VISIBLE, false);

			btnAbout = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnReserved.png',
			  press_src: 'btnReserved.png',
			  click_func: () => {
				click_About();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnAbout.setProperty(hmUI.prop.VISIBLE, false);

			btnVibrate = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnVibON.png',
			  press_src: 'btnVibON.png',
			  click_func: () => {
				click_VIBONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnVibrate.setProperty(hmUI.prop.VISIBLE, false);
			UpdateVib();

			btnBroken = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBrokON.png',
			  press_src: 'btnBrokON.png',
			  click_func: () => {
				click_BrokONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnBroken.setProperty(hmUI.prop.VISIBLE, false);

			btnTools = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnTools.png',
			  press_src: 'btnTools.png',
			  click_func: () => {
				click_Tools();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnTools.setProperty(hmUI.prop.VISIBLE, false);

			btnRandom = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnRandom.png',
			  press_src: 'btnRandom.png',
			  click_func: () => {
				click_Random();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnRandom.setProperty(hmUI.prop.VISIBLE, false);

			btnAnalog = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'AnalogOFF.png',
			  press_src: 'AnalogOFF.png',
			  click_func: () => {
				click_Analog();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnAnalog.setProperty(hmUI.prop.VISIBLE, false);

			btnPreset1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset1.png',
			  press_src: 'btnPreset1.png',
			  click_func: () => {
				click_Preset(1);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset1.setProperty(hmUI.prop.VISIBLE, false);

			btnPreset2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset2.png',
			  press_src: 'btnPreset2.png',
			  click_func: () => {
				click_Preset(2);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset2.setProperty(hmUI.prop.VISIBLE, false);

			btnPreset3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnPreset3.png',
			  press_src: 'btnPreset3.png',
			  click_func: () => {
				click_Preset(3);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnPreset3.setProperty(hmUI.prop.VISIBLE, false);

			btnStoreFlag = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 300*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnStorOFF.png',
			  press_src: 'btnStorOFF.png',
			  click_func: () => {
				click_StorONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnStoreFlag.setProperty(hmUI.prop.VISIBLE, false);

			btnOther = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnOtherOFF.png',
			  press_src: 'btnOtherOFF.png',
			  click_func: () => {
				click_Other();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnOther.setProperty(hmUI.prop.VISIBLE, false);
			UpdateOther();

			btnDigital = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnDigitalOFF.png',
			  press_src: 'btnDigitalOFF.png',
			  click_func: () => {
				click_Digital();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnDigital.setProperty(hmUI.prop.VISIBLE, false);
			UpdateDigital();

			btnLang = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 80*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnLang.png',
			  press_src: 'btnLang.png',
			  click_func: () => {
				click_Lang();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnLang.setProperty(hmUI.prop.VISIBLE, false);

			btnAtom = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnAtomOFF.png',
			  press_src: 'btnAtomOFF.png',
			  click_func: () => {
				click_AtomONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnAtom.setProperty(hmUI.prop.VISIBLE, false);
			UpdateAtom();

			btnScroll = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnScrollOFF.png',
			  press_src: 'btnScrollOFF.png',
			  click_func: () => {
				click_ScrollONOFF();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnScroll.setProperty(hmUI.prop.VISIBLE, false);
			UpdateScroll();

			btnRes4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320*GTRRatio,
			  y: 190*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'bbWhite.png',
			  press_src: 'bbWhite.png',
			  click_func: () => {
				click_Res4();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnRes4.setProperty(hmUI.prop.VISIBLE, false);

			clear = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 328*GTRRatio,
			  y: 334*GTRRatio,
			  src: 'clear.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			clear.setProperty(hmUI.prop.VISIBLE, false);
			clear.addEventListener(hmUI.event.CLICK_UP, (function (info) {
				click_Vibrate();
				if (!flag) {
					timer.stopTimer(hsTimer);
					hsTimer=null;
					}
				flag=true
				green_red_btn.setProperty(hmUI.prop.SRC, "green.png"); 
				lastMark=0
				lastTime=0
				CalcTime(lastTime)
				PaintData()
				UpdateMenu();
			}));


			green_red_btn = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 72*GTRRatio,
			  y: 334*GTRRatio,
			  src: 'green.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			green_red_btn.setProperty(hmUI.prop.VISIBLE, false);
			green_red_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
				click_Vibrate();
			  flag = !flag
			  if (flag) {
				timer.stopTimer(hsTimer);
				hsTimer=null;
				green_red_btn.setProperty(hmUI.prop.SRC, "green.png"); 
				tmpMark = now.utc - lastTime
				CalcTime(tmpMark)
				PaintData()
				lastMark = lastMark + tmpMark;
				clear.setProperty(hmUI.prop.VISIBLE, true);
			  } else {
				green_red_btn.setProperty(hmUI.prop.SRC, "red.png");
				lastTime=now.utc;
				timerSample()
				clear.setProperty(hmUI.prop.VISIBLE, false);
			  }
				UpdateMenu();
			}));

			
		 Xhour = hmUI.createWidget(hmUI.widget.IMG, {
              src: 'HR.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: (240-40)*GTRRatio,
              pos_y: 100*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		 Xminute = hmUI.createWidget(hmUI.widget.IMG, {
              src: 'MG.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: (240-35)*GTRRatio,
              pos_y: 50*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		 Xsecond = hmUI.createWidget(hmUI.widget.IMG, {
              src: 'SB.png',
              center_x: 240*GTRRatio,
              center_y: 240*GTRRatio,
              pos_x: (240-25)*GTRRatio,
              pos_y: 20*GTRRatio,
			  x:0,
			  y:0,
			  w:480*GTRRatio,
			  h:480*GTRRatio,
			  angle:0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		 Xcenter = hmUI.createWidget(hmUI.widget.IMG, {
              src: 'center.png',
			  x:220*GTRRatio,
			  y:220*GTRRatio,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			AnalogDial = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'AnalogDial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			UpdateAnalog();
			
			rnd2Ball = hmUI.createWidget(hmUI.widget.IMG, {
              x: (rnd2BallX-20)*GTRRatio,
              y: (rnd2BallY-20)*GTRRatio,
              w: 40*GTRRatio,
              h: 40*GTRRatio,
              src: 'rndBall1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			rndBall = hmUI.createWidget(hmUI.widget.IMG, {
              x: (rndBallX-20)*GTRRatio,
              y: (rndBallY-20)*GTRRatio,
              w: 40*GTRRatio,
              h: 40*GTRRatio,
              src: 'rndBall1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			UpdateBall();

			broken = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480*GTRRatio,
              h: 480*GTRRatio,
              src: 'bglass2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			UpdateBroken();

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375*GTRRatio,
              y: 241*GTRRatio,
              w: 100*GTRRatio,
              h: 70*GTRRatio,
              src: 'Shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374*GTRRatio,
              y: 154*GTRRatio,
              w: 100*GTRRatio,
              h: 69*GTRRatio,
              src: 'Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195*GTRRatio,
              y: 38*GTRRatio,
              w: 100*GTRRatio,
              h: 100*GTRRatio,
              src: 'Shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60*GTRRatio,
              y: 332*GTRRatio,
              w: 100*GTRRatio,
              h: 60*GTRRatio,
              src: 'Shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30*GTRRatio,
              y: 114*GTRRatio,
              w: 139*GTRRatio,
              h: 58*GTRRatio,
              src: 'Shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




click_Vibrate(); // Llegará hasta aqui?
			
			// no other way than put this on top in order to be pressed.
			btnmenu = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190*GTRRatio,
			  y: 380*GTRRatio,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenu.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			CreateCounters();
			PaintCounters();
			CreateMiniTime();
			SetMiniTime(164,18);
			PaintWeekDay();

			ShowAll(true);
			MainTimer = timer.createTimer(50, 50, PaintMain, {}); // Watchface timer
			PartTimer = timer.createTimer(50, 50, UpdateBall, {}); // Particles time
			// This allows to take actions when screen activates/deactivates in the wf
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
					lWFActive=true;
					PaintMain();
              }),
              pause_call: (function () {
				lWFActive=false;
				nAnimFrameSec=-1;
				nAnimFrameMin=-1;
				nAnimFrameHour=-1;
				lRedrawTime=true;
				nRetOther=1000;
             }),
            });

          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
			vibrate.stop();
			timer.stopTimer(MainTimer);
			timer.stopTimer(PartTimer);
			if(hsTimer) timer.stopTimer(hsTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  