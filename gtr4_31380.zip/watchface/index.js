﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_fat_burning_icon_img = ''
        // let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
		
						let btn_zona1 = ''
		let zona1_num = 0
		let zona1_all = 2
		
		function click_zona1() {
		zona1_num = (zona1_num + 1) % (zona1_all + 1);
		if (zona1_num == 0) {
        normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'Батарея ВКЛ'
        });
      };

		if (zona1_num == 1) {
        normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'ЧСС ВКЛ'
        });
      };
            
		if (zona1_num == 2) {
        normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'Шаги ВКЛ'
        });
      };
    }
	
			let btn_zona2 = ''
		let zona2_num = 0
		let zona2_all = 2
		
		function click_zona2() {
		zona2_num = (zona2_num + 1) % (zona2_all + 1);
		if (zona2_num == 0) {
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'Батарея ВКЛ'
        });
      };
	  
		if (zona2_num == 1) {
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'Батарея ВКЛ'
        });
      };

		if (zona2_num == 2) {
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'Батарея ВКЛ'
        });
      };
	}


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Main_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 33,
              y: 33,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "leftanim",
              anim_fps: 31,
              anim_size: 62,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 162,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 162,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 370,
              src: 'pwr_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 394,
              font_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 370,
              src: 'hr_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 394,
              font_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 370,
              src: 'steps_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 394,
              font_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 58,
              day_sc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_tc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_en_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 84,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 188,
              year_startY: 58,
              year_sc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_tc_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_en_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 84,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 40,
              src: 'weather_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 86,
              font_array: ["Numbers_S_00.png","Numbers_S_01.png","Numbers_S_02.png","Numbers_S_03.png","Numbers_S_04.png","Numbers_S_05.png","Numbers_S_06.png","Numbers_S_07.png","Numbers_S_08.png","Numbers_S_09.png"],
              padding: false,
              h_space: -1,
              negative_image: 'Numbers_S_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 86,
              font_array: ["Numbers_S_00.png","Numbers_S_01.png","Numbers_S_02.png","Numbers_S_03.png","Numbers_S_04.png","Numbers_S_05.png","Numbers_S_06.png","Numbers_S_07.png","Numbers_S_08.png","Numbers_S_09.png"],
              padding: false,
              h_space: -1,
              negative_image: 'Numbers_S_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 58,
              font_array: ["Numbers_L_00.png","Numbers_L_01.png","Numbers_L_02.png","Numbers_L_03.png","Numbers_L_04.png","Numbers_L_05.png","Numbers_L_06.png","Numbers_L_07.png","Numbers_L_08.png","Numbers_L_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Numbers_L_C.png',
              unit_tc: 'Numbers_L_C.png',
              unit_en: 'Numbers_L_C.png',
              negative_image: 'Numbers_L_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// SMOOTH SECONDS Definition
        let second_centerX = 233;
        let second_centerY = 233;
        let second_posX = 24;
        let second_posY = 234;
        let second_path = "Hands_second.png";
        // ----------------------------
        let sec_pointer;
        let clock_timer;
        let animAngle = 0;
        let animDelay = 0;
        const animFps = 30;                             // Frames per second 
        const animRepeat = 1000 / animFps;              // then execute every <animRepeat>ms
        const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection
        // SMOOTH SECONDS Definition End

        sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: second_centerX - second_posX,
          pos_y: second_centerY - second_posY,
          center_x: second_centerX,
          center_y: second_centerY,
          src: second_path,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let bazel = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'dote.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const now = hmSensor.createSensor(hmSensor.id.TIME);

        const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('ui resume');

            if (!clock_timer) {
              console.log('createTimer');
              clock_timer = timer.createTimer(animDelay, animRepeat, (function (option) {
                animAngle = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);
                sec_pointer.setProperty(hmUI.prop.ANGLE, animAngle);
              }));
            }
          }),
          pause_call: (function () {
            console.log('ui pause');
            if (clock_timer) {
              timer.stopTimer(clock_timer);
              clock_timer = undefined;
              console.log('stopTimer');
            }
          }),

        });
        // End Smooth Seconds

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 394,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Main_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 162,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 162,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 394,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
			
							btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			x: 144, //x кнопки
			y: 350, //y кнопки
			text: '',
			w: 179, //ширина кнопки
			h: 97, //высота кнопки
			normal_src: 'click_e.png',
			press_src: 'click_e.png',
			click_func: () => {
            click_zona1();
            click_Vibrate(); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

        normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		
					btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			x: 145, //x кнопки
			y: 35, //y кнопки
			text: '',
			w: 177, //ширина кнопки
			h: 89, //высота кнопки
			normal_src: 'click_e.png',
			press_src: 'click_e.png',
			click_func: () => {
            click_zona2();
            click_Vibrate(); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
