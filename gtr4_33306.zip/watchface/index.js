﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_stress_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_calorie_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'index_modern03 (Custom).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 205,
              src: 'mini_back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 356,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 232,
              // center_y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 236,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 232,
              center_y: 232,
              start_angle: 0,
              end_angle: 360,
              radius: 234,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 203,
              font_array: ["digi_size4.5_along_001.png","digi_size4.5_along_002.png","digi_size4.5_along_003.png","digi_size4.5_along_004.png","digi_size4.5_along_005.png","digi_size4.5_along_006.png","digi_size4.5_along_007.png","digi_size4.5_along_008.png","digi_size4.5_along_009.png","digi_size4.5_along_010.png"],
              padding: false,
              h_space: -31,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 99,
              y: 193,
              src: 'icon_step_lightgrey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: -20,
              src: 'mark.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 64,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 247,
              font_array: ["digi_size4.5_along_001.png","digi_size4.5_along_002.png","digi_size4.5_along_003.png","digi_size4.5_along_004.png","digi_size4.5_along_005.png","digi_size4.5_along_006.png","digi_size4.5_along_007.png","digi_size4.5_along_008.png","digi_size4.5_along_009.png","digi_size4.5_along_010.png"],
              padding: false,
              h_space: -32,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 230,
              image_array: ["battry_small_red_0001.png","battry_small_red_0002.png","battry_small_red_0003.png","battry_small_red_0004.png","battry_small_red_0005.png","battry_small_red_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 369,
              day_startY: 202,
              day_sc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_tc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_en_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_zero: 0,
              day_space: -49,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 315,
              y: 208,
              week_en: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_tc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_sc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0020h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0020m.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0020s.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 8,
              second_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'index_modern03 (Custom).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 356,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: -17,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0020h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0020m.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 22,
              minute_posY: 201,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0020s.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 8,
              second_posY: 213,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 232,
                      center_y: 232,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 234,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}