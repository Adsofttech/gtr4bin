﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let idle_system_disconnect_img = ''
        let idle_calorie_icon_img = ''
        let timeSensor = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0017.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 233,
              center_y: 410,
              x: 8,
              y: 247,
              start_angle: -14,
              end_angle: 14,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 415,
              day_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0003.png',
              // center_x: 72,
              // center_y: 318,
              // x: 14,
              // y: 113,
              // start_angle: -30,
              // end_angle: 150,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 72 - 14,
              pos_y: 318 - 113,
              center_x: 72,
              center_y: 318,
              src: '0003.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0004.png',
              // center_x: 393,
              // center_y: 318,
              // x: 14,
              // y: 113,
              // start_angle: -150,
              // end_angle: 30,
              // cover_path: '0005.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 393 - 14,
              pos_y: 318 - 113,
              center_x: 393,
              center_y: 318,
              src: '0004.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0005.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 22,
              src: '0018.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0017.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 233,
              center_y: 410,
              x: 8,
              y: 247,
              start_angle: -14,
              end_angle: 14,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 415,
              day_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0003.png',
              // center_x: 72,
              // center_y: 318,
              // x: 14,
              // y: 113,
              // start_angle: -30,
              // end_angle: 150,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 72 - 14,
              pos_y: 318 - 113,
              center_x: 72,
              center_y: 318,
              src: '0003.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0004.png',
              // center_x: 393,
              // center_y: 318,
              // x: 14,
              // y: 113,
              // start_angle: -150,
              // end_angle: 30,
              // cover_path: '0005.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 393 - 14,
              pos_y: 318 - 113,
              center_x: 393,
              center_y: 318,
              src: '0004.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0005.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 22,
              src: '0018.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0019.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 180;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = -30 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 180;
                let normal_angle_minute = -150 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 180;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = -30 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 180;
                let idle_angle_minute = -150 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
