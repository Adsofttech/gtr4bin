/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_img14 = '';
		let normal_img15 = '';
		let timeInterval;
		let normal_hour_high_imageset17 = '';
		let normal_hour_high_imageset17_array = ['0015.png','0016.png','0017.png'];
		let normal_hour_low_imageset18 = '';
		let normal_hour_low_imageset18_array = ['0018.png','0019.png','0020.png','0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png'];
		let normal_minute_high_imageset19 = '';
		let normal_minute_high_imageset19_array = ['0028.png','0029.png','0030.png','0031.png','0032.png','0033.png'];
		let normal_minute_low_imageset20 = '';
		let normal_minute_low_imageset20_array = ['0034.png','0035.png','0036.png','0037.png','0038.png','0039.png','0040.png','0041.png','0042.png','0043.png'];
		let normal_second_low_imageset21 = '';
		let normal_second_low_imageset21_array = ['0044.png','0045.png','0044.png','0045.png','0044.png','0045.png','0044.png','0045.png','0044.png','0045.png'];
		let normal_week_imageset23 = '';
		let normal_date_high_imageset24 = '';
		let normal_date_high_imageset24_array = ['0053.png','0054.png','0055.png','0056.png'];
		let normal_date_low_imageset25 = '';
		let normal_date_low_imageset25_array = ['0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png','0065.png','0066.png'];
		let normal_month_imageset26 = '';
		let normal_alarm_status28 = '';
		let normal_bt_status29 = '';
		let normal_lock_status30 = '';
		let normal_steps_imagecombo32 = '';
		let normal_heart_current_imagecombo34 = '';
		let normal_distance_imagecombo36 = '';
		let normal_calories_imagecombo38 = '';
		let normal_battery_imagecombo40 = '';
		let normal_temperature_current_imagecombo42 = '';
		let normal_img43 = '';
		let normal_humidity_imagecombo45 = '';
		let normal_img46 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 131,
					y: 18,
					w: 206,
					h: 83,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 16,
					y: 246,
					w: 140,
					h: 85,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 162,
					y: 246,
					w: 142,
					h: 85,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 310,
					y: 246,
					w: 140,
					h: 85,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 90,
					y: 337,
					w: 140,
					h: 85,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 237,
					y: 337,
					w: 140,
					h: 85,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 421,
					w: 43,
					h: 45,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 387,
					y: 333,
					w: 30,
					h: 36,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 47,
					y: 333,
					w: 34,
					h: 40,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 326,
					y: 245,
					w: 104,
					h: 35,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 52,
					y: 245,
					w: 71,
					h: 35,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 111,
					y: 336,
					w: 96,
					h: 35,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 193,
					y: 245,
					w: 79,
					h: 35,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 256,
					y: 336,
					w: 96,
					h: 35,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 36,
					y: 106,
					w: 396,
					h: 2,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -5,
					y: 239,
					w: 477,
					h: 2,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 28,
					y: 108,
					w: 28,
					h: 108,
					src: '0017.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 124,
					y: 108,
					w: 124,
					h: 108,
					src: '0027.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 247,
					y: 108,
					w: 247,
					h: 108,
					src: '0033.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 343,
					y: 108,
					w: 343,
					h: 108,
					src: '0043.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_low_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 223,
					y: 145,
					w: 223,
					h: 145,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_week_imageset23 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 138,
					y: 16,
					week_en: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					week_tc: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					week_sc: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 147,
					y: 52,
					w: 147,
					h: 52,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 183,
					y: 52,
					w: 183,
					h: 52,
					src: '0066.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_month_imageset26 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 235,
					month_startY: 53,
					month_sc_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_tc_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_en_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status28 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 211,
					y: 421,
					w: 43,
					h: 45,
					type: hmUI.system_status.CLOCK,
					src: '0079.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status29 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 387,
					y: 333,
					w: 30,
					h: 36,
					type: hmUI.system_status.DISCONNECT,
					src: '0080.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_lock_status30 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 46,
					y: 333,
					w: 34,
					h: 40,
					type: hmUI.system_status.LOCK,
					src: '0081.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo32 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 17,
					y: 281,
					font_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
					padding: false,
					h_space: -10,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 190,
					y: 281,
					font_array: ["0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					padding: false,
					h_space: -10,
					invalid_image: '0102.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo36 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 310,
					y: 281,
					font_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
					padding: false,
					h_space: -10,
					dot_image: '0103.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo38 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 105,
					y: 373,
					font_array: ["0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
					padding: false,
					h_space: -10,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo40 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 249,
					y: 373,
					font_array: ["0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
					padding: false,
					h_space: -10,
					unit_sc: '0114.png',
					unit_tc: '0114.png',
					unit_en: '0114.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo42 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 334,
					y: 65,
					font_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					padding: false,
					h_space: -10,
					unit_sc: ["0126.png"],
					unit_tc: ["0126.png"],
					unit_en: ["0126.png"],
					negative_image: ["0125.png"],
					invalid_image: ["0125.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img43 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 355,
					y: 39,
					w: 18,
					h: 30,
					src: '0127.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo45 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 63,
					y: 65,
					font_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					padding: false,
					h_space: -10,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 92,
					y: 39,
					w: 24,
					h: 30,
					src: '0138.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateTime() {
					normal_hour_high_imageset17.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset17_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset18.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset18_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset19.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset19_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset20.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset20_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_second_low_imageset21.setProperty(hmUI.prop.MORE, {
						src: normal_second_low_imageset21_array[(timeSensor.second.toString().length == 2 ? timeSensor.second.toString().charAt(1) : timeSensor.second.toString().charAt(0))]
					})
					normal_date_high_imageset24.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset24_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset25.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset25_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}