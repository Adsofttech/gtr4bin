﻿/*
** Watch_Face_Editor tool
** watchface js version v2.0.1
** Copyright © CashaCX75. All Rights Reserved
** Created by StarRrScreaM [4pda]
*/

try {
    (() => {
        //dynamic modify start

        let normal_background_bg = ''
        let circle_second_img = ''
        let circle_second_img1 = ''
        let bg_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_pulse_animation_1 = ''
        let mask_pulse_txt_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let mask_calendar_txt_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''

        let digit_time_img = ''
        let mask_digit_time_txt_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second_mini = ''

        let steps_mask_shadow_img = ''
        let pulse_mask_shadow_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_aod_mask_img = ''
        let bot_circle_btn = ''
        let circle_info_btn = ''
        let weather_btn = ''
        let bg_toggle_btn = ''
        let hands_toggle_btn = ''
        
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_calendar_jumpable_img_click = ''

        let bot_circle_state = 0 // 0 - calendar, 1 - pulse
        let bot_circle_state_txt = ''

        let weather_state = 0 // 0 - digit, 1 - ico
        let weather_state_txt = ''

        let bg_toggle_state = 0 // 0 - white, 1 - black
        let bg_state_txt = ''

        let hands_toggle_state = 0 // 0 - yellow, 1 - gray
        let hands_state_txt = ''

        let normal_hand_second = 'hands_seconds.png';
        let normal_circle_second = 'circle_second.png';

        let step_goal = ''
        let step_goal_full_TXT = ''
        let step_goal_half_TXT = ''

        let test_btn = ''

        //------------------SMOOTH SECOND START-------------------//
        let hsTimer = null;
        let hsTimer_reverse = null;
        let now = hmSensor.createSensor(hmSensor.id.TIME);

        function DisplaySeconds() {
            let cs = now.second * 6 + 6 * (now.utc % 1000) / 1000;

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                pos_x: 233 - 15,
                pos_y: 233 - 222,
                center_x: 233,
                center_y: 233,
                src: normal_hand_second,
                angle: cs,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }

        function DisplaySeconds_reverse() {

            let cs_reverse = 360 - (now.second * 6 + 6 * (now.utc % 1000) / 1000);

            circle_second_img.setProperty(hmUI.prop.MORE, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                pos_x: 233 - 150,
                pos_y: 233 - 150,
                center_x: 233,
                center_y: 233,
                src: normal_circle_second,
                angle: cs_reverse,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }

        //------------------SMOOTH SECOND END_-------------------//

        function click_bg_Switcher() {
            let bg_toggle_total = 2;

            bg_toggle_state = (bg_toggle_state + 1) % bg_toggle_total;

            switch (bg_toggle_state) {
                case 0:
                    bg_img.setProperty(hmUI.prop.SRC, 'bg.png');
                    circle_second_img.setProperty(hmUI.prop.SRC, 'circle_second.png');

                    mask_calendar_txt_img.setProperty(hmUI.prop.SRC, 'mask_calendar.png');
                    mask_pulse_txt_img.setProperty(hmUI.prop.SRC, 'mask_pulse.png');
                    mask_digit_time_txt_img.setProperty(hmUI.prop.SRC, 'mask_digit_time.png');

                    timer.stopTimer(hsTimer);
                    timer.stopTimer(hsTimer_reverse);
                    
                    normal_hand_second = 'hands_seconds.png';
                    normal_circle_second = 'circle_second.png';

                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.SRC, normal_hand_second);
                    circle_second_img.setProperty(hmUI.prop.SRC, normal_circle_second);

                    hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
                    hsTimer_reverse = timer.createTimer(50, 50, DisplaySeconds_reverse, {})

                    step_goal_full_TXT.setProperty(hmUI.prop.MORE, {
                        x: 190,
                        y: 165,
                        w: 20,
                        h: 20,
                        text_size: 18,
                        text: step_goal / 1000,
                        color: '0xFF202020',
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V
                    });

                    step_goal_half_TXT = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 255,
                        y: 165,
                        w: 20,
                        h: 20,
                        text_size: 18,
                        text: step_goal / 1000 / 2,
                        color: '0xFF202020',
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V
                    });

                    bg_state_txt = 'White theme';
                    break;

                case 1:
                    bg_img.setProperty(hmUI.prop.SRC, 'bg_black.png');
                    circle_second_img.setProperty(hmUI.prop.SRC, 'circle_second_black.png');

                    mask_calendar_txt_img.setProperty(hmUI.prop.SRC, 'mask_calendar_W.png');
                    mask_pulse_txt_img.setProperty(hmUI.prop.SRC, 'mask_pulse_W.png');
                    mask_digit_time_txt_img.setProperty(hmUI.prop.SRC, 'mask_digit_time_W.png');

                    timer.stopTimer(hsTimer);
                    timer.stopTimer(hsTimer_reverse);

                    normal_hand_second = 'hands_seconds_W.png';
                    normal_circle_second = 'circle_second_black.png';

                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.SRC, normal_hand_second);
                    circle_second_img.setProperty(hmUI.prop.SRC, normal_circle_second);

                    hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
                    hsTimer_reverse = timer.createTimer(50, 50, DisplaySeconds_reverse, {})

                    step_goal_full_TXT.setProperty(hmUI.prop.MORE, {
                        x: 190,
                        y: 165,
                        w: 20,
                        h: 20,
                        text_size: 18,
                        text: step_goal / 1000,
                        color: '0xFFDFDFDF',
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V
                    });

                    step_goal_half_TXT = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 255,
                        y: 165,
                        w: 20,
                        h: 20,
                        text_size: 18,
                        text: step_goal / 1000 / 2,
                        color: '0xFFDFDFDF',
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V
                    });

                    bg_state_txt = 'Black theme';
                    break;
            }

            hmUI.showToast({ text: bg_state_txt });
        }

        function click_hands_Switcher() {
            let hands_toggle_total = 3;

            hands_toggle_state = (hands_toggle_state + 1) % hands_toggle_total;

            switch (hands_toggle_state) {
                case 0:
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                        hour_path: 'hands_hour.png',
                        hour_centerX: 233,
                        hour_centerY: 233,
                        hour_posX: 35,
                        hour_posY: 132,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                        minute_path: 'hands_minute.png',
                        minute_centerX: 233,
                        minute_centerY: 233,
                        minute_posX: 35,
                        minute_posY: 213,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    break;

                case 1:
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                        hour_path: 'hands_hour_G.png',
                        hour_centerX: 233,
                        hour_centerY: 233,
                        hour_posX: 35,
                        hour_posY: 132,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                        minute_path: 'hands_minute_G.png',
                        minute_centerX: 233,
                        minute_centerY: 233,
                        minute_posX: 35,
                        minute_posY: 213,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    break;

                case 2:
                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                        hour_path: 'hands_hour_W.png',
                        hour_centerX: 233,
                        hour_centerY: 233,
                        hour_posX: 35,
                        hour_posY: 132,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                        minute_path: 'hands_minute_W.png',
                        minute_centerX: 233,
                        minute_centerY: 233,
                        minute_posX: 35,
                        minute_posY: 213,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    break;

                default:
                    break;
            }
        }

        function click_bot_circle_Switcher() {

            let bot_circle_state_total = 3;

            bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

            switch (bot_circle_state) {

                case 0:
                    normal_pulse_animation_1.setProperty(hmUI.prop.VISIBLE, false);
                    mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                    pulse_mask_shadow_img.setProperty(hmUI.prop.VISIBLE, false);

                    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
                    mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);

                    digit_time_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                    mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, false);

                    bot_circle_state_txt = 'Calendar mode';
                    break;

                case 1:
                    normal_pulse_animation_1.setProperty(hmUI.prop.VISIBLE, true);
                    mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                    pulse_mask_shadow_img.setProperty(hmUI.prop.VISIBLE, true);

                    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                    mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

                    digit_time_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                    mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, false);

                    bot_circle_state_txt = 'Pulse mode';
                    break;

                case 2:
                    normal_pulse_animation_1.setProperty(hmUI.prop.VISIBLE, false);
                    mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                    pulse_mask_shadow_img.setProperty(hmUI.prop.VISIBLE, false);

                    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                    mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

                    digit_time_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                    mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, true);

                    bot_circle_state_txt = 'Digit time mode';
                    break;

                default:
                    break;
            }

            hmUI.showToast({ text: bot_circle_state_txt });
        }

        function click_weather_Switcher() {

            if (weather_state == 0) {
                weather_state = weather_state + 1; // ico

                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

                weather_state_txt = 'Graphic weather';
            }
            else {
                weather_state = weather_state - 1; // digit

                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);

                weather_state_txt = 'Digit weather';
            }

            hmUI.showToast({ text: weather_state_txt });

        }

        function click_circle_appStart() {

            if (bot_circle_state == 0) {
                hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
            }
            if (bot_circle_state == 1) {
                hmApp.startApp({ appid: 1, url: 'heart_app_Screen', native: true });
            }
            if (bot_circle_state == 2) {
                hmApp.startApp({ appid: 1, url: 'AlarmInfoScreen', native: true });
            }
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
            , { px: i } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o)),
                e.__globals__)
            , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start


                normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    color: '0xFF000000',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                //circle_second_img = hmUI.createWidget(hmUI.widget.IMG, {
                //    x: 83,
                //    y: 83,
                //    src: 'circle_second.png',
                //    show_level: hmUI.show_level.ONLY_NORMAL,
                //});

                circle_second_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    pos_x: 233 - 150,
                    pos_y: 233 - 150,
                    center_x: 233,
                    center_y: 233,
                    src: normal_circle_second,
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                DisplaySeconds_reverse();
                hsTimer_reverse = timer.createTimer(50, 50, DisplaySeconds_reverse, {});

                bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'bg.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                // center_x: 233,
                // center_y: 232,
                // start_angle: 91,
                // end_angle: -31,
                // radius: 109,
                // line_width: 11,
                // color: 0xFFA5A9AD,
                // mirror: False,
                // inversion: False,
                // type: hmUI.data_type.STEP,
                // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                let screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.AOD) {
                    normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                const step = hmSensor.createSensor(hmSensor.id.STEP);
                step.addEventListener(hmSensor.event.CHANGE, function () {
                    scale_call();
                });
                step_goal = step.target;

                step_goal_full_TXT = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 190,
                    y: 165,
                    w: 20,
                    h: 20,
                    text_size: 18,
                    text: step_goal/1000,
                    color: '0xFF202020',
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V
                });

                step_goal_half_TXT = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 255,
                    y: 165,
                    w: 20,
                    h: 20,
                    text_size: 18,
                    text: step_goal / 1000 / 2,
                    color: '0xFF202020',
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V
                });

                normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: 'steps_point.png',
                    center_x: 233,
                    center_y: 232,
                    x: -95,
                    y: 8,
                    start_angle: 0,
                    end_angle: -121,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: 'hands_small.png',
                    center_x: 117,
                    center_y: 233,
                    x: 12,
                    y: 56,
                    start_angle: -132,
                    end_angle: 131,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 80,
                    y: 265,
                    font_array: ["digits_medium_0.png", "digits_medium_1.png", "digits_medium_2.png", "digits_medium_3.png", "digits_medium_4.png", "digits_medium_5.png", "digits_medium_6.png", "digits_medium_7.png", "digits_medium_8.png", "digits_medium_9.png"],
                    padding: false,
                    h_space: -2,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_pulse_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 217,
                    y: 349,
                    anim_path: "animation",
                    anim_ext: "png",
                    anim_prefix: "pulse",
                    anim_fps: 21,
                    anim_size: 25,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_pulse_animation_1.setProperty(hmUI.prop.VISIBLE, false);

                mask_pulse_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 246,
                    y: 236,
                    src: 'mask_pulse.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);

                // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                // center_x: 233,
                // center_y: 350,
                // start_angle: 0,
                // end_angle: 360,
                // radius: 67,
                // line_width: 23,
                // color: 0xFFFEA331,
                // mirror: False,
                // inversion: False,
                // type: hmUI.data_type.HEART,
                // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType != hmSetting.screen_type.AOD) {
                    normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
                heart_rate.addEventListener(hmSensor.event.CHANGE, function () {
                    scale_call();
                });

                normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 196,
                    y: 320,
                    font_array: ["digits_medium_0.png", "digits_medium_1.png", "digits_medium_2.png", "digits_medium_3.png", "digits_medium_4.png", "digits_medium_5.png", "digits_medium_6.png", "digits_medium_7.png", "digits_medium_8.png", "digits_medium_9.png"],
                    padding: false,
                    h_space: -3,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

                normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 91,
                    y: 338,
                    font_array: ["dig_small_0.png", "dig_small_1.png", "dig_small_2.png", "dig_small_3.png", "dig_small_4.png", "dig_small_5.png", "dig_small_6.png", "dig_small_7.png", "dig_small_8.png", "dig_small_9.png"],
                    padding: false,
                    h_space: -4,
                    unit_sc: 'dig_small_deg.png',
                    unit_tc: 'dig_small_deg.png',
                    unit_en: 'dig_small_deg.png',
                    negative_image: 'dig_small_minus.png',
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);

                normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 97,
                    y: 326,
                    image_array: ["w_01.png", "w_02.png", "w_03.png", "w_04.png", "w_05.png", "w_06.png", "w_07.png", "w_08.png", "w_09.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png", "w_29.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

                normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 206,
                    day_startY: 351,
                    day_sc_array: ["dig_0.png", "dig_1.png", "dig_2.png", "dig_3.png", "dig_4.png", "dig_5.png", "dig_6.png", "dig_7.png", "dig_8.png", "dig_9.png"],
                    day_tc_array: ["dig_0.png", "dig_1.png", "dig_2.png", "dig_3.png", "dig_4.png", "dig_5.png", "dig_6.png", "dig_7.png", "dig_8.png", "dig_9.png"],
                    day_en_array: ["dig_0.png", "dig_1.png", "dig_2.png", "dig_3.png", "dig_4.png", "dig_5.png", "dig_6.png", "dig_7.png", "dig_8.png", "dig_9.png"],
                    day_zero: 0,
                    day_space: 0,
                    day_align: hmUI.align.CENTER_H,
                    day_is_character: false,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);

                mask_calendar_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 246,
                    y: 236,
                    src: 'mask_calendar.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, true);

                normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 190,
                    month_startY: 318,
                    month_sc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
                    month_tc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
                    month_en_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
                    month_is_character: true,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);

                normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 163,
                    y: 273,
                    week_en: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
                    week_tc: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
                    week_sc: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);

                steps_mask_shadow_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 167,
                    y: 117,
                    src: 'steps_mask_shadow.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                pulse_mask_shadow_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 153,
                    y: 270,
                    src: 'pulse_mask_shadow.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                pulse_mask_shadow_img.setProperty(hmUI.prop.VISIBLE, false);

                digit_time_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 163,
                    y: 273,
                    src: 'clocks_mini.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                digit_time_img.setProperty(hmUI.prop.VISIBLE, false);

                mask_digit_time_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 246,
                    y: 236,
                    src: 'mask_digit_time.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);

                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 206,
                    hour_startY: 320,
                    hour_array: ["digits_medium_0.png", "digits_medium_1.png", "digits_medium_2.png", "digits_medium_3.png", "digits_medium_4.png", "digits_medium_5.png", "digits_medium_6.png", "digits_medium_7.png", "digits_medium_8.png", "digits_medium_9.png"],
                    hour_zero: 1,
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,

                    minute_startX: 206,
                    minute_startY: 350,
                    minute_array: ["dig_0.png", "dig_1.png", "dig_2.png", "dig_3.png", "dig_4.png", "dig_5.png", "dig_6.png", "dig_7.png", "dig_8.png", "dig_9.png"],
                    minute_zero: 1,
                    minute_space: 0,
                    minute_follow: 0,
                    minute_align: hmUI.align.CENTER_H,

                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);

                normal_analog_clock_time_pointer_second_mini = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_path: 'hands_seconds_small.png',
                    second_centerX: 233,
                    second_centerY: 348,
                    second_posX: 6,
                    second_posY: 72,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, false);

                normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_path: 'hands_hour.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 35,
                    hour_posY: 132,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_path: 'hands_minute.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 35,
                    minute_posY: 213,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                //normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                //    second_path: 'hands_seconds.png',
                //    second_centerX: 233,
                //    second_centerY: 233,
                //    second_posX: 15,
                //    second_posY: 222,
                //    show_level: hmUI.show_level.ONLY_NORMAL,
                //});

                normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    pos_x: 233 - 15,
                    pos_y: 233 - 222,
                    center_x: 233,
                    center_y: 233,
                    src: normal_hand_second,
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                DisplaySeconds();
                hsTimer = timer.createTimer(50, 50, DisplaySeconds, {})

                idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: 'aod_bg_F.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_path: 'hands_hour_aod.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 35,
                    hour_posY: 132,
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_path: 'hands_minute_aod.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 35,
                    minute_posY: 213,
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_aod_mask_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'aod_mask.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
                // disconneсnt_vibrate_type: 9,
                // disconneсnt_toast_text: Связь потеряна,
                // conneсnt_vibrate_type: 0,
                // conneсnt_toast_text: Связь восстановлена,
                // });

                // vibration when connecting or disconnecting

                function checkConnection() {
                    hmBle.removeListener;
                    hmBle.addListener(function (status) {
                        if (!status) {
                            hmUI.showToast({ text: "Связь потеряна" });
                            vibro(9);
                        }
                        if (status) {
                            hmUI.showToast({ text: "Связь восстановлена" });
                            vibro(0);
                        }
                    });
                }

                // end vibration when connecting or disconnecting
                // vibrate function

                const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
                let timer_StopVibrate = null;


                function vibro(scene = 25) {
                    let stopDelay = 50;
                    stopVibro();
                    vibrate.scene = scene;
                    if (scene < 23 || scene > 25) stopDelay = 1300;
                    vibrate.start();
                    timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
                }

                function stopVibro() {
                    vibrate.stop();
                    if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
                }

                // end vibrate function

                bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 280,
                    y: 365,
                    text: '',
                    w: 75,
                    h: 75,
                    normal_src: 'pst.png',
                    press_src: 'pst.png',
                    click_func: () => {
                        click_bot_circle_Switcher();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);

                bg_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 200,
                    y: 400,
                    text: '',
                    w: 75,
                    h: 75,
                    normal_src: 'pst.png',
                    press_src: 'pst.png',
                    click_func: () => {
                        click_bg_Switcher();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                bg_toggle_btn.setProperty(hmUI.prop.VISIBLE, true);

                hands_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 183,
                    y: 183,
                    text: '',
                    w: 100,
                    h: 100,
                    normal_src: 'pst.png',
                    press_src: 'pst.png',
                    click_func: () => {
                        click_hands_Switcher();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hands_toggle_btn.setProperty(hmUI.prop.VISIBLE, true);

                weather_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 107,
                    y: 385,
                    text: '',
                    w: 50,
                    h: 50,
                    normal_src: 'pst.png',
                    press_src: 'pst.png',
                    click_func: () => {
                        click_weather_Switcher();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                weather_btn.setProperty(hmUI.prop.VISIBLE, true);

                normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 82,
                    y: 312,
                    w: 70,
                    h: 70,
                    src: 'pst.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

                circle_info_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 197,
                    y: 312,
                    text: '',
                    w: 75,
                    h: 75,
                    normal_src: 'pst.png',
                    press_src: 'pst.png',
                    click_func: () => {
                        click_circle_appStart();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                circle_info_btn.setProperty(hmUI.prop.VISIBLE, true);

                //test_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
                //    x: 233 - 75 / 2,
                //    y: 233 - 75 / 2,
                //    text: '',
                //    w: 75,
                //    h: 75,
                //    normal_src: 'pst.png',
                //    press_src: 'pst.png',
                //    click_func: () => {
                //        hmUI.showToast({ text: 'Steps goal is ' + step_goal});
                //        vibro();
                //    },
                //    show_level: hmUI.show_level.ONLY_NORMAL,
                //});
                //test_btn.setProperty(hmUI.prop.VISIBLE, true);

                function scale_call() {

                    console.log('update scales STEP');

                    let valueStep = step.current;
                    let targetStep = step.target;
                    let progressStep = valueStep / targetStep;
                    if (progressStep > 1) progressStep = 1;
                    let progress_cs_normal_step = progressStep;

                    if (screenType != hmSetting.screen_type.AOD) {

                        // normal_step_circle_scale
                        // initial parameters
                        let start_angle_normal_step = 1;
                        let end_angle_normal_step = -121;
                        let center_x_normal_step = 233;
                        let center_y_normal_step = 232;
                        let radius_normal_step = 109;
                        let line_width_cs_normal_step = 11;
                        let color_cs_normal_step = 0xFFA5A9AD;

                        // calculated parameters
                        let arcX_normal_step = center_x_normal_step - radius_normal_step;
                        let arcY_normal_step = center_y_normal_step - radius_normal_step;
                        let CircleWidth_normal_step = 2 * radius_normal_step;
                        let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                        angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                        let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;

                        normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                            x: arcX_normal_step,
                            y: arcY_normal_step,
                            w: CircleWidth_normal_step,
                            h: CircleWidth_normal_step,
                            start_angle: start_angle_normal_step,
                            end_angle: end_angle_normal_step_draw,
                            color: color_cs_normal_step,
                            line_width: line_width_cs_normal_step,
                        });
                    };

                    console.log('update scales HEART');

                    let valueHeartRate = heart_rate.last;
                    let targetHeartRate = 179;
                    let progressHeartRate = (valueHeartRate - 61) / (targetHeartRate - 61);
                    if (progressHeartRate < 0) progressHeartRate = 0;
                    if (progressHeartRate > 1) progressHeartRate = 1;
                    let progress_cs_normal_heart_rate = progressHeartRate;

                    if (screenType != hmSetting.screen_type.AOD) {

                        // normal_heart_rate_circle_scale
                        // initial parameters
                        let start_angle_normal_heart_rate = -90;
                        let end_angle_normal_heart_rate = 270;
                        let center_x_normal_heart_rate = 233;
                        let center_y_normal_heart_rate = 350;
                        let radius_normal_heart_rate = 67;
                        let line_width_cs_normal_heart_rate = 23;
                        let color_cs_normal_heart_rate = 0xFFFEA331;

                        // calculated parameters
                        let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                        let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                        let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                        let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                        angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                        let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;

                        normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                            x: arcX_normal_heart_rate,
                            y: arcY_normal_heart_rate,
                            w: CircleWidth_normal_heart_rate,
                            h: CircleWidth_normal_heart_rate,
                            start_angle: start_angle_normal_heart_rate,
                            end_angle: end_angle_normal_heart_rate_draw,
                            color: color_cs_normal_heart_rate,
                            line_width: line_width_cs_normal_heart_rate,
                        });
                    };

                };

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        scale_call();
                        if (bot_circle_state == 1) {
                            normal_pulse_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                        }
                        checkConnection();
                        stopVibro();

                        DisplaySeconds();
                        DisplaySeconds_reverse();
                        if (hsTimer == null) hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
                        if (hsTimer_reverse == null) hsTimer_reverse = timer.createTimer(50, 50, DisplaySeconds_reverse, {});

                    }),
                    pause_call: (function () {
                        if (bot_circle_state == 1) {
                            normal_pulse_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
                        }
                        stopVibro();

                        timer.stopTimer(hsTimer);
                        hsTimer = null;
                        timer.stopTimer(hsTimer_reverse);
                        hsTimer_reverse = null;

                    }),
                });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                    n.log("index page.js on ready invoke")
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                if (hsTimer) timer.stopTimer(hsTimer);
                if (hsTimer_reverse) timer.stopTimer(hsTimer_reverse);
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
        e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}
