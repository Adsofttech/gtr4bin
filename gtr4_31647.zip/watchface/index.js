﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "light_anim",
              anim_fps: 6,
              anim_size: 13,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 279,
              src: '104.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 142,
              y: 279,
              src: '103.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 193,
              y: 103,
              w: 77,
              h: 14,
              text_size: 9,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 123,
              font_array: ["091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png","100.png"],
              padding: false,
              h_space: 4,
              unit_sc: '101.png',
              unit_tc: '101.png',
              unit_en: '101.png',
              negative_image: '102.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 218,
              month_sc_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_tc_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_en_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 214,
              day_sc_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_tc_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_en_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 218,
              week_en: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              week_tc: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              week_sc: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 374,
              font_array: ["078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png"],
              padding: false,
              h_space: 2,
              dot_image: '088.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 389,
              src: '090.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 299,
              // start_angle: -90,
              // end_angle: 52,
              // radius: 21,
              // line_width: 3,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 121,
              font_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 390,
              // center_y: 299,
              // start_angle: -52,
              // end_angle: 90,
              // radius: 21,
              // line_width: 3,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 376,
              font_array: ["068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 369,
              src: '089.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 110,
              font_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 285,
              hour_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '045.png',
              hour_unit_tc: '045.png',
              hour_unit_en: '045.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 231,
              hour_centerY: 94,
              hour_posX: 6,
              hour_posY: 59,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 231,
              minute_centerY: 94,
              minute_posX: 9,
              minute_posY: 68,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 231,
              second_centerY: 94,
              second_posX: 8,
              second_posY: 70,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 279,
              src: '104.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 142,
              y: 279,
              src: '103.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 193,
              y: 103,
              w: 77,
              h: 14,
              text_size: 9,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 123,
              font_array: ["091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png","100.png"],
              padding: false,
              h_space: 4,
              unit_sc: '101.png',
              unit_tc: '101.png',
              unit_en: '101.png',
              negative_image: '102.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 218,
              month_sc_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_tc_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_en_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png","060.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 214,
              day_sc_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_tc_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_en_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 218,
              week_en: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              week_tc: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              week_sc: ["061.png","062.png","063.png","064.png","065.png","066.png","067.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 374,
              font_array: ["078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png"],
              padding: false,
              h_space: 2,
              dot_image: '088.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 389,
              src: '090.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 299,
              // start_angle: -90,
              // end_angle: 52,
              // radius: 21,
              // line_width: 3,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 121,
              font_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 390,
              // center_y: 299,
              // start_angle: -52,
              // end_angle: 90,
              // radius: 21,
              // line_width: 3,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 376,
              font_array: ["068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 369,
              src: '089.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 110,
              font_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 285,
              hour_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '045.png',
              hour_unit_tc: '045.png',
              hour_unit_en: '045.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 231,
              hour_centerY: 94,
              hour_posX: 6,
              hour_posY: 59,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 231,
              minute_centerY: 94,
              minute_posX: 9,
              minute_posY: 68,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 231,
              second_centerY: 94,
              second_posX: 8,
              second_posY: 70,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 113,
              y: 252,
              w: 80,
              h: 80,
              src: '105.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 98,
              w: 80,
              h: 80,
              src: '105.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 60,
              w: 100,
              h: 100,
              src: '105.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 58,
              w: 100,
              h: 100,
              src: '105.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -180;
                  let end_angle_normal_step = -38;
                  let center_x_normal_step = 75;
                  let center_y_normal_step = 299;
                  let radius_normal_step = 21;
                  let line_width_cs_normal_step = 3;
                  let color_cs_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -142;
                  let end_angle_normal_battery = 0;
                  let center_x_normal_battery = 390;
                  let center_y_normal_battery = 299;
                  let radius_normal_battery = 21;
                  let line_width_cs_normal_battery = 3;
                  let color_cs_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -180;
                  let end_angle_idle_step = -38;
                  let center_x_idle_step = 75;
                  let center_y_idle_step = 299;
                  let radius_idle_step = 21;
                  let line_width_cs_idle_step = 3;
                  let color_cs_idle_step = 0xFF000000;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -142;
                  let end_angle_idle_battery = 0;
                  let center_x_idle_battery = 390;
                  let center_y_idle_battery = 299;
                  let radius_idle_battery = 21;
                  let line_width_cs_idle_battery = 3;
                  let color_cs_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
