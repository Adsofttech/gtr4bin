﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
                //------------------------ автозамена иконок погоды -----------------------------------
                
                let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
                
                let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
                let weatherData = weather.getForecastWeather();
                let forecastData = weatherData.forecastData;
                let sunData = weatherData.tideData;
                let today = '';
                let sunriseMins = '';
                let sunsetMins = '';
                let sunriseMins_def = 8 * 60;			// время восхода
                let sunsetMins_def = 20 * 60;			// и заката по умолчанию
                
                let curMins = '';
                
                let isDayIcons = true;
                let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
                
                function autoToggleWeatherIcons() {
                
                weatherData = weather.getForecastWeather();
                sunData = weatherData.tideData;
                if (sunData.count > 0){
                today = sunData.data[0];
                sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                sunriseMins = sunriseMins_def;
                sunsetMins = sunsetMins_def;
                }
                
                curMins = curTime.hour * 60 + curTime.minute;
                let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
                
                if(isDayNow){
                if(!isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
                  }
                  isDayIcons = true;
                }
                } else {
                if(isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
                  }
                  isDayIcons = false;
                }
                }
                }
                
                //------------------------ автозамена иконок погоды ----------------------------------- \\		

       // смена безеля
       //let bezel_img = ''
       let btn_bezel = ''
       let bezel_num = 1
       let bezel_all = 5
    
       function click_Bezel() {
           if(bezel_num>=bezel_all) {bezel_num=1;}
           else { bezel_num=bezel_num+1;}
           hmUI.showToast({text: "<Безель> " + parseInt(bezel_num) });
           normal_background_bg_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(bezel_num) + ".png");
       }    

       let delay_Timer = null;
       let clicks = 0;
       let clicksDelay = 400;       // задержка между кликами в мс 
     
     //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------		
         function checkClicks() {

           switch(clicks) {
             case 1:
               click_Bezel();
            break;
             case 2:
              click_bot_ssmoth_Switcher(); // функции на двойной клик
            break;
            // case 3:
            //   click_mask();// функции на тройной клик
            // break;
            // case 4:
              // функции на 4-ной клик
            //break;
             default:
            break;
          }
           
          timer.stopTimer(delay_Timer);
          clicks = 0;

         }
           
       
     
         function getClick() {		
     
           clicks++;
           if(delay_Timer) timer.stopTimer(delay_Timer);
           delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
     
         }

       let hands_smoth_btn = ''
       let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
       let sec_smoth_state_txt = ''
 
       function click_bot_ssmoth_Switcher() {
 
         let bot_sec_state_total = 5;
 
         sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;
 
         switch (sec_smoth_state) {
 
             case 0:
               normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                 hour_path: 'hour_1.png',
                 hour_centerX: 233,
                 hour_centerY: 233,
                 hour_posX: 42,
                 hour_posY: 233,
                 show_level: hmUI.show_level.ONLY_NORMAL,
               });
   
               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                 minute_path: 'min_1.png',
                 minute_centerX: 233,
                 minute_centerY: 233,
                 minute_posX: 42,
                 minute_posY: 233,
                 show_level: hmUI.show_level.ONLY_NORMAL,
               });

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                second_path: 'sec_1.png',
                second_centerX: 233,
                second_centerY: 233,
                second_posX: 42,
                second_posY: 233,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
                  src: 'pointer1_1.png',
                  center_x: 350,
                  center_y: 233,
                  posX: 47,
                  posY: 47,
                  start_angle: -125,
                  end_angle: 96,
                  type: hmUI.date.WEEK,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
    
                             
               //normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.SRC, "pointer_1.png");
               //normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.SRC, "dnp_1.png");
                 //normal_analog_clock_pro_second_pointer_img .setProperty(hmUI.prop.SRC, "s_1.png");
       
               sec_smoth_state_txt = 'Стрелка 1';
                 break;
 
             case 1:
 
               normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                 hour_path: 'hour_2.png',
                 hour_centerX: 233,
                 hour_centerY: 233,
                 hour_posX: 42,
                 hour_posY: 233,
                 show_level: hmUI.show_level.ONLY_NORMAL,
               });
   
               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                 minute_path: 'min_2.png',
                 minute_centerX: 233,
                 minute_centerY: 233,
                 minute_posX: 42,
                 minute_posY: 233,
                 show_level: hmUI.show_level.ONLY_NORMAL,
               });

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                second_path: 'sec_2.png',
                second_centerX: 233,
                second_centerY: 233,
                second_posX: 42,
                second_posY: 233,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
              normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
                src: 'pointer1_2.png',
                center_x: 350,
                center_y: 233,
                posX: 47,
                posY: 47,
                start_angle: -125,
                end_angle: 96,
                type: hmUI.date.WEEK,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

               sec_smoth_state_txt = 'Стрелка 2';
                 break;

                 case 2:
 
                 normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hour_3.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 42,
                  hour_posY: 233,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'min_3.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 42,
                  minute_posY: 233,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
 
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                 second_path: 'sec_3.png',
                 second_centerX: 233,
                 second_centerY: 233,
                 second_posX: 42,
                 second_posY: 233,
                 show_level: hmUI.show_level.ONLY_NORMAL,
               });
   
               normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
                src: 'pointer1_3.png',
                center_x: 350,
                center_y: 233,
                posX: 47,
                posY: 47,
                start_angle: -125,
                end_angle: 96,
                type: hmUI.date.WEEK,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                 sec_smoth_state_txt = 'Стрелка 3';
                   break;

                   case 3:
 
                   normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'hour_4.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 42,
                    hour_posY: 233,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'min_4.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 42,
                    minute_posY: 233,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
   
                  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                   second_path: 'sec_4.png',
                   second_centerX: 233,
                   second_centerY: 233,
                   second_posX: 42,
                   second_posY: 233,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 });
     
                 normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
                  src: 'pointer1_4.png',
                  center_x: 350,
                  center_y: 233,
                  posX: 47,
                  posY: 47,
                  start_angle: -125,
                  end_angle: 96,
                  type: hmUI.date.WEEK,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
      
                   sec_smoth_state_txt = 'Стрелка 4';
                     break;

                     case 4:
 
                     normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_5.png',
                      hour_centerX: 233,
                      hour_centerY: 233,
                      hour_posX: 42,
                      hour_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_5.png',
                      minute_centerX: 233,
                      minute_centerY: 233,
                      minute_posX: 42,
                      minute_posY: 233,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
     
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                     second_path: 'sec_5.png',
                     second_centerX: 233,
                     second_centerY: 233,
                     second_posX: 42,
                     second_posY: 233,
                     show_level: hmUI.show_level.ONLY_NORMAL,
                   });
       
                   normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
                    src: 'pointer1_5.png',
                    center_x: 350,
                    center_y: 233,
                    posX: 47,
                    posY: 47,
                    start_angle: -125,
                    end_angle: 96,
                    type: hmUI.date.WEEK,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
        
                     sec_smoth_state_txt = 'Стрелка 5';
                       break;
  
             default:
                 break;
         }
 
         hmUI.showToast({ text: sec_smoth_state_txt });
       }

       let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
       
       let switch_checkBT;
       let switch_hourlyVibro;
       
       //const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider1_on.png' : 'slider1_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   
   //--------------------- вибрация каждый час  ---------------------
       function setEveryHourVibro() {
         curTime.addEventListener(curTime.event.MINUTEEND, function () {
             if (everyHourVibro && !(curTime.minute % 60)) {
               vibro(27);
               hmUI.showToast({text: "Новый час!!!"});
             }
         });
           }
   
   //----------------- вибрация каждый час: включение/отключение  ------------------
       function toggleEveryHourVibro() {
         everyHourVibro = !everyHourVibro;
         vibro();
         hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 
         hmUI.showToast({text: "Ежечасная вибрация " + (everyHourVibro ? "включена" : "отключена")});
           }
   
   
   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
         if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
           everyHourVibro = false;
           hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         } else {
           everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
         }
     
       }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 332,
              src: 'bton.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 332,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 103,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 332,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 101,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 377,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'zona_4.png',
              center_x: 231,
              center_y: 350,
              x: 47,
              y: 47,
              start_angle: -112,
              end_angle: 112,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 338,
              day_startY: 258,
              day_sc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_tc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_en_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer1_1.png',
              center_x: 350,
              center_y: 233,
              posX: 47,
              posY: 47,
              start_angle: -125,
              end_angle: 96,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 136,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 231,
              center_y: 111,
              x: 11,
              y: 65,
              start_angle: -112,
              end_angle: 112,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 258,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 115,
              center_y: 233,
              x: 11,
              y: 65,
              start_angle: -110,
              end_angle: 110,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 42,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 42,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 42,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 184,
              text: '',
              w: 97,
              h: 97,
              normal_src: '',
              press_src: '',
              click_func: () => {
                getClick();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
      

 
      // кнопка включения/отключения ежечасного сигнала
      switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
        x: 113,
        y: 283,
        w: 68,
        h: 68,
        src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
          switch_hourlyVibro.addEventListener(hmUI.event.CLICK_UP, function () {
          toggleEveryHourVibro();
       });


      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 283,
        y: 283,
        w: 68,
        h: 68,
        src: checkBT ? 'slider1_on.png' : 'slider1_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });

                // низкий заряд
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 184,
                  y: 66,
                  w: 97,
                  h: 97,
                  text: '',
                  normal_src: '',
                  press_src: '',
                  click_func: () => {
                  hmApp.startApp({ url: 'LowBatteryScreen', native: true });
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });				
       
              // календарь
              hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 303,
                y: 184,
                w: 97,
                h: 97,
                text: '',
                normal_src: '',
                press_src: '',
                click_func: () => {
                hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
               });	

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 42,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 42,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 66,
              w: 97,
              h: 97,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 66,
              w: 97,
              h: 97,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 305,
              w: 97,
              h: 97,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 184,
              w: 97,
              h: 97,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                stopVibro();
                checkConnection(checkBT);
                autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });
            setEveryHourVibro();


                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}