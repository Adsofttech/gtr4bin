﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   

	//*******************************//
	//*								*//
	//*		Digital Technology +	*//
	//*	  			GTR4			*//
	//*		2023 © leXxiR 4pda		*//
	//*								*//
	//*******************************//


    try {
    (()=>{
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block
		
        let normal_background_bg = ''
        let normal_battery_linear_scale = ''
        let normal_stress_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let normal_alarm_jumpable_img_click = ''

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		const step = hmSensor.createSensor(hmSensor.id.STEP);
		const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
		const heart = hmSensor.createSensor(hmSensor.id.HEART);
		const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
		let curTime = hmSensor.createSensor(hmSensor.id.TIME);

		let bg_fill = ''
		let bgColor = [0x4bd9da, 0xbfff03, 0x00bef0, 0xeb212d, 0xff7800, 0xffd700, 0x37ffc8, 0x088683, 0xff3859, 0x7438ff, 0x38ff38, 0xff38c4, 0x3883ff, 0xffffff, 0x0538f8, 0x999999];
		let colorIndex = 0;
		let path = String(colorIndex) + '/';
		let stepsText = ''
		let distText = ''
		let pulseText = ''
		let calorieText = ''		
		let dateText = ''
		let dayNameText = ''
		let dayNameRect = ''
		let dayName = ''
		let batText = ''
		let weatherText = ''
		let caption = ''
		let copyright = ''
		let activity_cur = 0;
		let activity_btn = ''
		let clock_cover = ''
		let tapsScreen = ''
		let settingsScreen = ''
		let settings_btn;
		let longPress_Timer = null;
		let longPressDelay = 900;
		let checkBT;
		let switch_checkBT;
		let switch_hourlyVibro;
		let everyHourVibro = false;
		let dig_temp_array = [];
		
		var curAODmode;
		let AODmodes = ["пустой", "часы", "полный"];
		let AODmodeName;

		function getCurrentDayName() {
			let day_names = ["П", "В", "С", "Ч", "П", "С", "В"];
			return  day_names[curTime.week - 1];
        }
		
		function getCurrentDate() {
			return curTime.day.toString().padStart(2, "0") + "/" + curTime.month.toString().padStart(2, "0");
        }

		function updateDate() {
			dateText.setProperty(hmUI.prop.TEXT, getCurrentDate());
			dayNameText.setProperty(hmUI.prop.TEXT, getCurrentDayName());
			dayName.setProperty(hmUI.prop.MORE, {
				x: 51 + (curTime.week - 1) * 26,
				y: 100,
			});
		}

		function updateSteps(){
			stepsText.setProperty(hmUI.prop.TEXT, step.current.toString());
		}

		function updateDist(){
			let curDist = distance.current;
			let value = '';
			if (curDist < 1000) {
				value += curDist.toString() + 'м';
			} else {
				curDist = (curDist / 1000).toFixed(2);
				value += curDist.toString() + 'км';
			}

			if (distText) distText.setProperty(hmUI.prop.TEXT, value);
		}
		
		function updatePulse(){
			pulseText.setProperty(hmUI.prop.TEXT, heart.last.toString()); 
		}

		function updateCalorie(){
			calorieText.setProperty(hmUI.prop.TEXT, calorie.current.toString());
		}

		function updateBattery() {
			batText.setProperty(hmUI.prop.TEXT, battery.current.toString() + '%');
			scale_call();
		}

		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			// время восхода
		let sunsetMins_def = 20 * 60;			// и заката по умолчанию
		let curMins = '';
		
		let isDayIcons = true;
		let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь

		function updateWeather(){
			weatherData = weather.getForecastWeather();
			forecastData = weatherData.forecastData;
			let minMaxTemp = forecastData.count ? forecastData.data[0].low.toString() + '° / ' + forecastData.data[0].high.toString() + '°' : '-';
			weatherText.setProperty(hmUI.prop.TEXT, minMaxTemp);
		}

		let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]

		function autoToggleWeatherIcons() {
			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
					}
					isDayIcons = true;
				}
			} else {
				if(isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
					}
					isDayIcons = false;
				}
			}
		}

        function updateData() {
			updateDate();
			updateBattery();
			updateSteps();
			updateDist();
			updatePulse();
			updateCalorie();
			updateWeather();
		}

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

		function toggleActivity() {
			activity_cur = (activity_cur + 1) % 2;
			vibro();
			stepsText.setProperty(hmUI.prop.VISIBLE, activity_cur == 0);
			distText.setProperty(hmUI.prop.VISIBLE, activity_cur == 1);
			caption.setProperty(hmUI.prop.SRC, activity_cur == 0 ? 'cap_steps.png' : 'cap_dist.png');
        }

		function setActivitiesVisibility() {
			distText.setProperty(hmUI.prop.VISIBLE, false);
        }

		function updateArray() {
			path = String(colorIndex) + '/';
			dig_temp_array = [];
			for(let i = 0; i < 10; i++) {
				dig_temp_array.push(path + 'dig_temp_' + i + '.png');
			}
        }

		function showClockCover(show = true) {
			clock_cover.setProperty(hmUI.prop.VISIBLE, show);
		}

		function changeColor() {
			colorIndex = (colorIndex + 1) % bgColor.length;
			bg_fill.setProperty(hmUI.prop.MORE, { 
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				radius: 233,
				color: bgColor[colorIndex]
			});
			showClockCover(true);
			stepsText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			distText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			pulseText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			calorieText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			dateText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			batText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			weatherText.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			dayNameRect.setProperty(hmUI.prop.MORE, { 
				x: 7,
				y: 8,
				w: 25,
				h: 25,
				radius: 6,
				color: bgColor[colorIndex]
			});
			copyright.setProperty(hmUI.prop.MORE, {color: bgColor[colorIndex]});
			updateArray();
            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 325,
              y: 75,
              font_array: dig_temp_array,
              padding: false,
              h_space: 0,
              unit_sc: path + 'dig_temp_deg.png',
              unit_tc: path + 'dig_temp_deg.png',
              unit_en: path + 'dig_temp_deg.png',
              negative_image: path + 'dig_temp_minus.png',
              invalid_image: path + 'dig_temp_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
            });
			
            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 398,
              y: 178,
              src: path + 'status_clock.png',
              type: hmUI.system_status.CLOCK,
            });
			vibro();
			hmFS.SysProSetInt('dtec_colorIndex', colorIndex);
		}

		function checkConnection(check = true) {
			hmBle.removeListener;
			if (check){
				hmBle.addListener(function (status) {
					if(!status && checkBT) {
						hmUI.showToast({text: "Нет связи!!!"});
						vibro(9);
					}
					if(status && checkBT) {
						hmUI.showToast({text: "Снова на связи!"});
						vibro(0);
					}
				})			
			} 
		}

		function toggleСheckConnection() {
			checkBT = !checkBT;
			hmFS.SysProSetBool('nsw_checkBT', checkBT);
			vibro();
			checkConnection(checkBT);
			switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png'); 
        }

		function toggleEveryHourVibro() {
			everyHourVibro = !everyHourVibro;
			hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			vibro();
			switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 

        }

		function setEveryHourVibro() {
			curTime.addEventListener(curTime.event.MINUTEEND, function () {
					if (everyHourVibro && !(curTime.minute % 60)) vibro(27);
			});

        }


		function loadSettings() {
			if (hmFS.SysProGetInt('dtec_aod') === undefined) {
				curAODmode = 1;
				hmFS.SysProSetInt('dtec_aod', curAODmode);
			} else {
				curAODmode = hmFS.SysProGetInt('dtec_aod');
			}
			
			if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
				checkBT = false;
				hmFS.SysProSetBool('nsw_checkBT', checkBT);
			} else {
				checkBT = hmFS.SysProGetBool('nsw_checkBT');
			}
			
			if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
				everyHourVibro = false;
				hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			} else {
				everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
			}
			
			if (hmFS.SysProGetInt('dtec_colorIndex') === undefined) {
				colorIndex = 0;
				hmFS.SysProSetInt('dtec_colorIndex', colorIndex);
			} else {
				colorIndex = hmFS.SysProGetInt('dtec_colorIndex');
			}

			if (hmFS.SysProGetInt('dtec_tapH') === undefined) {
				tapH = 1;
				hmFS.SysProSetInt('dtec_tapH', tapH);
			} else {
				tapH = hmFS.SysProGetInt('dtec_tapH');
			}

			if (hmFS.SysProGetInt('dtec_tapM') === undefined) {
				tapM = 2;
				hmFS.SysProSetInt('dtec_tapM', tapM);
			} else {
				tapM = hmFS.SysProGetInt('dtec_tapM');
			}

			path = String(colorIndex) + '/';
		}


		let apps = [['Нет действия', '-'], ['Таймер', 'CountdownAppScreen'], ['Секундомер', 'StopWatchScreen'], ['Мировые часы', 'WorldClockScreen'],['Восход/закат', 'TideScreen'], ['Сон', 'Sleep_HomeScreen'], ['Стресс', 'StressHomeScreen'], ['SP02 (Кислород)', 'spo_HomeScreen'], ['Дыхание', 'RespirationsettingScreen'], ['Измерение одним касанием', 'oneKeyAppScreen'], ['Женский календарь', 'menstrualAppScreen'], ['Найти телефон', 'FindPhoneScreen'], ['Музыка', 'PhoneMusicCtrlScreen'], ['Компас', 'CompassScreen'], ['Набрать номер', 'DialCallScreen'], ['Телефон', 'PhoneHomeScreen'], ['Диктофон', 'VoiceMemoScreen'], ['Расписание', 'ScheduleListScreen'], ['Список дел', 'todoListScreen']];
		let tapH = 3;
		let tapM = 2;
		let tapH_appName = ''
		let tapM_appName = ''

		function showAppScreen(index) {
			if (index){
				vibro();
				hmApp.startApp({ url: apps[index][1], native: true });
			}
		}

		function toggleAODmode() {
			curAODmode = (curAODmode + 1) % AODmodes.length;
			hmFS.SysProSetInt('dtec_aod', curAODmode);
			vibro();
			AODmodeName.setProperty(hmUI.prop.TEXT, AODmodes[curAODmode]);
        }
	
		function createSettingsScreen() {
			settingsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
			settingsScreen.setProperty(hmUI.prop.VISIBLE, false);

            settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 60,
				w: 466,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
			});
			
			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 466,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКИ",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

 			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 115,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Режим AOD:",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			AODmodeName = settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 150,
				y: 155,
				w: 320,
				h: 64,
				text_size: 32,
				text: AODmodes[curAODmode],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});
			
			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 115,
              w: 340,
              h: 115,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleAODmode();
			});

            switch_checkBT = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 230,
              w: 60,
              h: 33,
              src: checkBT ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 215,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация при потере связи",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 220,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleСheckConnection();
			});

            switch_hourlyVibro = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 290,
              w: 60,
              h: 33,
              src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 275,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация в начале часа",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 280,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleEveryHourVibro();
			});

 			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 380,
				w: 466,
				h: 50,
				text_size: 32,
				text: "Тап-зоны >>",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
					showTapsScreen();
			});

		}

		function showSettingsScreen(value = true) {
			settingsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function openSettingsScreen() {
			if(longPress_Timer) timer.stopTimer(longPress_Timer);
			vibro();
			showSettingsScreen();
		}

		function createTapsScreen() {
			tapsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
			tapsScreen.setProperty(hmUI.prop.VISIBLE, false);

            tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 466,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showTapsScreen(false);
			});
			
			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 60,
				w: 466,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКА",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 100,
				w: 466,
				h: 64,
				text_size: 36,
				text: "ТАП-ЗОН",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});			
			
			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 150,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Зона ЧАСЫ",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapH_appName = tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 90,
				y: 195,
				w: 276,
				h: 64,
				text_size: 32,
				text: apps[tapH][0],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

			tapsScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 30,
			  y: 205,
			  w: 60,
			  h: 50,
			  text_size: 32,
			  text: '<',
			  radius: 6,
			  normal_color: 0x505050,
			  press_color: 0x999999,
			  click_func: () => {
				toggleTapAppH('down');
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			tapsScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 376,
			  y: 205,
			  w: 60,
			  h: 50,
			  text_size: 32,
			  text: '>',
			  radius: 6,
			  normal_color: 0x505050,
			  press_color: 0x999999,
			  click_func: () => {
				toggleTapAppH('up');
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});			

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 250,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Зона МИНУТЫ",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapM_appName = tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 90,
				y: 295,
				w: 276,
				h: 64,
				text_size: 32,
				text: apps[tapM][0],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});
			
			tapsScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 30,
			  y: 305,
			  w: 60,
			  h: 50,
			  text_size: 32,
			  text: '<',
			  radius: 6,
			  normal_color: 0x505050,
			  press_color: 0x999999,
			  click_func: () => {
				toggleTapAppM('down');
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			tapsScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 376,
			  y: 305,
			  w: 60,
			  h: 50,
			  text_size: 32,
			  text: '>',
			  radius: 6,
			  normal_color: 0x505050,
			  press_color: 0x999999,
			  click_func: () => {
				toggleTapAppM('up');
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	
		}

		function showTapsScreen(value = true) {
			tapsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function changeApp(dir) {
			if (dir == 'up'){
				appIndex = (appIndex + 1) % apps.length;
			} else if (dir == 'down'){
				appIndex = (appIndex + apps.length - 1) % apps.length;
			}
			appName.setProperty(hmUI.prop.TEXT, apps[appIndex]);
		}	



		function toggleTapAppH(dir) {
			if (dir == 'up'){
				tapH = (tapH + 1) % apps.length;
				if (tapH && tapH == tapM) tapH = (tapH + 1) % apps.length;
			} else if (dir == 'down'){
				tapH = (tapH + apps.length - 1) % apps.length;
				if (tapH && tapH == tapM) tapH = (tapH + apps.length - 1) % apps.length;
			}
			vibro();
			tapH_appName.setProperty(hmUI.prop.TEXT, apps[tapH][0]);
			hmFS.SysProSetInt('dtec_tapH', tapH);
		}

		function toggleTapAppM(dir) {
			if (dir == 'up'){
				tapM = (tapM + 1) % apps.length;
				if (tapM && tapM == tapH) tapM = (tapM + 1) % apps.length;
			} else if (dir == 'down'){
				tapM = (tapM + apps.length - 1) % apps.length;
				if (tapM && tapH == tapM) tapM = (tapM + apps.length - 1) % apps.length;
			}
			vibro();
			tapM_appName.setProperty(hmUI.prop.TEXT, apps[tapM][0]);
			hmFS.SysProSetInt('dtec_tapM', tapM);
		}


		function makeAOD() {
			
			let mode = hmFS.SysProGetInt('dtec_aod');
			
            hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

			if (mode == 1){			// часы
			
				bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 0,
				  w: 466,
				  h: 466,
				  radius: 233,
				  color: bgColor[colorIndex],
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 55,
				  w: 466,
				  h: 98,
				  color: 0x000000,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 277,
				  w: 466,
				  h: 60,
				  color: 0x000000,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 125,
				  y: 392,
				  w: 25,
				  h: 25,
				  color: 0x000000,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 165,
				  y: 405,
				  w: 130,
				  h: 30,
				  color: 0x000000,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 378,
				  y: 145,
				  w: 50,
				  h: 140,
				  color: 0x000000,
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'bg.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 223,
				  y: 415,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 217,
				  y: 350,
				  src: path + 'status_clock.png',
				  type: hmUI.system_status.CLOCK,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 47,
				  hour_startY: 158,
				  hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  hour_zero: 1,
				  hour_space: 12,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 232,
				  minute_startY: 158,
				  minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  minute_zero: 1,
				  minute_space: 12,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});

			}

			if (mode == 2){			// полный
				
				updateArray(); 
					
				bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 0,
				  w: 466,
				  h: 466,
				  radius: 233,
				  color: bgColor[colorIndex],
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 378,
				  y: 226,
				  w: 50,
				  h: 42,
				  color: 0x000000,
				});
				
				normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

				caption = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 205,
				  y: 309,
				  src: 'cap_steps.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				autoToggleWeatherIcons();
				hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
				  x: 282,
				  y: 69,
				  image_array: weather_icons,
				  image_length: 29,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'bg.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 129,
				  y: 398,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 398,
				  y: 178,
				  src: path + 'status_clock.png',
				  type: hmUI.system_status.CLOCK,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 325,
				  y: 75,
				  font_array: dig_temp_array,
				  padding: false,
				  h_space: 0,
				  unit_sc: path + 'dig_temp_deg.png',
				  unit_tc: path + 'dig_temp_deg.png',
				  unit_en: path + 'dig_temp_deg.png',
				  negative_image: path + 'dig_temp_minus.png',
				  invalid_image: path + 'dig_temp_minus.png',
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 47,
				  hour_startY: 158,
				  hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  hour_zero: 1,
				  hour_space: 12,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 232,
				  minute_startY: 158,
				  minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  minute_zero: 1,
				  minute_space: 12,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});


				dateText = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 105,
					y: 57,
					w: 124,
					h: 40,
					text_size: 41,
					char_space: 2,
					color: bgColor[colorIndex],
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text: getCurrentDate(),		
				});

				dayName = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 51 + (curTime.week - 1) * 25,
				  y: 100,
				  w: 40,
				  h: 40,
				});

				dayNameRect = dayName.createWidget(hmUI.widget.FILL_RECT, {
				  x: 7,
				  y: 8,
				  w: 25,
				  h: 25,
				  radius: 6,
				  color: bgColor[colorIndex],
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				dayNameText = dayName.createWidget(hmUI.widget.TEXT, {
					x: 0,
					y: 0,
					w: 40,
					h: 40,
					text_size: 24,
					color: 0x000000,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text: getCurrentDayName(),		
				});

				weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 254,
				  y: 100,
				  w: 140,
				  h: 40,
				  text_size: 23,
				  char_space: 0,
				  line_space: 0,
				  color: bgColor[colorIndex],
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				stepsText = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 0,
				  y: 338,
				  w: 466,
				  h: 50,
				  text_size: 50,
				  char_space: 1,
				  line_space: 0,
				  color: bgColor[colorIndex],
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				step.addEventListener(hmSensor.event.CHANGE, function() {
				  updateSteps();
				});

				distText = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 0,
				  y: 338,
				  w: 466,
				  h: 50,
				  text_size: 40,
				  char_space: 0,
				  line_space: 0,
				  color: bgColor[colorIndex],
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				distance.addEventListener(hmSensor.event.CHANGE, function() {
				  updateDist();
				});

				pulseText = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 78,
				  y: 338,
				  w: 66,
				  h: 40,
				  text_size: 35,
				  char_space: 0,
				  line_space: 0,
				  color: bgColor[colorIndex],
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				heart.addEventListener(hmSensor.event.CHANGE, function() {
				  updatePulse();
				});

				calorieText = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 318,
				  y: 338,
				  w: 86,
				  h: 40,
				  text_size: 35,
				  char_space: 0,
				  line_space: 0,
				  color: bgColor[colorIndex],
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				calorie.addEventListener(hmSensor.event.CHANGE, function() {
				  updateCalorie();
				});
			
				setActivitiesVisibility();

				batText = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 304,
					y: 396,
					w: 70,
					h: 30,
					text_size: 25,
					color: bgColor[colorIndex],
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					show_level: hmUI.show_level.ONLY_AOD,
				});

				battery.addEventListener(hmSensor.event.CHANGE, function() {
				  updateBattery();
				});

				curTime.addEventListener(curTime.event.DAYCHANGE, function () {
					updateDate();
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'mask.png',
				});
				updateData();
			}

			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					stopVibro();
				}),
				pause_call: (function () {
					stopVibro();
				}),
			});	
			
			checkConnection(hmFS.SysProGetBool('nsw_checkBT'));
			setEveryHourVibro();
		}

		function scale_call() {

			console.log('update scales BATTERY');
			
			let valueBattery = battery.current;
			let targetBattery = 100;
			let progressBattery = valueBattery/targetBattery;
			if (progressBattery > 1) progressBattery = 1;
			let progress_ls_normal_battery = 1 - progressBattery;

			  // normal_battery_linear_scale
			  // initial parameters
			  let start_x_normal_battery = 293;
			  let start_y_normal_battery = 412;
			  let lenght_ls_normal_battery = -121;
			  let line_width_ls_normal_battery = 22;
			  let color_ls_normal_battery = 0xFF272727;
			  
			  // calculated parameters
			  let start_x_normal_battery_draw = start_x_normal_battery;
			  let start_y_normal_battery_draw = start_y_normal_battery;
			  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
			  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
			  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
			  if (lenght_ls_normal_battery < 0){
				lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
				start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
			  }
			  
			  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
				x: start_x_normal_battery_draw,
				y: start_y_normal_battery_draw,
				w: lenght_ls_normal_battery_draw,
				h: line_width_ls_normal_battery_draw,
				color: color_ls_normal_battery,
			  });
		}


//------------------------------------------------------------------------

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {

            updateArray(); 
                
            bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
			  radius: 233,
              color: bgColor[colorIndex],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            caption = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 309,
              src: 'cap_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			autoToggleWeatherIcons();
			hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
			  x: 282,
			  y: 69,
			  image_array: weather_icons,
			  image_length: 29,
			  type: hmUI.data_type.WEATHER_CURRENT,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_background_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 398,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 178,
              src: path + 'status_clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            clock_cover = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 397,
              y: 177,
              w: 32,
              h: 34,
              color: 0x000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			showClockCover(false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 75,
              font_array: dig_temp_array,
              padding: false,
              h_space: 0,
              unit_sc: path + 'dig_temp_deg.png',
              unit_tc: path + 'dig_temp_deg.png',
              unit_en: path + 'dig_temp_deg.png',
              negative_image: path + 'dig_temp_minus.png',
              invalid_image: path + 'dig_temp_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 158,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 158,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 384,
              second_startY: 232,
              second_array: ["dig_sec_0.png","dig_sec_1.png","dig_sec_2.png","dig_sec_3.png","dig_sec_4.png","dig_sec_5.png","dig_sec_6.png","dig_sec_7.png","dig_sec_8.png","dig_sec_9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			dateText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 105,
				y: 57,
				w: 124,
				h: 40,
				text_size: 41,
				char_space: 2,
				color: bgColor[colorIndex],
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				text: getCurrentDate(),		
			});

			dayName = hmUI.createWidget(hmUI.widget.GROUP, {
			  x: 51 + (curTime.week - 1) * 25,
			  y: 100,
              w: 40,
              h: 40,
            });

            dayNameRect = dayName.createWidget(hmUI.widget.FILL_RECT, {
              x: 7,
              y: 8,
              w: 25,
              h: 25,
			  radius: 6,
              color: bgColor[colorIndex],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			dayNameText = dayName.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 0,
				w: 40,
				h: 40,
				text_size: 24,
				color: 0x000000,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				text: getCurrentDayName(),		
			});

			weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 254,
			  y: 100,
			  w: 140,
			  h: 40,
			  text_size: 23,
			  char_space: 0,
			  line_space: 0,
			  color: bgColor[colorIndex],
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			stepsText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 0,
			  y: 338,
			  w: 466,
			  h: 50,
			  text_size: 50,
			  char_space: 1,
			  line_space: 0,
			  color: bgColor[colorIndex],
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			step.addEventListener(hmSensor.event.CHANGE, function() {
			  updateSteps();
			});

			distText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 0,
			  y: 338,
			  w: 466,
			  h: 50,
			  text_size: 40,
			  char_space: 0,
			  line_space: 0,
			  color: bgColor[colorIndex],
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			distance.addEventListener(hmSensor.event.CHANGE, function() {
			  updateDist();
			});

			pulseText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 78,
			  y: 338,
			  w: 66,
			  h: 40,
			  text_size: 35,
			  char_space: 0,
			  line_space: 0,
			  color: bgColor[colorIndex],
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			heart.addEventListener(hmSensor.event.CHANGE, function() {
			  updatePulse();
			});

			calorieText = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 318,
			  y: 338,
			  w: 86,
			  h: 40,
			  text_size: 35,
			  char_space: 0,
			  line_space: 0,
			  color: bgColor[colorIndex],
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			calorie.addEventListener(hmSensor.event.CHANGE, function() {
			  updateCalorie();
			});
		
			setActivitiesVisibility();

			batText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 304,
				y: 396,
				w: 70,
				h: 30,
				text_size: 25,
				color: bgColor[colorIndex],
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            battery.addEventListener(hmSensor.event.CHANGE, function() {
              updateBattery();
            });

			curTime.addEventListener(curTime.event.DAYCHANGE, function () {
				updateDate();
			});

			copyright = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 396,
				y: 40,
				w: 70,
				h: 30,
				text_size: 24,
				text: 'leXxiR',
				color: bgColor[colorIndex],
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: 405,
				y: 64,
				w: 70,
				h: 30,
				text_size: 24,
				text: '4pda',
				color: 0x4bd9da,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 62,
              w: 123,
              h: 82,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 303,
              w: 82,
              h: 84,
              src: 'blank.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 390,
              y: 155,
              w: 76,
              h: 68,
              src: 'blank.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 303,
              w: 82,
              h: 84,
              src: 'blank.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 159,
              y: 344,
              w: 149,
              h: 60,
              src: 'blank.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			//запуск приложения по нажатию на часы
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 54,
              y: 163,
              w: 128,
              h: 107,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showAppScreen(tapH);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			//запуск приложения по нажатию на минуты
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 239,
              y: 163,
              w: 128,
              h: 107,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showAppScreen(tapM);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 62,
              w: 205,
              h: 82,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 159,
              y: 287,
              w: 149,
              h: 55,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				toggleActivity();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			settings_btn = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 170,
			  y: 0,
			  w: 123,
			  h: 51,
			  src: 'blank.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			settings_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				longPress_Timer = timer.createTimer(longPressDelay, 0, openSettingsScreen, {});
			});
			settings_btn.addEventListener(hmUI.event.CLICK_UP, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				changeColor();
			});

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				showClockCover(false);
				stopVibro();
				updateData();
				autoToggleWeatherIcons();
              }),
              pause_call: (function () {
				stopVibro();
              }),
            });

			createSettingsScreen();
			createTapsScreen();

            },
            onInit() {
				stopVibro();
				loadSettings();
                logger.log("index page.js on init invoke")
            },
            build() {
				if (hmSetting.getScreenType() == hmSetting.screen_type.AOD){
					makeAOD();
				} else {
					this.init_view();
				}
            },
            onDestroy() {
				vibrate && vibrate.stop();
				heart.removeEventListener(heart.event.CURRENT, hrLastListener);
                logger.log("index page.js on destroy invoke")
            }
        })
    })()
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
