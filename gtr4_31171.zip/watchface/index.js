﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_stand_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let idle_stand_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let editGroup_1  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'Pr1.png', path: 'B1.png' },
                { id: 2, preview: 'Pr2.png', path: 'B2.png' },
                { id: 3, preview: 'Pr3.png', path: 'B3.png' },
                { id: 4, preview: 'Pr4.png', path: 'B4.png' },
                { id: 5, preview: 'Pr5.png', path: 'B5.png' },
                { id: 6, preview: 'Pr6.png', path: 'B6.png' },
                { id: 7, preview: 'Pr7.png', path: 'B7.png' },
                { id: 8, preview: 'Pr8.png', path: 'B8.png' },
                { id: 9, preview: 'Pr9.png', path: 'B9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: 'Mask.png',
              tips_bg: 'faq.png',
              tips_x: 104,
              tips_y: 157,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 165,
              center_y: 233,
              x: 15,
              y: 66,
              start_angle: -180,
              end_angle: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 320,
              day_startY: 204,
              day_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 165,
              center_y: 233,
              x: 15,
              y: 66,
              start_angle: -180,
              end_angle: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 320,
              day_startY: 204,
              day_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              select_image: 'Mask.png',
              un_select_image: 'Mask.png',
              default_type: hmUI.edit_type.WIND,
              optional_types: [
                { type: hmUI.edit_type.WIND, preview: 'ScPr1.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ScPr2.png' },
              ],
              count: 2,
              tips_BG: 'faq.png',
              tips_x: -200,
              tips_y: -200,
              tips_width: 100,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Sc2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Sc1.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 234,
                    path: '0005.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 32,
                    posY: 159,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 29,
                    posY: 229,
                    path: '0004.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 233,
                    centerY: 233,
                    posX: 30,
                    posY: 234,
                    path: '0005.png',
                  },
                  hour: {
                    centerX: 233,
                    centerY: 233,
                    posX: 50,
                    posY: 167,
                    path: '0017.png',
                  },
                  minute: {
                    centerX: 233,
                    centerY: 233,
                    posX: 43,
                    posY: 233,
                    path: '0018.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: 'Mask.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
