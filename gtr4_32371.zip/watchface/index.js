﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 244,
              second_centerY: 244,
              second_posX: 173,
              second_posY: 173,
              second_cover_path: 'center1.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arrow1.png',
              center_x: 352,
              center_y: 244,
              x: 13,
              y: 55,
              start_angle: 105,
              end_angle: -104,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 267,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'proc.png',
              unit_tc: 'proc.png',
              unit_en: 'proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 376,
              y: 312,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 353,
              font_array: ["Act_Small_Font_01w.png","Act_Small_Font_02w.png","Act_Small_Font_03w.png","Act_Small_Font_04w.png","Act_Small_Font_05w.png","Act_Small_Font_06w.png","Act_Small_Font_07w.png","Act_Small_Font_08w.png","Act_Small_Font_09w.png","Act_Small_Font_10w.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 137,
              y: 393,
              w: 219,
              h: 33,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFCF9,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 354,
              font_array: ["Act_Small_Font_01w.png","Act_Small_Font_02w.png","Act_Small_Font_03w.png","Act_Small_Font_04w.png","Act_Small_Font_05w.png","Act_Small_Font_06w.png","Act_Small_Font_07w.png","Act_Small_Font_08w.png","Act_Small_Font_09w.png","Act_Small_Font_10w.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbo_02w.png',
              unit_tc: 'Weather_symbo_02w.png',
              unit_en: 'Weather_symbo_02w.png',
              negative_image: 'Weather_symbo_01w.png',
              invalid_image: 'Weather_symbo_01w.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 346,
              image_array: ["weather_icon_01w.png","weather_icon_02w.png","weather_icon_03w.png","weather_icon_04w.png","weather_icon_05w.png","weather_icon_06w.png","weather_icon_07w.png","weather_icon_08w.png","weather_icon_09w.png","weather_icon_10w.png","weather_icon_11w.png","weather_icon_12w.png","weather_icon_13w.png","weather_icon_14w.png","weather_icon_15w.png","weather_icon_16w.png","weather_icon_17w.png","weather_icon_18w.png","weather_icon_19w.png","weather_icon_20w.png","weather_icon_21w.png","weather_icon_22w.png","weather_icon_23w.png","weather_icon_24w.png","weather_icon_25w.png","weather_icon_26w.png","weather_icon_27w.png","weather_icon_28w.png","weather_icon_29w.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 322,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 152,
              month_sc_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              month_tc_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              month_en_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arrow2.png',
              center_x: 138,
              center_y: 244,
              x: 13,
              y: 55,
              start_angle: -105,
              end_angle: 104,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 266,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 153,
              day_sc_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              day_tc_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              day_en_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'Act_Small_Font_00.png',
              day_unit_tc: 'Act_Small_Font_00.png',
              day_unit_en: 'Act_Small_Font_00.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -92,
              y: 8,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -82,
              y: 122,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 82,
              y: -279,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["w-1.png","w-2.png","w-3.png","w-4.png","w-5.png","w-6.png","w-7.png"],
              week_tc: ["w-1.png","w-2.png","w-3.png","w-4.png","w-5.png","w-6.png","w-7.png"],
              week_sc: ["w-1.png","w-2.png","w-3.png","w-4.png","w-5.png","w-6.png","w-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 320,
              font_array: ["Act_Small_Font_01w.png","Act_Small_Font_02w.png","Act_Small_Font_03w.png","Act_Small_Font_04w.png","Act_Small_Font_05w.png","Act_Small_Font_06w.png","Act_Small_Font_07w.png","Act_Small_Font_08w.png","Act_Small_Font_09w.png","Act_Small_Font_10w.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 307,
              src: 'procent.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 352,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 121,
              src: '0099.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 246,
                    centerY: 246,
                    posX: 23,
                    posY: 167,
                    path: '0096.png',
                  },
                  minute: {
                    centerX: 246,
                    centerY: 246,
                    posX: 24,
                    posY: 211,
                    path: '0097.png',
                  },
                  preview: 'AOD-m.png',
                },
                {
                  id: 2,
                  hour: {
                    centerX: 246,
                    centerY: 246,
                    posX: 23,
                    posY: 167,
                    path: 'AOD-h.png',
                  },
                  minute: {
                    centerX: 246,
                    centerY: 246,
                    posX: 24,
                    posY: 211,
                    path: 'AOD-m.png',
                  },
                },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: Связь с телефоном разорвана,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Связь с телефоном восстановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь с телефоном разорвана"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "Связь с телефоном восстановлена"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 206,
              w: 89,
              h: 87,
              src: '0000101.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 89,
              w: 109,
              h: 109,
              src: '0000101.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 310,
              w: 64,
              h: 64,
              src: '0000101.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 336,
              w: 109,
              h: 60,
              src: '0000101.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 191,
              w: 109,
              h: 109,
              src: '0000101.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 336,
              w: 109,
              h: 60,
              src: '0000101.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
