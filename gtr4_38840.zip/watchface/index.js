﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_stress_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 44,
              month_sc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_tc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_en_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 81,
              week_en: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_tc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_sc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 159,
              day_startY: 50,
              day_sc_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_tc_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_en_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 334,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 276,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'kropka.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 395,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 164,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 111,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 220,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 245,
              hour_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 90,
              minute_startY: 321,
              minute_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 151,
              second_startY: 398,
              second_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 44,
              month_sc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_tc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_en_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 81,
              week_en: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_tc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_sc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 159,
              day_startY: 50,
              day_sc_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_tc_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_en_array: ["day00.png","day01.png","day02.png","day03.png","day04.png","day05.png","day06.png","day07.png","day08.png","day09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 395,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 245,
              hour_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 90,
              minute_startY: 321,
              minute_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 151,
              second_startY: 398,
              second_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}