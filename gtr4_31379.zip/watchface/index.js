﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_icon_img = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_stand_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
		
				let img = ''  // Hintergrund
        let prefix_img = 'bg_'  // prefix image (name without sequence number)
        let img_index = 0  // image number
        let img_count = 14  // number of images
		
		function toggleColor() {							// переключаем цвет фона и секундной стрелки по кругу от 0 до img_count-1
			img_index = (img_index + 1) % img_count;
			hmFS.SysProSetInt('MARK_colorIndex', img_index);
            img.setProperty(hmUI.prop.SRC, prefix_img + img_index + '.png');
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'hand_second_' + img_index + '.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 233,
			});
		}
		
		
		
		function loadSettings() {							// получаем значение индекса цвета из системной переменной
			
			if (hmFS.SysProGetInt('MARK_colorIndex') === undefined) {
				img_index = 0;
				hmFS.SysProSetInt('MARK_colorIndex', img_index);
			} else {
				img_index = hmFS.SysProGetInt('MARK_colorIndex');
			}
		}
		
		let btn_zona1 = ''
		let zona1_num = 0
		let zona1_all = 1
		
		function click_zona1() {
		zona1_num = (zona1_num + 1) % (zona1_all + 1);
		if (zona1_num == 0) {
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_year_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'ЧИСЛО+ДЕНЬ НЕДЕЛИ'
			});
		};


		if (zona1_num == 1) {
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
		normal_date_year_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'МЕСЯЦ+ГОД'
        });
      }
	 }
	 
	 	let btn_zona2 = ''
		let zona2_num = 0
		let zona2_all = 1
		
		function click_zona2() {
		zona2_num = (zona2_num + 1) % (zona2_all + 1);
		if (zona2_num == 0) {
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'ШАГИ'
			});
		};


		if (zona2_num == 1) {
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'КАЛОРИИ'
        });
      }
	 }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
		      img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + parseInt(img_index) + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 70,
              y: 124,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Untitled",
              anim_fps: 31,
              anim_size: 31,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 124,
              hour_startY: 139,
              hour_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 124,
              minute_startY: 237,
              minute_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 374,
              font_array: ["NUMBERS_M_00.png","NUMBERS_M_01.png","NUMBERS_M_02.png","NUMBERS_M_03.png","NUMBERS_M_04.png","NUMBERS_M_05.png","NUMBERS_M_06.png","NUMBERS_M_07.png","NUMBERS_M_08.png","NUMBERS_M_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 98,
              src: 'ICON_STEPS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 67,
              font_array: ["NUMBERS_M_00.png","NUMBERS_M_01.png","NUMBERS_M_02.png","NUMBERS_M_03.png","NUMBERS_M_04.png","NUMBERS_M_05.png","NUMBERS_M_06.png","NUMBERS_M_07.png","NUMBERS_M_08.png","NUMBERS_M_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 427,
              font_array: ["NUMBERS_PWR_00.png","NUMBERS_PWR_01.png","NUMBERS_PWR_02.png","NUMBERS_PWR_03.png","NUMBERS_PWR_04.png","NUMBERS_PWR_05.png","NUMBERS_PWR_06.png","NUMBERS_PWR_07.png","NUMBERS_PWR_08.png","NUMBERS_PWR_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 67,
              src: 'ICON_CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 67,
              font_array: ["NUMBERS_M_00.png","NUMBERS_M_01.png","NUMBERS_M_02.png","NUMBERS_M_03.png","NUMBERS_M_04.png","NUMBERS_M_05.png","NUMBERS_M_06.png","NUMBERS_M_07.png","NUMBERS_M_08.png","NUMBERS_M_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 22,
              day_sc_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              day_tc_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              day_en_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 30,
              src: 'icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 224,
              y: 22,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 174,
              month_startY: 22,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 252,
              year_startY: 22,
              year_sc_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              year_tc_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              year_en_array: ["NUMBERS_MONTHDAY_00.png","NUMBERS_MONTHDAY_01.png","NUMBERS_MONTHDAY_02.png","NUMBERS_MONTHDAY_03.png","NUMBERS_MONTHDAY_04.png","NUMBERS_MONTHDAY_05.png","NUMBERS_MONTHDAY_06.png","NUMBERS_MONTHDAY_07.png","NUMBERS_MONTHDAY_08.png","NUMBERS_MONTHDAY_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 243,
              y: 30,
              src: 'icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 1,
              y: 91,
              src: 'ICON_BLUETOOTH_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_second_' + img_index + '.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 25,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		
				            // Button to switch images. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 124,  // x coordinate of the button
              y: 138,  // y coordinate of the button
              text: '',
              w: 218,  // button width
              h: 193,  // button height
              normal_src: 'click_e.png',  // transparent image
              press_src: 'click_e.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
				toggleColor();
			  }
            });		

			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			x: 156, 
			y: 0, 
			text: '',
			w: 156, 
			h: 62, 
			normal_src: 'click_e.png',
			press_src: 'click_e.png',
			show_level: hmUI.show_level.ONLY_NORMAL,
			click_func: () => {
            click_zona1();
            click_Vibrate(); //имя вызываемой функции
              } 
            });
		
        btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
		normal_date_year_separator_img.setProperty(hmUI.prop.VISIBLE, false);	

			btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			x: 155, 
			y: 61, 
			text: '',
			w: 153, 
			h: 66, 
			normal_src: 'click_e.png',
			press_src: 'click_e.png',
			show_level: hmUI.show_level.ONLY_NORMAL,
			click_func: () => {
            click_zona2();
            click_Vibrate(); //имя вызываемой функции
              } 
            });
		
        btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);		


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: prefix_img + img_index + '.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 354,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 124,
              hour_startY: 139,
              hour_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 124,
              minute_startY: 237,
              minute_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
			onInit() {
				loadSettings();
                n.log("index page.js on init invoke");
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
