﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_icon_img = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFFD5D7D2',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 0,
              src: 'Center_Grey_0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 222,
              src: 'charge.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 213,
              font_array: ["analog_dark_charge_0001.png","analog_dark_charge_0002.png","analog_dark_charge_0003.png","analog_dark_charge_0004.png","analog_dark_charge_0005.png","analog_dark_charge_0006.png","analog_dark_charge_0007.png","analog_dark_charge_0008.png","analog_dark_charge_0009.png","analog_dark_charge_0010.png"],
              padding: false,
              h_space: -32,
              unit_sc: 'simple_analog_percent.png',
              unit_tc: 'simple_analog_percent.png',
              unit_en: 'simple_analog_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 210,
              day_sc_array: ["analog_red_daynum_0001.png","analog_red_daynum_0002.png","analog_red_daynum_0003.png","analog_red_daynum_0004.png","analog_red_daynum_0005.png","analog_red_daynum_0006.png","analog_red_daynum_0007.png","analog_red_daynum_0008.png","analog_red_daynum_0009.png","analog_red_daynum_0010.png"],
              day_tc_array: ["analog_red_daynum_0001.png","analog_red_daynum_0002.png","analog_red_daynum_0003.png","analog_red_daynum_0004.png","analog_red_daynum_0005.png","analog_red_daynum_0006.png","analog_red_daynum_0007.png","analog_red_daynum_0008.png","analog_red_daynum_0009.png","analog_red_daynum_0010.png"],
              day_en_array: ["analog_red_daynum_0001.png","analog_red_daynum_0002.png","analog_red_daynum_0003.png","analog_red_daynum_0004.png","analog_red_daynum_0005.png","analog_red_daynum_0006.png","analog_red_daynum_0007.png","analog_red_daynum_0008.png","analog_red_daynum_0009.png","analog_red_daynum_0010.png"],
              day_zero: 1,
              day_space: -67,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 11,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 442,
              src: '0087.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 372,
              y: 178,
              week_en: ["analog_dark_day_0001.png","analog_dark_day_0002.png","analog_dark_day_0003.png","analog_dark_day_0004.png","analog_dark_day_0005.png","analog_dark_day_0006.png","analog_dark_day_0007.png"],
              week_tc: ["analog_dark_day_0001.png","analog_dark_day_0002.png","analog_dark_day_0003.png","analog_dark_day_0004.png","analog_dark_day_0005.png","analog_dark_day_0006.png","analog_dark_day_0007.png"],
              week_sc: ["analog_dark_day_0001.png","analog_dark_day_0002.png","analog_dark_day_0003.png","analog_dark_day_0004.png","analog_dark_day_0005.png","analog_dark_day_0006.png","analog_dark_day_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Red_min.png',
              minute_centerX: 232,
              minute_centerY: 233,
              minute_posX: 42,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Red_hour.png',
              hour_centerX: 232,
              hour_centerY: 233,
              hour_posX: 42,
              hour_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'oyemi_sec.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 13,
              second_posY: 232,
              second_cover_path: 'Picture1.png',
              second_cover_x: 215,
              second_cover_y: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -33,
              src: 'Shadow ring 239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF030303',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Ana_aob_min.png',
              minute_centerX: 232,
              minute_centerY: 233,
              minute_posX: 42,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Ana_aob_hr.png',
              hour_centerX: 232,
              hour_centerY: 233,
              hour_posX: 43,
              hour_posY: 168,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -11,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  