﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_wind_icon_img = ''
        let idle_wind_text_text_img = ''
        let idle_altimeter_icon_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_humidity_icon_img = ''
        let idle_humidity_text_text_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_high_separator_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 364,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 2,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 362,
              src: '100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 396,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 2,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 393,
              src: '101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 296,
              y: 358,
              image_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 122,
              y: 367,
              src: '132.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 146,
              src: '018.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 53,
              src: '033.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 56,
              src: '032.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 348,
              year_startY: 274,
              year_sc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_tc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_en_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 278,
              month_sc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_tc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_en_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 274,
              day_sc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_tc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_en_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 279,
              week_en: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              week_tc: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              week_sc: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 379,
              y: 249,
              src: '155.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 237,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 389,
              y: 184,
              src: '029.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 172,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 380,
              y: 217,
              src: '030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 205,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 319,
              w: 136,
              h: 20,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 238,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 224,
              src: '099.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 187,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 173,
              src: '098.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 171,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 205,
              image_array: ["066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png","088.png","089.png","090.png","091.png","092.png","093.png","094.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 247,
              src: '065.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 237,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 204,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              dot_image: '005.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 209,
              src: '031.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 176,
              src: '002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 170,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 316,
              font_array: ["019.png","020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 375,
              y: 313,
              src: '004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 61,
              y: 313,
              src: '003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 319,
              font_array: ["019.png","020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 334,
              src: '053.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 98,
              hour_array: ["134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              hour_zero: 0,
              hour_space: 1,
              hour_unit_sc: '144.png',
              hour_unit_tc: '144.png',
              hour_unit_en: '144.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 315,
              second_startY: 111,
              second_array: ["145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 364,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 2,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 362,
              src: '100.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 396,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 2,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 393,
              src: '101.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 296,
              y: 358,
              image_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 122,
              y: 367,
              src: '132.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 146,
              src: '018.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 53,
              src: '033.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 56,
              src: '032.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 348,
              year_startY: 274,
              year_sc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_tc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_en_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 278,
              month_sc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_tc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_en_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 274,
              day_sc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_tc_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_en_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 279,
              week_en: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              week_tc: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              week_sc: ["034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 379,
              y: 249,
              src: '155.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 237,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 389,
              y: 184,
              src: '029.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 172,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 380,
              y: 217,
              src: '030.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 205,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 319,
              w: 136,
              h: 20,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 238,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 224,
              src: '099.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 187,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 173,
              src: '098.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 171,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              unit_sc: '007.png',
              unit_tc: '007.png',
              unit_en: '007.png',
              negative_image: '006.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 205,
              image_array: ["066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png","088.png","089.png","090.png","091.png","092.png","093.png","094.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 247,
              src: '065.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 237,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 204,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              dot_image: '005.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 209,
              src: '031.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 176,
              src: '002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 170,
              font_array: ["008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 316,
              font_array: ["019.png","020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 375,
              y: 313,
              src: '004.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 61,
              y: 313,
              src: '003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 319,
              font_array: ["019.png","020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 334,
              src: '053.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 98,
              hour_array: ["134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              hour_zero: 0,
              hour_space: 1,
              hour_unit_sc: '144.png',
              hour_unit_tc: '144.png',
              hour_unit_en: '144.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 315,
              second_startY: 111,
              second_array: ["145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 30,
              w: 80,
              h: 70,
              src: '133.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 352,
              w: 160,
              h: 80,
              src: '133.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 171,
              w: 97,
              h: 98,
              src: '133.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 166,
              w: 80,
              h: 98,
              src: '133.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 294,
              w: 113,
              h: 79,
              src: '133.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 163,
              w: 108,
              h: 100,
              src: '133.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
