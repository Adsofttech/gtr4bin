﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        // смена безеля
        let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 4
 
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Безель> " + parseInt(bezel_num) });
                  bezel_img.setProperty(hmUI.prop.SRC, "Bezel_" + parseInt(bezel_num) + ".png");
            }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
                bezel_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'Bezel_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 379,
              src: 'bth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 268,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 156,
              y: 151,
              w: 146,
              h: 29,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 115,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              negative_image: '59.png',
              invalid_image: '59.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 115,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              negative_image: '59.png',
              invalid_image: '59.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 95,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              negative_image: '59.png',
              invalid_image: '59.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 92,
              image_array: ["wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png","wz_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 190,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              unit_sc: '72.png',
              unit_tc: '72.png',
              unit_en: '72.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 394,
              y: 173,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_8.png","bay_7.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 190,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 173,
              image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 247,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 247,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 349,
              month_sc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_tc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_en_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 184,
              day_startY: 349,
              day_sc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_tc_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_en_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '33.png',
              day_unit_tc: '33.png',
              day_unit_en: '33.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 316,
              week_en: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              week_tc: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              week_sc: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 29,
              hour_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 29,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '3.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 27,
              second_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 336,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
               click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 29,
              hour_posY: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 29,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Нет связи !,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Нет связи !"});
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 140,
              w: 97,
              h: 97,
              src: 'null.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 67,
              w: 97,
              h: 97,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 238,
              w: 97,
              h: 97,
              src: 'null.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 140,
              w: 97,
              h: 97,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 238,
              w: 97,
              h: 97,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
