﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_stress_icon_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

//Start background change
        let btnbackground = ''
        let backgroundnumber = 0
        let totalpictures = 7

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=0;
                UpdateBackground();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==1) {
                  UpdateBackground();
                }
				if(backgroundnumber==2) {
                  UpdateBackground();
                }
                if(backgroundnumber==3) {
                  UpdateBackground();
                }
				if(backgroundnumber==4) {
                  UpdateBackground();
                }
				if(backgroundnumber==5) {
                  UpdateBackground();
                }
                if(backgroundnumber==6) {
                  UpdateBackground();
                }
				if(backgroundnumber==7) {
                  UpdateBackground();
                }
            }
            {
                 if(backgroundnumber==1) hmUI.showToast({text: 'CYAN STYLE'});
				 if(backgroundnumber==2) hmUI.showToast({text: 'AMBER STYLE'});
                 if(backgroundnumber==3) hmUI.showToast({text: 'GREEN STYLE'});
				 if(backgroundnumber==4) hmUI.showToast({text: 'ORANGE STYLE'});
				 if(backgroundnumber==5) hmUI.showToast({text: 'BLUE STYLE'});
                 if(backgroundnumber==6) hmUI.showToast({text: 'PURPLE STYLE'});
				 if(backgroundnumber==7) hmUI.showToast({text: 'COLORLESS'});
            }
            if(backgroundnumber==0) hmUI.showToast({text: 'RED STYLE'});
        }


        function UpdateBackground(){

                normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(backgroundnumber) + ".png");
				call_change_Hands();
        }
//END background change
//Change hands called by backgroundcolor
        function call_change_Hands() {
              if(backgroundnumber==1) {
                ChangeHands(1);
              } else if(backgroundnumber==2) {
                ChangeHands(2);
              } else if(backgroundnumber==3) {
                ChangeHands(3);
              } else if(backgroundnumber==4) {
                ChangeHands(4);
			  } else if(backgroundnumber==5) {
                ChangeHands(5);
              } else if(backgroundnumber==6) {
                ChangeHands(6);
              } else if(backgroundnumber==7) {
                ChangeHands(7);
              } else if(backgroundnumber==0) {
                ChangeHands(0);
              }
        }
		
		function ChangeHands(number) {
           if(number==1) {
				  hourstring='t_hour1.png';
				  minstring='t_min1.png';
                  secstring='t_sec1.png';
             } else if(number==2) {
                  hourstring='t_hour2.png';
				  minstring='t_min2.png';
                  secstring='t_sec2.png';
             } else if(number==3) {
                  hourstring='t_hour3.png';
				  minstring='t_min3.png';
                  secstring='t_sec3.png';
             } else if(number==4) {
                  hourstring='t_hour4.png';
				  minstring='t_min4.png';
                  secstring='t_sec4.png';
             } else if(number==5) {
                  hourstring='t_hour5.png';
				  minstring='t_min5.png';
                  secstring='t_sec5.png';
			 } else if(number==6) {
                  hourstring='t_hour6.png';
				  minstring='t_min6.png';
                  secstring='t_sec6.png';
             } else if(number==7) {
                  hourstring='t_hour7.png';
				  minstring='t_min7.png';
                  secstring='t_sec7.png';
             } else {
                  hourstring='t_hour0.png';
				  minstring='t_min0.png';
                  secstring='t_sec0.png';
             }
              
			  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minstring,
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 11,
              minute_posY: 190,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 14,
              second_posY: 199,
              second_cover_path: 't_point.png',
              second_cover_x: 216,
              second_cover_y: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }
//END hands change
//Start NO Hands
        let btnchangepointer = ''
        let pointernumber = 0
        let totalpointer = 1

        function click_Changepointer() {
          pointernumber=pointernumber+1;
          switch (pointernumber) {
            case 1:
              Changepointer(1); break;
            default:
              Changepointer(0); pointernumber=0;
          }
          if(pointernumber==1) hmUI.showToast({text: 'Digital Only'});
		  if(pointernumber==0) hmUI.showToast({text: 'Hybrid Watch'});
        }

	// Give contentnumber. Must exist
        function Changepointer(number) {
           if(number==1) {
                  UpdatepointerNo();
			 } else {
                  UpdatepointerBoth();
             }
        }
		
        function UpdatepointerNo(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }

		function UpdatepointerBoth(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }	
//END NO Hands
//START AOD CHANGE

        let btn_aod = ''
		let curAODmode = 0;		// 0 - Display OFF
                                // 1 - Full AOD
								// 2 - Normal AOD
								// 3 - Minimal AOD
								

        let AODmodes = ["Display OFF", "Full", "Normal", "Minimal"];
        let AODmodeCaption;

        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = "Display OFF";
                    break;
                case 1:
                    AODmodeCaption = "Full AOD";
                    break;
                case 2:
                    AODmodeCaption = "Normal AOD";
                    break;
				case 3:
                    AODmodeCaption = "Minimal AOD";
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
        }

        function makeAOD() {

            let mode = hmFS.SysProGetInt('parkur_aod');
			
            if (mode == 1) {    // Full AOD
			
			
          idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 136,
              year_startY: 236,
              year_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 91,
              month_startY: 236,
              month_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'small_10.png',
              month_unit_tc: 'small_10.png',
              month_unit_en: 'small_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 48,
              day_startY: 236,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'small_10.png',
              day_unit_tc: 'small_10.png',
              day_unit_en: 'small_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 202,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 356,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 45,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 46,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 95,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 150,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'middle_14.png',
              dot_image: 'middle_17.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 150,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_16.png',
              unit_tc: 'middle_16.png',
              unit_en: 'middle_16.png',
              negative_image: 'middle_15.png',
              invalid_image: 'middle_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 94,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 93,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 37,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 359,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 359,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 401,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 370,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 216,
              src: 't_point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 292,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 408,
              am_y: 209,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 408,
              pm_y: 209,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 208,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 348,
              minute_startY: 208,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 208,
              src: 'big_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 292,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_11.png',
              unit_tc: 'middle_11.png',
              unit_en: 'middle_11.png',
              imperial_unit_sc: 'middle_12.png',
              imperial_unit_tc: 'middle_12.png',
              imperial_unit_en: 'middle_12.png',
              dot_image: 'middle_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour7.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min7.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 11,
              minute_posY: 190,
              minute_cover_path: 't_point.png',
              minute_cover_x: 216,
              minute_cover_y: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			}

            if (mode == 2) {	// Normal AOD
			
			 idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 136,
              year_startY: 236,
              year_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 91,
              month_startY: 236,
              month_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'small_10.png',
              month_unit_tc: 'small_10.png',
              month_unit_en: 'small_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 48,
              day_startY: 236,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'small_10.png',
              day_unit_tc: 'small_10.png',
              day_unit_en: 'small_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 202,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 356,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 45,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 46,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 93,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 53,
              image_array: ["aod_batt01.png","aod_batt02.png","aod_batt03.png","aod_batt04.png","aod_batt05.png","aod_batt06.png","aod_batt07.png","aod_batt08.png","aod_batt09.png","aod_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 408,
              am_y: 209,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 408,
              pm_y: 209,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 208,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 348,
              minute_startY: 208,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 208,
              src: 'big_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour7.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min7.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 11,
              minute_posY: 190,
              minute_cover_path: 't_point.png',
              minute_cover_x: 216,
              minute_cover_y: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			}

            if (mode == 3) {	// Minimal AOD
			
			idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 356,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 45,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 46,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_analog.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 93,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 53,
              image_array: ["aod_batt01.png","aod_batt02.png","aod_batt03.png","aod_batt04.png","aod_batt05.png","aod_batt06.png","aod_batt07.png","aod_batt08.png","aod_batt09.png","aod_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour7.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min7.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 11,
              minute_posY: 190,
              minute_cover_path: 't_point.png',
              minute_cover_x: 216,
              minute_cover_y: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			}
      }

        function loadSettings() {
            if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                curAODmode = 1;
                hmFS.SysProSetInt('parkur_aod', curAODmode);
            } else {
                curAODmode = hmFS.SysProGetInt('parkur_aod');
            }
        }
//END AOD CHANGE
//START Change Language
        let dayArray = null
        let ln = 0
        let btnlanguage = ''
        let languagenumber = 0
        let totallanguages = 5
        let langchange = false

        function click_Language() {
            languagenumber=(languagenumber+1) % (totallanguages+1);
            showlanguageonscreen();

            call_change_Language(languagenumber);

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 68,
              y: 202,
              week_en: DayArray,
              week_tc: DayArray,
              week_sc: DayArray,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//langchange will not work without going out of the screen.
            langchange=true;
            const result = hmSetting.setScreenOff();
        }

        function showlanguageonscreen() {
              if(languagenumber==0) hmUI.showToast({text: 'English'});
              if(languagenumber==1) hmUI.showToast({text: 'Deutsch'});
              if(languagenumber==2) hmUI.showToast({text: 'Русский'});
              if(languagenumber==3) hmUI.showToast({text: 'Polska'});
			  if(languagenumber==4) hmUI.showToast({text: 'Ελληνική'});
			  if(languagenumber==5) hmUI.showToast({text: 'Français'});
        }

        function call_change_Language(ln) {
            dayArray=null;
            DayArray = ["wd" + parseInt(ln) + "_01.png",
                        "wd" + parseInt(ln) + "_02.png",
                        "wd" + parseInt(ln) + "_03.png",
                        "wd" + parseInt(ln) + "_04.png",
                        "wd" + parseInt(ln) + "_05.png",
                        "wd" + parseInt(ln) + "_06.png",
                        "wd" + parseInt(ln) + "_07.png"]
        }	
//END Change Language
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
//initialize default language
            call_change_Language(0);                          
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 136,
              year_startY: 236,
              year_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 91,
              month_startY: 236,
              month_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'small_10.png',
              month_unit_tc: 'small_10.png',
              month_unit_en: 'small_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 48,
              day_startY: 236,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'small_10.png',
              day_unit_tc: 'small_10.png',
              day_unit_en: 'small_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 68,
              y: 202,
              week_en: ["wd0_01.png","wd0_02.png","wd0_03.png","wd0_04.png","wd0_05.png","wd0_06.png","wd0_07.png"],
              week_tc: ["wd0_01.png","wd0_02.png","wd0_03.png","wd0_04.png","wd0_05.png","wd0_06.png","wd0_07.png"],
              week_sc: ["wd0_01.png","wd0_02.png","wd0_03.png","wd0_04.png","wd0_05.png","wd0_06.png","wd0_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: 356,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 45,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 46,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 95,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 150,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'middle_14.png',
              dot_image: 'middle_17.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 150,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_16.png',
              unit_tc: 'middle_16.png',
              unit_en: 'middle_16.png',
              negative_image: 'middle_15.png',
              invalid_image: 'middle_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 94,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 93,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 37,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 359,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 359,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 401,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 370,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 216,
              src: 't_point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 105,
              // start_y: 336,
              // color: 0xFF000000,
              // pointer: 'pointer.png',
              // lenght: 261,
              // line_width: 7,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 292,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 292,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_11.png',
              unit_tc: 'middle_11.png',
              unit_en: 'middle_11.png',
              imperial_unit_sc: 'middle_12.png',
              imperial_unit_tc: 'middle_12.png',
              imperial_unit_en: 'middle_12.png',
              dot_image: 'middle_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 408,
              am_y: 209,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 408,
              pm_y: 209,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 208,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 348,
              minute_startY: 208,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 208,
              src: 'big_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 11,
              minute_posY: 190,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec0.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 14,
              second_posY: 199,
              second_cover_path: 't_point.png',
              second_cover_x: 216,
              second_cover_y: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
//START Button Shortcuts
		//START AOD Button (right)
			btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 405,
              y: 194,
              text: '',
              w: 60,
              h: 78,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
                toggleAODmode();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btn_aod.setProperty(hmUI.prop.VISIBLE, true);
		//END AOD Button
		//START Hands Button (middle)
			btnchangepointer = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 194,
              y: 194,
              text: '',
              w: 78,
              h: 78,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
                click_Changepointer();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnchangepointer.setProperty(hmUI.prop.VISIBLE, true);
		//END Hands Button
		//START Language Button (top)
			btnlanguage = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 0,
              text: '',
              w: 78,
              h: 60,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Language();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnlanguage.setProperty(hmUI.prop.VISIBLE, true);
		//END Language Button
		//START background shortcut start (left)
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 194,
              text: '',
              w: 60,
              h: 78,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Background();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
		//END background shortcut end
//END Button Shortcuts
            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 194,
              w: 63,
              h: 78,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 194,
              w: 63,
              h: 78,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//START Battery Shortcut            
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 63,
              w: 136,
              h: 121,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
            });
//END Battery Shortcut

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 87,
              w: 97,
              h: 97,
              src: 'blank.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 194,
              w: 126,
              h: 78,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
//END Calendar Shortcut 
            
            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 87,
              w: 97,
              h: 97,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 277,
              w: 165,
              h: 53,
              src: 'blank.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 350,
              w: 97,
              h: 58,
              src: 'blank.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 350,
              w: 97,
              h: 58,
              src: 'blank.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 350,
              w: 107,
              h: 87,
              src: 'blank.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 277,
              w: 165,
              h: 53,
              src: 'blank.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 366;
                  let start_y_normal_step = 336;
                  let lenght_ls_normal_step = -261;
                  let line_width_ls_normal_step = 7;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 16;
                  let pointer_offset_y_ls_normal_step = 16;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();
				if (langchange) {
                             showlanguageonscreen();
                             langchange=false;
                       }
              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
				const currentScreenType = hmSetting.getScreenType();
                switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}