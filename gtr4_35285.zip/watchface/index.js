﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start
    let normal_stopwatch_jumpable_img_click = "";
    let normal_countdown_jumpable_img_click = "";
    let normal_alarm_jumpable_img_click = "";
    let normal_heart_jumpable_img_click = "";
    let normal_step_jumpable_img_click = "";
    const heart = hmSensor.createSensor(hmSensor.id.HEART);
    const step = hmSensor.createSensor(hmSensor.id.STEP);
    const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
    let hour_string = "";
    let ampm_text = "";
    let minute_string = "";
    let bpm_string = "";
    let point_string = ":";
    let step_string = "";
    let bat_string = "";
    let day_string = "";
    let hour_text = "";
    let minute_text = "";
    let pulse_text = "";
    let day_text = "";
    let battery_text = "";
    let step_text = "";
    let step_text_img = "";
    let idle_step_text_img = "";
    let point_text = "";
    let color_btn = "";
    let normal_background_bg = "";
    let idle_background_bg_img = "";
    let normal_battery_linear_scale = "";
    let normal_battery_linear_fill = "";
    let normal_image_img = "";
    let normal_analog_clock_pro_second_pointer_img = "";
    let normal_timerUpdateSecSmooth = undefined;
    let timeSensor = "";
    let color_num = 0;
    let sec_string = "";
    let color_array = [
      0xe59d9a, 0xd26f1f, 0x9fde57, 0x22be89, 0x7abbd2, 0x3d72fd, 0xa05ba4,
      0xf01f28,
    ];
    let week_string = ["пнд", "втр", "срд", "чтв", "птн", "сбт", "вск"];
    let month_string = [
      "янв",
      "фев",
      "мар",
      "апр",
      "мая",
      "июн",
      "июл",
      "авг",
      "сен",
      "окт",
      "ноя",
      "дек,",
    ];
    const timeFormat = hmSetting.getTimeFormat();

    function color_change() {
      color_num++;
      if (color_num > 7) color_num = 0;
      hmUI.showToast({ text: "Цвет " + parseInt(color_num + 1) });
      //цвет фона
      normal_background_bg.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        color: color_array[color_num],
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      //цвет индикатора батареи
      normal_battery_linear_scale.setProperty(
        hmUI.prop.COLOR,
        color_array[color_num]
      );
      //цвет секундной стрелки
      sec_string = "sec_" + parseInt(color_num) + ".png";
      normal_analog_clock_pro_second_pointer_img.setProperty(
        hmUI.prop.SRC,
        sec_string
      );
      //цвет разделителя времени :
      point_text.setProperty(hmUI.prop.MORE, {
        color: color_array[color_num],
      });
      //цвет шагов
      step_text_img.setProperty(hmUI.prop.MORE, {
        color: color_array[color_num],
      });
      ampm_text.setProperty(hmUI.prop.MORE, {
        color: color_array[color_num],
      });
    }
    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start
        let wfScreen =
          hmSetting.getScreenType() == hmSetting.screen_type.WATCHFACE;
        let aodScreen = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
        let editScreen =
          hmSetting.getScreenType() == hmSetting.screen_type.SETTINGS;
        const now = hmSensor.createSensor(hmSensor.id.TIME);

        // SMOOTH SECONDS Definition
        let second_centerX = 233;
        let second_centerY = 233;
        let second_posX = 233;
        let second_posY = 233;
        let second_path = "sec_0.png";
        // ----------------------------
        let sec_pointer;
        let clock_timer;
        let animAngle = 0;
        let animDelay = 0;
        const animFps = 12; // Frames per second
        const animRepeat = 1000 / animFps; // then execute every <animRepeat>ms
        const deviceInfo = hmSetting.getDeviceInfo(); // Needed for automatic screen size detection
        // SMOOTH SECONDS Definition End

        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          color: color_array[color_num],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "bkg_aod.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "bkg_mask.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(
          hmUI.widget.IMG,
          {
            x: 0,
            y: 0,
            w: deviceInfo.width,
            h: deviceInfo.height,
            pos_x: second_centerX - second_posX,
            pos_y: second_centerY - second_posY,
            center_x: second_centerX,
            center_y: second_centerY,
            src: second_path,
            angle: 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        ampm_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 350,
          y: 102,
          w: 50,
          h: 22,
          color: color_array[color_num],
          text_size: 22,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: "AM",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        hour_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 110,
          y: 42,
          w: 120,
          h: 90,
          color: 0xffffff,
          text_size: 90,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: hour_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        minute_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 236,
          y: 42,
          w: 120,
          h: 90,
          color: 0xffffff,
          text_size: 90,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: minute_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        point_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 213,
          y: 42,
          w: 40,
          h: 90,
          color: color_array[color_num],
          text_size: 90,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: point_string,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        day_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 84,
          y: 137,
          w: 300,
          h: 36,
          color: 0xffffff,
          text_size: 36,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: day_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        battery_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 195,
          y: 196,
          w: 80,
          h: 20,
          color: 0xffffff,
          text_size: 20,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: bat_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        step_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 345,
          y: 235,
          w: 100,
          h: 30,
          color: 0xffffff,
          text_size: 25,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: step_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        step_text_img = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 345,
          y: 210,
          w: 100,
          h: 22,
          color: color_array[color_num],
          text_size: 22,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: "ШАГИ",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_step_text_img = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 345,
          y: 210,
          w: 100,
          h: 22,
          color: 0xc1c1c1,
          text_size: 22,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: "ШАГИ",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        pulse_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 345,
          y: 286,
          w: 100,
          h: 30,
          color: 0xffffff,
          text_size: 25,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/product_sans_thin.ttf",
          text: bpm_string,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        normal_heart_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 360,
            y: 281,
            w: 70,
            h: 70,
            type: hmUI.data_type.HEART,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_step_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 360,
            y: 201,
            w: 70,
            h: 70,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 258,
            y: 55,
            w: 70,
            h: 70,
            type: hmUI.data_type.STOP_WATCH,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_countdown_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 136,
            y: 55,
            w: 70,
            h: 70,
            type: hmUI.data_type.COUNT_DOWN,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_alarm_jumpable_img_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          {
            x: 199,
            y: 132,
            w: 70,
            h: 70,
            type: hmUI.data_type.ALARM_CLOCK,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        function updateBattery() {
          bat_string = String(battery.current) + "%";
          battery_text.setProperty(hmUI.prop.MORE, {
            text: bat_string,
          });
        }

        function updateSteps() {
          step_string = String(step.current);
          step_text.setProperty(hmUI.prop.MORE, {
            text: step_string,
          });
        }

        function updatePulse() {
          bpm_string = String(heart.last);
          pulse_text.setProperty(hmUI.prop.MORE, {
            text: bpm_string,
          });
        }

        function updateDay() {
          day_string =
            week_string[now.week - 1] +
            " " +
            now.day.toString() +
            " " +
            month_string[now.month - 1];
          day_text.setProperty(hmUI.prop.MORE, {
            text: day_string,
          });
        }

        function TimeUpdate() {
          const hrt = now.hour;
          const hr = now.format_hour.toString();
          const min = now.minute.toString();
          if (wfScreen) {
            if (hrt >= 12) {
              ampm_text.setProperty(hmUI.prop.TEXT, "PM");
              ampm_text.setProperty(hmUI.prop.COLOR, color_array[color_num]);
            } else {
              ampm_text.setProperty(hmUI.prop.TEXT, "AM");
              ampm_text.setProperty(hmUI.prop.COLOR, color_array[color_num]);
            }
          }
          if (aodScreen) {
            if (hrt > 12) {
              ampm_text.setProperty(hmUI.prop.TEXT, "PM");
              ampm_text.setProperty(hmUI.prop.COLOR, 0xc1c1c1);
            } else {
              ampm_text.setProperty(hmUI.prop.TEXT, "AM");
              ampm_text.setProperty(hmUI.prop.COLOR, 0xc1c1c1);
            }
          }
          hour_string = hr.padStart(2, "0");
          hour_text.setProperty(hmUI.prop.TEXT, hour_string);
          minute_string = min.padStart(2, "0");
          minute_text.setProperty(hmUI.prop.TEXT, minute_string);
          updateDay();
          updateBattery();
          updatePulse();
          updateSteps();
        }

        function scale_call() {
          //console.log("update scales BATTERY");

          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_ls_normal_battery = progressBattery;

          // normal_battery_linear_scale
          // initial parameters
          let start_x_normal_battery = 133;
          let start_y_normal_battery = 185;
          let lenght_ls_normal_battery = 200;
          let line_width_ls_normal_battery = 5;
          let color_ls_normal_battery = color_array[color_num];

          // calculated parameters
          let start_x_normal_battery_draw = start_x_normal_battery;
          let start_y_normal_battery_draw = start_y_normal_battery;
          lenght_ls_normal_battery =
            lenght_ls_normal_battery * progress_ls_normal_battery;
          let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
          55;
          if (lenght_ls_normal_battery < 0) {
            lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
            start_x_normal_battery_draw =
              start_x_normal_battery - lenght_ls_normal_battery_draw;
          }
          if (wfScreen) {
            normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
              x: 133,
              y: 185,
              w: lenght_ls_normal_battery_draw,
              h: 5,
              radius: 2,
              color: color_ls_normal_battery,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
          }
          if (aodScreen) {
            normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
              x: 133,
              y: 185,
              w: lenght_ls_normal_battery_draw,
              h: 5,
              radius: 2,
              color: 0xffffff,
              show_level: hmUI.show_level.ONLY_AOD,
            });
          }
        }

        now.addEventListener(now.event.MINUTEEND, function () {
          if (aodScreen) {
            scale_call();
            TimeUpdate();
          }
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            scale_call();
            //TimeUpdate();
            if (!clock_timer) {
              //console.log("createTimer");
              clock_timer = timer.createTimer(
                animDelay,
                animRepeat,
                function (option) {
                  animAngle = now.second * 6 + ((now.utc % 1000) / 1000) * 6;
                  normal_analog_clock_pro_second_pointer_img.setProperty(
                    hmUI.prop.ANGLE,
                    animAngle
                  );
                  TimeUpdate();
                }
              );
            }
          },
          pause_call: function () {
            if (clock_timer) {
              scale_call();
              timer.stopTimer(clock_timer);
              clock_timer = undefined;
              //console.log("stopTimer");
              TimeUpdate();
            }
          },
        });

        color_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 177,
          y: 316,
          w: 100,
          h: 100,
          text: "",
          normal_src: "transparent.png",
          press_src: "transparent.png",
          click_func: () => {
            //vibro();
            color_change();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        color_btn.setProperty(hmUI.prop.VISIBLE, true);

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
