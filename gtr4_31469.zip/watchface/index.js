﻿/*
** Watch_Face_Editor tool
** watchface js version v2.0.1
** Copyright © CashaCX75. All Rights Reserved
** Created by StarRrScreaM [4pda]
*/

try {
    (() => {
        //dynamic modify start


        let normal_humidity_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_pai_icon_img = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_humidity_icon_img = ''

        let hsTimer = null;
        let hsTimer_reverse = null;
        let now = hmSensor.createSensor(hmSensor.id.TIME);

        let screenType = hmSetting.getScreenType();

        function DisplaySeconds() {

            let cs = (now.second * 6 + 6 * (now.utc % 1000) / 1000) * 8;

            normal_humidity_icon_img.setProperty(hmUI.prop.MORE, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                pos_x: 0,
                pos_y: 0,
                center_x: 233,
                center_y: 233,
                src: 'bg_anim.png',
                angle: cs,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
            , { px: i } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o)),
                e.__globals__)
            , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

                normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    pos_x: 233,
                    pos_y: 233,
                    center_x: 233,
                    center_y: 233,
                    src: 'bg_anim.png',
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                DisplaySeconds();
                hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});

                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 18,
                    hour_startY: 137,
                    hour_array: ["b_0.png", "b_1.png", "b_2.png", "b_3.png", "b_4.png", "b_5.png", "b_6.png", "b_7.png", "b_8.png", "b_9.png"],
                    hour_zero: 1,
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,

                    minute_startX: 18,
                    minute_startY: 233,
                    minute_array: ["b_0.png", "b_1.png", "b_2.png", "b_3.png", "b_4.png", "b_5.png", "b_6.png", "b_7.png", "b_8.png", "b_9.png"],
                    minute_zero: 1,
                    minute_space: 0,
                    minute_follow: 0,
                    minute_align: hmUI.align.CENTER_H,

                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'bg.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });


                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    second_startX: 250,
                    second_startY: 140,
                    second_array: ["d44_0.png", "d44_1.png", "d44_2.png", "d44_3.png", "d44_4.png", "d44_5.png", "d44_6.png", "d44_7.png", "d44_8.png", "d44_9.png"],
                    second_zero: 1,
                    second_space: -3,
                    second_follow: 0,
                    second_align: hmUI.align.CENTER_H,

                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 248,
                    y: 406,
                    anim_path: "animation",
                    anim_ext: "png",
                    anim_prefix: "anim_pulse",
                    anim_fps: 21,
                    anim_size: 25,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 266,
                    y: 403,
                    font_array: ["d28_0.png", "d28_1.png", "d28_2.png", "d28_3.png", "d28_4.png", "d28_5.png", "d28_6.png", "d28_7.png", "d28_8.png", "d28_9.png"],
                    padding: false,
                    h_space: -3,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 247,
                    y: 228,
                    font_array: ["d18_0.png", "d18_1.png", "d18_2.png", "d18_3.png", "d18_4.png", "d18_5.png", "d18_6.png", "d18_7.png", "d18_8.png", "d18_9.png"],
                    padding: false,
                    h_space: -3,
                    unit_sc: 'd18_11.png',
                    unit_tc: 'd18_11.png',
                    unit_en: 'd18_11.png',
                    negative_image: 'd18_10.png',
                    align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 298,
                    y: 131,
                    image_array: ["w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png", "w_29.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 245,
                    y: 300,
                    font_array: ["d28_0.png", "d28_1.png", "d28_2.png", "d28_3.png", "d28_4.png", "d28_5.png", "d28_6.png", "d28_7.png", "d28_8.png", "d28_9.png"],
                    padding: false,
                    h_space: -3,
                    unit_sc: 'd28_proc.png',
                    unit_tc: 'd28_proc.png',
                    unit_en: 'd28_proc.png',
                    align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 245,
                    y: 358,
                    font_array: ["d44w30_0.png","d44w30_1.png","d44w30_2.png","d44w30_3.png","d44w30_4.png","d44w30_5.png","d44w30_6.png","d44w30_7.png","d44w30_8.png","d44w30_9.png"],
                    padding: false,
                    h_space: 0,
                    align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 247,
                    y: 256,
                    week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                    week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                    week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 348,
                    day_startY: 88,
                    day_sc_array: ["d33_0.png", "d33_1.png", "d33_2.png", "d33_3.png", "d33_4.png", "d33_5.png", "d33_6.png", "d33_7.png", "d33_8.png", "d33_9.png"],
                    day_tc_array: ["d33_0.png", "d33_1.png", "d33_2.png", "d33_3.png", "d33_4.png", "d33_5.png", "d33_6.png", "d33_7.png", "d33_8.png", "d33_9.png"],
                    day_en_array: ["d33_0.png", "d33_1.png", "d33_2.png", "d33_3.png", "d33_4.png", "d33_5.png", "d33_6.png", "d33_7.png", "d33_8.png", "d33_9.png"],
                    day_zero: 1,
                    day_space: 0,
                    day_align: hmUI.align.CENTER_H,
                    day_is_character: false,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 243,
                    month_startY: 89,
                    month_sc_array: ["m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png", "m_12.png"],
                    month_tc_array: ["m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png", "m_12.png"],
                    month_en_array: ["m_1.png", "m_2.png", "m_3.png", "m_4.png", "m_5.png", "m_6.png", "m_7.png", "m_8.png", "m_9.png", "m_10.png", "m_11.png", "m_12.png"],
                    month_is_character: true,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: 'aod_bg.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 18,
                    hour_startY: 137,
                    hour_array: ["b_aod_0.png", "b_aod_1.png", "b_aod_2.png", "b_aod_3.png", "b_aod_4.png", "b_aod_5.png", "b_aod_6.png", "b_aod_7.png", "b_aod_8.png", "b_aod_9.png"],
                    hour_zero: 1,
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,

                    minute_startX: 18,
                    minute_startY: 233,
                    minute_array: ["b_aod_0.png", "b_aod_1.png", "b_aod_2.png", "b_aod_3.png", "b_aod_4.png", "b_aod_5.png", "b_aod_6.png", "b_aod_7.png", "b_aod_8.png", "b_aod_9.png"],
                    minute_zero: 1,
                    minute_space: 0,
                    minute_follow: 0,
                    minute_align: hmUI.align.CENTER_H,

                    show_level: hmUI.show_level.ONLY_AOD,
                });

                idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'aod_mask.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
                // disconneсnt_vibrate_type: 9,
                // disconneсnt_toast_text: Связь потеряна,
                // conneсnt_vibrate_type: 0,
                // conneсnt_toast_text: Связь восстановлена,
                // });

                // vibration when connecting or disconnecting

                function checkConnection() {
                    hmBle.removeListener;
                    hmBle.addListener(function (status) {
                        if (!status) {
                            hmUI.showToast({ text: "Связь потеряна" });
                            vibro(9);
                        }
                        if (status) {
                            hmUI.showToast({ text: "Связь восстановлена" });
                            vibro(0);
                        }
                    });
                }

                // end vibration when connecting or disconnecting
                // vibrate function

                const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
                let timer_StopVibrate = null;


                function vibro(scene = 25) {
                    let stopDelay = 50;
                    stopVibro();
                    vibrate.scene = scene;
                    if (scene < 23 || scene > 25) stopDelay = 1300;
                    vibrate.start();
                    timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
                }

                function stopVibro() {
                    vibrate.stop();
                    if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
                }

                // end vibrate function

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                        checkConnection();
                        stopVibro();

                        if (screenType != hmSetting.screen_type.AOD) {
                            DisplaySeconds();
                            if (hsTimer == null) hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
                        };

                    }),
                    pause_call: (function () {
                        normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
                        stopVibro();
                        timer.stopTimer(hsTimer);
                        hsTimer = null;

                    }),
                });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                    n.log("index page.js on ready invoke")
            },
            onDestroy() {
                if (hsTimer) timer.stopTimer(hsTimer);
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
        e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}
