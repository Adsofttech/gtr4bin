﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
 

	//*******************************//
	//*								*//
	//*		FORMEX REEF GTR4		*//
	//*		2023 © leXxiR 4pda		*//
	//*								*//
	//*******************************//
	

    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_image_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_system_disconnect_img = ''
        let idle_system_disconnect_img = ''
        let image_top_img = ''

		let colorIndex = 0;
		let path = String(colorIndex) + '/';
		let colorNum = 6;

		let curTime = hmSensor.createSensor(hmSensor.id.TIME);
        // плавная секундная стрелка с тенью
        let second_centerX = 233;
        let second_centerY = 233;
        let second_posX = 16;
        let second_posY = 231;
        let secPointer_img = 'hand_S.png';
        let sec_pointer;
        let shadow_shift_centerX = 9;
        let shadow_shift_centerY = 2;
        let shadow_posX = 22;
        let shadow_posY = 232;		
		let shadow_img = 'hand_S_shadow.png';
		let shadow_sec_pointer;

        let secPointer_timer = undefined;
        let secPointerAngle = 0;
        let animDelay = 0;
		let animRepeat = 1000;
        const deviceInfo = hmSetting.getDeviceInfo();

        function setSecPointerAnim(sec, animDuration) {
		  let secAnimProps = {
            anim_steps: [{
              anim_rate: 'linear',
              anim_duration: animDuration,
              anim_from: sec,
              anim_to: sec + (animDuration * 6 / 1000),
              anim_key: 'angle',
            }],
            anim_fps: 25,
            anim_auto_start: 1,
            anim_repeat: 1,
            anim_auto_destroy: 1,
          }
          sec_pointer.setProperty(hmUI.prop.ANIM, secAnimProps);
		  shadow_sec_pointer.setProperty(hmUI.prop.ANIM, secAnimProps);
        }
	
        function startSecPointerAnim() {
			secPointerAngle = (curTime.second + (curTime.utc % 1000) / 1000) * 6;
			sec_pointer.setProperty(hmUI.prop.ANGLE, secPointerAngle);
			shadow_sec_pointer.setProperty(hmUI.prop.ANGLE, secPointerAngle);
			sec_pointer.setProperty(hmUI.prop.VISIBLE, true);
			shadow_sec_pointer.setProperty(hmUI.prop.VISIBLE, true);
			setSecPointerAnim(secPointerAngle, animRepeat);
			
			if (secPointer_timer) timer.stopTimer(secPointer_timer);
			animDelay = 1000 - curTime.utc % 1000;
			secPointer_timer = timer.createTimer(animDelay, animRepeat, (function (option) {
				secPointerAngle = (curTime.second + (curTime.utc % 1000) / 1000) * 6;
				setSecPointerAnim(secPointerAngle, animRepeat);
			}));
        }

        function stopSecPointerAnim() {
            sec_pointer.setProperty(hmUI.prop.VISIBLE, false);
			shadow_sec_pointer.setProperty(hmUI.prop.VISIBLE, false);
			if (secPointer_timer) {
              timer.stopTimer(secPointer_timer);
              secPointer_timer = undefined;
            }
		}

		function loadSettings() {
			if (hmFS.SysProGetInt('freef_colorIndex') === undefined) {
				colorIndex = 0;
				hmFS.SysProSetInt('freef_colorIndex', colorIndex);
			} else {
				colorIndex = hmFS.SysProGetInt('freef_colorIndex');
			}

			path = String(colorIndex) + '/';
		}

		function changeColor() {
			colorIndex = (colorIndex + 1) % colorNum;
			path = String(colorIndex) + '/';
			normal_image_img.setProperty(hmUI.prop.SRC, path + 'bg.png');
			hmFS.SysProSetInt('freef_colorIndex', colorIndex);
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 378,
              src: 'bg_date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_disk.png',
              center_x: 233,
              center_y: 233,
              posX: 182,
              posY: 182,
              start_angle: -11,
              end_angle: 349,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: path + 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 89,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_H_shadow.png',
              hour_centerX: 233+2,
              hour_centerY: 233+1,
              hour_posX: 24,
              hour_posY: 137,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_H.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 21,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_M_shadow.png',
              minute_centerX: 233+5,
              minute_centerY: 233+1,
              minute_posX: 22,
              minute_posY: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_M.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 19,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

			shadow_sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  w: deviceInfo.width,
			  h: deviceInfo.height,
			  pos_x: second_centerX - shadow_posX,
			  pos_y: second_centerY - shadow_posY,
			  center_x: second_centerX + shadow_shift_centerX,
			  center_y: second_centerY + shadow_shift_centerY,
			  src: shadow_img,
			  angle: 0,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	

			sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  w: deviceInfo.width,
			  h: deviceInfo.height,
			  pos_x: second_centerX - second_posX,
			  pos_y: second_centerY - second_posY,
			  center_x: second_centerX,
			  center_y: second_centerY,
			  src: secPointer_img,
			  angle: 0,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: 395,
				y: 40,
				w: 70,
				h: 30,
				text_size: 24,
				text: 'leXxiR',
				color: 0xffffff,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: 403,
				y: 64,
				w: 70,
				h: 30,
				text_size: 24,
				text: '4pda',
				color: 0x4bd9da,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 228,
              src: 'cover.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 378,
              src: 'bg_date.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_disk.png',
              center_x: 233,
              center_y: 233,
              posX: 182,
              posY: 182,
              start_angle: -11,
              end_angle: 349,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: path + 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 209,
              y: 91,
              src: path + 'status_bt_aod.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: path + 'hand_H_aod.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 43,
              hour_posY: 169,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: path + 'hand_M_aod.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 42,
              minute_posY: 233,
              minute_cover_path: 'cover_aod.png',
              minute_cover_x: 228,
              minute_cover_y: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 365,
              w: 80,
              h: 80,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 85,
              w: 100,
              h: 100,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				changeColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                if (screenType == hmSetting.screen_type.WATCHFACE) {
					startSecPointerAnim();
                }
              }),
              pause_call: (function () {
                stopSecPointerAnim();
              })
            });

                //dynamic modify end
            },
            onInit() {
				loadSettings();
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}