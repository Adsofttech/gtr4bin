/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let timeInterval;
		let normal_hour_high_imageset5 = '';
		let normal_hour_high_imageset5_array = ['0006.png','0007.png','0008.png'];
		let normal_hour_low_imageset6 = '';
		let normal_hour_low_imageset6_array = ['0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png','0018.png'];
		let normal_minute_high_imageset7 = '';
		let normal_minute_high_imageset7_array = ['0019.png','0020.png','0021.png','0022.png','0023.png','0024.png'];
		let normal_minute_low_imageset8 = '';
		let normal_minute_low_imageset8_array = ['0025.png','0026.png','0027.png','0028.png','0029.png','0030.png','0031.png','0032.png','0033.png','0034.png'];
		let normal_week_imageset10 = '';
		let normal_date_imagecombo11 = '';
		let normal_month_imagecombo12 = '';
		let normal_year_imagecombo13 = '';
		let normal_img14 = '';
		let normal_img15 = '';
		let normal_heart_current_imagecombo17 = '';
		let normal_steps_imagecombo19 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 47,
					y: -58,
					w: 466,
					h: 456,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -57,
					y: 147,
					w: 449,
					h: 400,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 101,
					y: 251,
					w: 40,
					h: 35,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 330,
					y: 187,
					w: 28,
					h: 30,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 97,
					y: 118,
					w: 97,
					h: 118,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 188,
					y: 118,
					w: 188,
					h: 118,
					src: '0018.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 188,
					y: 232,
					w: 188,
					h: 232,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 279,
					y: 232,
					w: 279,
					h: 232,
					src: '0034.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_week_imageset10 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 79,
					y: 80,
					week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 156,
					day_startY: 351,
					day_sc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_tc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_en_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_zero: true,
					day_space: -8,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 226,
					month_startY: 351,
					month_sc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					month_tc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					month_en_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					month_zero: true,
					month_space: -8,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_year_imagecombo13 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 293,
					year_startY: 351,
					year_sc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					year_tc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					year_en_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					year_zero: true,
					year_space: -8,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 209,
					y: 350,
					w: 21,
					h: 60,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 275,
					y: 350,
					w: 21,
					h: 60,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 280,
					font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					padding: false,
					h_space: -9,
					invalid_image: '0073.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 288,
					y: 149,
					font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
					padding: false,
					h_space: -8,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateTime() {
					normal_hour_high_imageset5.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset5_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset6.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset6_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset7.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset7_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset8.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset8_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}