﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Digital_Perfection_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 225,
              src: 'DP_Status_Locked.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 225,
              src: 'DP_Status_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 160,
              y: 225,
              src: 'DP_Status_Bluet_Disc.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 225,
              src: 'DP_Status_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 32,
              y: 245,
              w: 161,
              h: 30,
              text_size: 20,
              char_space: 2,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 52,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              negative_image: 'CN_Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 53,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              negative_image: 'CN_Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 79,
              font_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              padding: false,
              h_space: 5,
              negative_image: 'CN_Med_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 77,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 135,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'CN_Small_Black_DDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 163,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'CN_Small_Black_DDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 195,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'CN_Small_Black_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 131,
              day_sc_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              day_tc_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              day_en_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 67,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'CN_Small_Black_Perc.png',
              unit_tc: 'CN_Small_Black_Perc.png',
              unit_en: 'CN_Small_Black_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 104,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 136,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'CN_Small_Black_Perc.png',
              unit_tc: 'CN_Small_Black_Perc.png',
              unit_en: 'CN_Small_Black_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 162,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 206,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 237,
              image_array: ["DP_Step_LVL_1.png","DP_Step_LVL_2.png","DP_Step_LVL_3.png","DP_Step_LVL_4.png","DP_Step_LVL_5.png","DP_Step_LVL_6.png","DP_Step_LVL_7.png","DP_Step_LVL_8.png","DP_Step_LVL_9.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 392,
              font_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'CN_Med_White_Perc.png',
              unit_tc: 'CN_Med_White_Perc.png',
              unit_en: 'CN_Med_White_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 348,
              image_array: ["DP_Bat_LVL_0.png","DP_Bat_LVL_1.png","DP_Bat_LVL_2.png","DP_Bat_LVL_3.png","DP_Bat_LVL_3_copy_1.png","DP_Bat_LVL_4.png","DP_Bat_LVL_5.png","DP_Bat_LVL_6.png","DP_Bat_LVL_7.png","DP_Bat_LVL_8.png","DP_Bat_LVL_9.png","DP_Bat_LVL_10.png","DP_Bat_LVL_11.png","DP_Bat_LVL_12.png","DP_Bat_LVL_13.png","DP_Bat_LVL_14.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 281,
              hour_array: ["CN_Big_Black_0.png","CN_Big_Black_1.png","CN_Big_Black_2.png","CN_Big_Black_3.png","CN_Big_Black_4.png","CN_Big_Black_5.png","CN_Big_Black_6.png","CN_Big_Black_7.png","CN_Big_Black_8.png","CN_Big_Black_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'CN_Big_Black_DDot.png',
              hour_unit_tc: 'CN_Big_Black_DDot.png',
              hour_unit_en: 'CN_Big_Black_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CN_Big_Black_0.png","CN_Big_Black_1.png","CN_Big_Black_2.png","CN_Big_Black_3.png","CN_Big_Black_4.png","CN_Big_Black_5.png","CN_Big_Black_6.png","CN_Big_Black_7.png","CN_Big_Black_8.png","CN_Big_Black_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 331,
              second_startY: 288,
              second_array: ["CN_Med_Black_0.png","CN_Med_Black_1.png","CN_Med_Black_2.png","CN_Med_Black_3.png","CN_Med_Black_4.png","CN_Med_Black_5.png","CN_Med_Black_6.png","CN_Med_Black_7.png","CN_Med_Black_8.png","CN_Med_Black_9.png"],
              second_zero: 0,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Digital_Perfection_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 225,
              src: 'DP_Status_Locked.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 225,
              src: 'DP_Status_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 160,
              y: 225,
              src: 'DP_Status_Bluet_Disc.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 225,
              src: 'DP_Status_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 79,
              font_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              padding: false,
              h_space: 5,
              negative_image: 'CN_Med_White_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 195,
              font_array: ["CN_Small_Black_0.png","CN_Small_Black_1.png","CN_Small_Black_2.png","CN_Small_Black_3.png","CN_Small_Black_4.png","CN_Small_Black_5.png","CN_Small_Black_6.png","CN_Small_Black_7.png","CN_Small_Black_8.png","CN_Small_Black_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'CN_Small_Black_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 131,
              day_sc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_tc_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_en_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 392,
              font_array: ["CN_Med_White_0.png","CN_Med_White_1.png","CN_Med_White_2.png","CN_Med_White_3.png","CN_Med_White_4.png","CN_Med_White_5.png","CN_Med_White_6.png","CN_Med_White_7.png","CN_Med_White_8.png","CN_Med_White_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'CN_Med_White_Perc.png',
              unit_tc: 'CN_Med_White_Perc.png',
              unit_en: 'CN_Med_White_Perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 281,
              hour_array: ["CN_Big_White_0.png","CN_Big_White_1.png","CN_Big_White_2.png","CN_Big_White_3.png","CN_Big_White_4.png","CN_Big_White_5.png","CN_Big_White_6.png","CN_Big_White_7.png","CN_Big_White_8.png","CN_Big_White_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_unit_sc: 'CN_Big_White_DDot.png',
              hour_unit_tc: 'CN_Big_White_DDot.png',
              hour_unit_en: 'CN_Big_White_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CN_Big_White_0.png","CN_Big_White_1.png","CN_Big_White_2.png","CN_Big_White_3.png","CN_Big_White_4.png","CN_Big_White_5.png","CN_Big_White_6.png","CN_Big_White_7.png","CN_Big_White_8.png","CN_Big_White_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  