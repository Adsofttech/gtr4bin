﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_stress_icon_img = ''
        let normal_humidity_text_text_img = ''
/*        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''*/
/*        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''*/
        let normal_altimeter_icon_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_DIRECTION_img_LEVEL = ''
        let normal_humidity_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_calendar_img_click = ''
        let normal_find_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'data_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 290,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                

/*            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 292,
              src: 'icon_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

				
/*            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
				
				
            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_10.png',
              unit_tc: 'data_10.png',
              unit_en: 'data_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				

/*            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 287,
              src: 'icon_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

/*            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 143,
              font_array: ["vosh_0.png","vosh_1.png","vosh_2.png","vosh_3.png","vosh_4.png","vosh_5.png","vosh_6.png","vosh_7.png","vosh_8.png","vosh_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'vosh_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 143,
              font_array: ["vosh_0.png","vosh_1.png","vosh_2.png","vosh_3.png","vosh_4.png","vosh_5.png","vosh_6.png","vosh_7.png","vosh_8.png","vosh_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'vosh_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 289,
              src: 'icon_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'icon_10.png',
              center_x: 195,
              center_y: 310,
              x: 3,
              y: 9,
              start_angle: -140,
              end_angle: 140,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 336,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

				
            normal_wind_DIRECTION_img_LEVEL = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 298,
              image_array: ["wind_1.png", "wind_2.png", "wind_3.png", "wind_4.png", "wind_5.png", "wind_6.png", "wind_7.png", "wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

				

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 289,
              src: 'icon_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 370,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 147,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_11.png',
              unit_tc: 'data_11.png',
              unit_en: 'data_11.png',
              negative_image: 'data_16.png',
              invalid_image: 'data_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 147,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_11.png',
              unit_tc: 'data_11.png',
              unit_en: 'data_11.png',
              negative_image: 'data_16.png',
              invalid_image: 'data_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 147,
              src: 'data_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 118,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_11.png',
              unit_tc: 'data_11.png',
              unit_en: 'data_11.png',
              negative_image: 'data_16.png',
              invalid_image: 'data_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 257,
              image_array: ["weat_1.png","weat_2.png","weat_3.png","weat_4.png","weat_5.png","weat_6.png","weat_7.png","weat_8.png","weat_9.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 72,
              w: 201,
              h: 41,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 411,
              month_startY: 139,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 258,
              y: 12,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 410,
              y: 250,
              image_array: ["puls_pr_1.png","puls_pr_2.png","puls_pr_3.png","puls_pr_4.png","puls_pr_5.png","puls_pr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252,
              y: 350,
              image_array: ["bat_pr_1.png","bat_pr_2.png","bat_pr_3.png","bat_pr_4.png","bat_pr_5.png","bat_pr_6.png","bat_pr_7.png","bat_pr_8.png","bat_pr_9.png","bat_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 11,
              image_array: ["kcal_pr_1.png","kcal_pr_2.png","kcal_pr_3.png","kcal_pr_4.png","kcal_pr_5.png","kcal_pr_6.png","kcal_pr_7.png","kcal_pr_8.png","kcal_pr_9.png","kcal_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 51,
              image_array: ["step_pr_1.png","step_pr_2.png","step_pr_3.png","step_pr_4.png","step_pr_5.png","step_pr_6.png","step_pr_7.png","step_pr_8.png","step_pr_9.png","step_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 179,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 179,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 49,
              src: 'stat_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 108,
              src: 'stat_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




				
				
				
				
				
				
				
//дата начало 1
          // required variables
            const valueImg_mett1 = new Array(2);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett1 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett1[i] = "data_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett1 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett1 = 222;        // радиус
            const Circle_x_mett1 = 466/2;           // Circle center x relative to display
            const Circle_y_mett1 = 466/2;           // Circle center y relative to display
            const Angle = 60;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett1 = 1;         // Угол между символами
            const ImageWidht_mett1 = 16;            // Ширина png
            const ImageHeight_mett1 = 23;           // Высота png
            const UnitsWidht_mett1 = 50;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett1 = -1;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett1 = false;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett1 = 0;               // -1=Left Aligment_mett1; 0=Centr Aligment_mett1; 1=Right Aligment_mett1.
            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett1 = Circle_x_mett1 - Circle_Radius_mett1 - ImageHeight_mett1;        // Widget X position relative to display
            let WI_y_mett1 = Circle_y_mett1 - Circle_Radius_mett1 - ImageHeight_mett1;        // Widget Y position relative to display
            let WI_h_mett1 = Circle_Radius_mett1*2 + ImageHeight_mett1 * 2;             // Widget hight
            let WI_w_mett1 = Circle_Radius_mett1*2 + ImageHeight_mett1 * 2;             // Widget widht
            let WI_center_mett1 = WI_h_mett1/2;
            let startAngle_mett1 = Angle;
            let imagePos_x_mett1 = WI_center_mett1 - ImageWidht_mett1/2;
            let imagePos_y_mett1 = WI_center_mett1 - Circle_Radius_mett1 - (ImageHeight_mett1 + Vertical_Alignment_mett1*ImageHeight_mett1)/2;
            if (ReverseDirection_mett1) imagePos_y_mett1 = WI_center_mett1 + Circle_Radius_mett1 - ImageHeight_mett1 + (ImageHeight_mett1 - Vertical_Alignment_mett1*ImageHeight_mett1)/2;

            let WI_units_x_mett1 = Circle_x_mett1 - Circle_Radius_mett1 - ImageHeight_mett1 - ImageWidht_mett1/2;
            let WI_units_y_mett1 = Circle_y_mett1 - Circle_Radius_mett1 - ImageHeight_mett1 - ImageWidht_mett1/2;
            let WI_units_h_mett1 = Circle_Radius_mett1*2 + ImageHeight_mett1 * 2 + ImageWidht_mett1;
            let WI_units_w_mett1 = Circle_Radius_mett1*2 + ImageHeight_mett1 * 2 + ImageWidht_mett1; 
            let WI_units_center_mett1 = WI_units_h_mett1/2;
            let imagePos_units_x_mett1 = WI_units_center_mett1 - UnitsWidht_mett1/2;
            let imagePos_units_y_mett1 = WI_units_center_mett1 - Circle_Radius_mett1 - (ImageHeight_mett1 + Vertical_Alignment_mett1*ImageHeight_mett1)/2;
            if (ReverseDirection_mett1) imagePos_units_y_mett1 = WI_units_center_mett1 + Circle_Radius_mett1 - ImageHeight_mett1 + (ImageHeight_mett1 - Vertical_Alignment_mett1*ImageHeight_mett1)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett1=(toDegree(Math.atan2(ImageWidht_mett1/2, Circle_Radius_mett1)));
            let unitAngle_mett1=(toDegree(Math.atan2(UnitsWidht_mett1/2, Circle_Radius_mett1)));
                
                

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett1[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett1 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            
            const time_data = hmSensor.createSensor(hmSensor.id.TIME);
            time_data.addEventListener(time_data.event.DAYCHANGE, function() { text_circle() });  // Should update the text on the AOD screen if the data has changed
//дата конец 1
                
                

            function text_circle() {  //  Get the parameter value and display it
                
//дата начало 2

              //console.log('update CALORIE');
              
              let Current_mett1=time_data.day;
              let String_mett1 = String(Current_mett1);
              let index = 0;
              valueImg_mett1[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett1[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett1) && String_mett1.length>0 && String_mett1.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett1)
                {
                  case -1:
                    console.log('Left Aligment_mett1');
                    startAngle_mett1 = Angle;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett1');
                    startAngle_mett1 = Angle - charAngle_mett1*(String_mett1.length-1) - CharSpaceAngle_mett1*(String_mett1.length-1)/2;
                    if (ReverseDirection_mett1) startAngle_mett1 = Angle + charAngle_mett1*(String_mett1.length-1) + CharSpaceAngle_mett1*(String_mett1.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett1');
                    startAngle_mett1 = Angle - 2*charAngle_mett1*(String_mett1.length-1) - CharSpaceAngle_mett1*(String_mett1.length-1);
                    if (ReverseDirection_mett1) startAngle_mett1 = Angle + 2*charAngle_mett1*(String_mett1.length-1) + CharSpaceAngle_mett1*(String_mett1.length-1);
                    break;
                }
                if (ReverseDirection_mett1) startAngle_mett1 = startAngle_mett1 - 180;

                for (let char of String_mett1) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett1 = startAngle_mett1 + 2*charAngle_mett1*index + CharSpaceAngle_mett1*index;
                  if (ReverseDirection_mett1) char_Angle_mett1 = startAngle_mett1 - 2*charAngle_mett1*index - CharSpaceAngle_mett1*index;
                  console.log("char_Angle_mett1: {0}", char_Angle_mett1);

                  if(charCode >= 0 && charCode < 10) valueImg_mett1[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett1,
                    y: WI_y_mett1,
                    w: WI_w_mett1,
                    h: WI_h_mett1,
                    pos_x: imagePos_x_mett1,
                    pos_y: imagePos_y_mett1,
                    center_x: WI_center_mett1,
                    center_y:  WI_center_mett1,
                    angle: char_Angle_mett1,
                    src: ASCIIARRAY_mett1[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett1 + 2*charAngle_mett1*(String_mett1.length-0.5) + unitAngle_mett1 + CharSpaceAngle_mett1*String_mett1.length;
                  if (ReverseDirection_mett1) units_Angle = startAngle_mett1 - 2*charAngle_mett1*(String_mett1.length-0.5) - unitAngle_mett1  - CharSpaceAngle_mett1*String_mett1.length;
                  units_img_mett1.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett1.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett1,
                    y: WI_units_y_mett1,
                    w: WI_units_w_mett1,
                    h: WI_units_h_mett1,
                    pos_x: imagePos_units_x_mett1,
                    pos_y: imagePos_units_y_mett1,
                    center_x: WI_units_center_mett1,
                    center_y:  WI_units_center_mett1,
                    angle: units_Angle,
                    src: "transparent.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett1.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett1 = Angle
                if (ReverseDirection_mett1) startAngle_mett1 = startAngle_mett1 - 180;
                valueImg_mett1[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett1,
                  y: WI_y_mett1,
                  w: WI_w_mett1,
                  h: WI_h_mett1,
                  pos_x: imagePos_x_mett1,
                  pos_y: imagePos_y_mett1,
                  center_x: WI_center_mett1,
                  center_y:  WI_center_mett1,
                  angle: startAngle_mett1,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett1.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
//дата конец 2
                
            };
                
                
                
                
                
          // калории     
          // required variables
            const valueImg_mett2 = new Array(3);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett2 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett2[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett2 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett2 = 187;        // радиус
            const Circle_x_mett2 = 466/2;           // Circle center x relative to display
            const Circle_y_mett2 = 466/2;           // Circle center y relative to display
            const Angle_mett2 = -15;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett2 = 1;         // Угол между символами
            const ImageWidht_mett2 = 13;            // Ширина png
            const ImageHeight_mett2 = 19;           // Высота png
            const UnitsWidht_mett2 = 50;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett2 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett2 = false;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett2 = 1;               // -1=Left Aligment_mett2; 0=Centr Aligment_mett2; 1=Right Aligment_mett2.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett2 = Circle_x_mett2 - Circle_Radius_mett2 - ImageHeight_mett2;        // Widget X position relative to display
            let WI_y_mett2 = Circle_y_mett2 - Circle_Radius_mett2 - ImageHeight_mett2;        // Widget Y position relative to display
            let WI_h_mett2 = Circle_Radius_mett2*2 + ImageHeight_mett2 * 2;             // Widget hight
            let WI_w_mett2 = Circle_Radius_mett2*2 + ImageHeight_mett2 * 2;             // Widget widht
            let WI_center_mett2 = WI_h_mett2/2;
            let startAngle_mett2 = Angle_mett2;
            let imagePos_x_mett2 = WI_center_mett2 - ImageWidht_mett2/2;
            let imagePos_y_mett2 = WI_center_mett2 - Circle_Radius_mett2 - (ImageHeight_mett2 + Vertical_Alignment_mett2*ImageHeight_mett2)/2;
            if (ReverseDirection_mett2) imagePos_y_mett2 = WI_center_mett2 + Circle_Radius_mett2 - ImageHeight_mett2 + (ImageHeight_mett2 - Vertical_Alignment_mett2*ImageHeight_mett2)/2;

            let WI_units_x_mett2 = Circle_x_mett2 - Circle_Radius_mett2 - ImageHeight_mett2 - ImageWidht_mett2/2;
            let WI_units_y_mett2 = Circle_y_mett2 - Circle_Radius_mett2 - ImageHeight_mett2 - ImageWidht_mett2/2;
            let WI_units_h_mett2 = Circle_Radius_mett2*2 + ImageHeight_mett2 * 2 + ImageWidht_mett2;
            let WI_units_w_mett2 = Circle_Radius_mett2*2 + ImageHeight_mett2 * 2 + ImageWidht_mett2; 
            let WI_units_center_mett2 = WI_units_h_mett2/2;
            let imagePos_units_x_mett2 = WI_units_center_mett2 - UnitsWidht_mett2/2;
            let imagePos_units_y_mett2 = WI_units_center_mett2 - Circle_Radius_mett2 - (ImageHeight_mett2 + Vertical_Alignment_mett2*ImageHeight_mett2)/2;
            if (ReverseDirection_mett2) imagePos_units_y_mett2 = WI_units_center_mett2 + Circle_Radius_mett2 - ImageHeight_mett2 + (ImageHeight_mett2 - Vertical_Alignment_mett2*ImageHeight_mett2)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett2 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett2=(toDegree_mett2(Math.atan2(ImageWidht_mett2/2, Circle_Radius_mett2)));
            let unitAngle_mett2=(toDegree_mett2(Math.atan2(UnitsWidht_mett2/2, Circle_Radius_mett2)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett2[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett2 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() { text_circle_mett2() });  // Should update the text on the AOD screen if the data has changed


            function text_circle_mett2() {  //  Get the parameter value and display it

              console.log('update CALORIE');
              
              let Current_mett2=calorie.current;
              let String_mett2 = String(Current_mett2);
              let index = 0;
              valueImg_mett2[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett2[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett2) && String_mett2.length>0 && String_mett2.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett2)
                {
                  case -1:
                    console.log('Left Aligment_mett2');
                    startAngle_mett2 = Angle_mett2;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett2');
                    startAngle_mett2 = Angle_mett2 - charAngle_mett2*(String_mett2.length-1) - CharSpaceAngle_mett2*(String_mett2.length-1)/2;
                    if (ReverseDirection_mett2) startAngle_mett2 = Angle_mett2 + charAngle_mett2*(String_mett2.length-1) + CharSpaceAngle_mett2*(String_mett2.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett2');
                    startAngle_mett2 = Angle_mett2 - 2*charAngle_mett2*(String_mett2.length-1) - CharSpaceAngle_mett2*(String_mett2.length-1);
                    if (ReverseDirection_mett2) startAngle_mett2 = Angle_mett2 + 2*charAngle_mett2*(String_mett2.length-1) + CharSpaceAngle_mett2*(String_mett2.length-1);
                    break;
                }
                if (ReverseDirection_mett2) startAngle_mett2 = startAngle_mett2 - 180;

                for (let char of String_mett2) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett2 = startAngle_mett2 + 2*charAngle_mett2*index + CharSpaceAngle_mett2*index;
                  if (ReverseDirection_mett2) char_Angle_mett2 = startAngle_mett2 - 2*charAngle_mett2*index - CharSpaceAngle_mett2*index;
                  console.log("char_Angle_mett2: {0}", char_Angle_mett2);

                  if(charCode >= 0 && charCode < 10) valueImg_mett2[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett2,
                    y: WI_y_mett2,
                    w: WI_w_mett2,
                    h: WI_h_mett2,
                    pos_x: imagePos_x_mett2,
                    pos_y: imagePos_y_mett2,
                    center_x: WI_center_mett2,
                    center_y:  WI_center_mett2,
                    angle: char_Angle_mett2,
                    src: ASCIIARRAY_mett2[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett2 + 2*charAngle_mett2*(String_mett2.length-0.5) + unitAngle_mett2 + CharSpaceAngle_mett2*String_mett2.length;
                  if (ReverseDirection_mett2) units_Angle = startAngle_mett2 - 2*charAngle_mett2*(String_mett2.length-0.5) - unitAngle_mett2  - CharSpaceAngle_mett2*String_mett2.length;
                  units_img_mett2.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett2.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett2,
                    y: WI_units_y_mett2,
                    w: WI_units_w_mett2,
                    h: WI_units_h_mett2,
                    pos_x: imagePos_units_x_mett2,
                    pos_y: imagePos_units_y_mett2,
                    center_x: WI_units_center_mett2,
                    center_y:  WI_units_center_mett2,
                    angle: units_Angle,
                    src: "transparent.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett2.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett2 = Angle_mett2
                if (ReverseDirection_mett2) startAngle_mett2 = startAngle_mett2 - 180;
                valueImg_mett2[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett2,
                  y: WI_y_mett2,
                  w: WI_w_mett2,
                  h: WI_h_mett2,
                  pos_x: imagePos_x_mett2,
                  pos_y: imagePos_y_mett2,
                  center_x: WI_center_mett2,
                  center_y:  WI_center_mett2,
                  angle: startAngle_mett2,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett2.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
                
                
                
           //пульс     
          // required variables
            const valueImg_mett3 = new Array(3);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett3 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett3[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett3 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett3 = 187;        // радиус
            const Circle_x_mett3 = 466/2;           // Circle center x relative to display
            const Circle_y_mett3 = 466/2;           // Circle center y relative to display
            const Angle_mett3 = 105;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett3 = 1;         // Угол между символами
            const ImageWidht_mett3 = 13;            // Ширина png
            const ImageHeight_mett3 = 19;           // Высота png
            const UnitsWidht_mett3 = 50;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett3 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett3 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett3 = 1;               // -1=Left Aligment_mett3; 0=Centr Aligment_mett3; 1=Right Aligment_mett3.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett3 = Circle_x_mett3 - Circle_Radius_mett3 - ImageHeight_mett3;        // Widget X position relative to display
            let WI_y_mett3 = Circle_y_mett3 - Circle_Radius_mett3 - ImageHeight_mett3;        // Widget Y position relative to display
            let WI_h_mett3 = Circle_Radius_mett3*2 + ImageHeight_mett3 * 2;             // Widget hight
            let WI_w_mett3 = Circle_Radius_mett3*2 + ImageHeight_mett3 * 2;             // Widget widht
            let WI_center_mett3 = WI_h_mett3/2;
            let startAngle_mett3 = Angle_mett3;
            let imagePos_x_mett3 = WI_center_mett3 - ImageWidht_mett3/2;
            let imagePos_y_mett3 = WI_center_mett3 - Circle_Radius_mett3 - (ImageHeight_mett3 + Vertical_Alignment_mett3*ImageHeight_mett3)/2;
            if (ReverseDirection_mett3) imagePos_y_mett3 = WI_center_mett3 + Circle_Radius_mett3 - ImageHeight_mett3 + (ImageHeight_mett3 - Vertical_Alignment_mett3*ImageHeight_mett3)/2;

            let WI_units_x_mett3 = Circle_x_mett3 - Circle_Radius_mett3 - ImageHeight_mett3 - ImageWidht_mett3/2;
            let WI_units_y_mett3 = Circle_y_mett3 - Circle_Radius_mett3 - ImageHeight_mett3 - ImageWidht_mett3/2;
            let WI_units_h_mett3 = Circle_Radius_mett3*2 + ImageHeight_mett3 * 2 + ImageWidht_mett3;
            let WI_units_w_mett3 = Circle_Radius_mett3*2 + ImageHeight_mett3 * 2 + ImageWidht_mett3; 
            let WI_units_center_mett3 = WI_units_h_mett3/2;
            let imagePos_units_x_mett3 = WI_units_center_mett3 - UnitsWidht_mett3/2;
            let imagePos_units_y_mett3 = WI_units_center_mett3 - Circle_Radius_mett3 - (ImageHeight_mett3 + Vertical_Alignment_mett3*ImageHeight_mett3)/2;
            if (ReverseDirection_mett3) imagePos_units_y_mett3 = WI_units_center_mett3 + Circle_Radius_mett3 - ImageHeight_mett3 + (ImageHeight_mett3 - Vertical_Alignment_mett3*ImageHeight_mett3)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett3 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett3=(toDegree_mett3(Math.atan2(ImageWidht_mett3/2, Circle_Radius_mett3)));
            let unitAngle_mett3=(toDegree_mett3(Math.atan2(UnitsWidht_mett3/2, Circle_Radius_mett3)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett3[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett3 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            const heart = hmSensor.createSensor(hmSensor.id.HEART);
            heart.addEventListener(hmSensor.event.CHANGE, function() { text_circle_mett3() });  // Should update the text on the AOD screen if the data has changed


            function text_circle_mett3() {  //  Get the parameter value and display it

              console.log('update HEART');
              
              let Current_mett3=heart.last;
              let String_mett3 = String(Current_mett3);
              let index = 0;
              valueImg_mett3[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett3[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett3) && String_mett3.length>0 && String_mett3.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett3)
                {
                  case -1:
                    console.log('Left Aligment_mett3');
                    startAngle_mett3 = Angle_mett3;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett3');
                    startAngle_mett3 = Angle_mett3 - charAngle_mett3*(String_mett3.length-1) - CharSpaceAngle_mett3*(String_mett3.length-1)/2;
                    if (ReverseDirection_mett3) startAngle_mett3 = Angle_mett3 + charAngle_mett3*(String_mett3.length-1) + CharSpaceAngle_mett3*(String_mett3.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett3');
                    startAngle_mett3 = Angle_mett3 - 2*charAngle_mett3*(String_mett3.length-1) - CharSpaceAngle_mett3*(String_mett3.length-1);
                    if (ReverseDirection_mett3) startAngle_mett3 = Angle_mett3 + 2*charAngle_mett3*(String_mett3.length-1) + CharSpaceAngle_mett3*(String_mett3.length-1);
                    break;
                }
                if (ReverseDirection_mett3) startAngle_mett3 = startAngle_mett3 - 180;

                for (let char of String_mett3) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett3 = startAngle_mett3 + 2*charAngle_mett3*index + CharSpaceAngle_mett3*index;
                  if (ReverseDirection_mett3) char_Angle_mett3 = startAngle_mett3 - 2*charAngle_mett3*index - CharSpaceAngle_mett3*index;
                  console.log("char_Angle_mett3: {0}", char_Angle_mett3);

                  if(charCode >= 0 && charCode < 10) valueImg_mett3[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett3,
                    y: WI_y_mett3,
                    w: WI_w_mett3,
                    h: WI_h_mett3,
                    pos_x: imagePos_x_mett3,
                    pos_y: imagePos_y_mett3,
                    center_x: WI_center_mett3,
                    center_y:  WI_center_mett3,
                    angle: char_Angle_mett3,
                    src: ASCIIARRAY_mett3[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett3 + 2*charAngle_mett3*(String_mett3.length-0.5) + unitAngle_mett3 + CharSpaceAngle_mett3*String_mett3.length;
                  if (ReverseDirection_mett3) units_Angle = startAngle_mett3 - 2*charAngle_mett3*(String_mett3.length-0.5) - unitAngle_mett3  - CharSpaceAngle_mett3*String_mett3.length;
                  units_img_mett3.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett3.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett3,
                    y: WI_units_y_mett3,
                    w: WI_units_w_mett3,
                    h: WI_units_h_mett3,
                    pos_x: imagePos_units_x_mett3,
                    pos_y: imagePos_units_y_mett3,
                    center_x: WI_units_center_mett3,
                    center_y:  WI_units_center_mett3,
                    angle: units_Angle,
                    src: "transparent.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett3.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett3 = Angle_mett3
                if (ReverseDirection_mett3) startAngle_mett3 = startAngle_mett3 - 180;
                valueImg_mett3[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett3,
                  y: WI_y_mett3,
                  w: WI_w_mett3,
                  h: WI_h_mett3,
                  pos_x: imagePos_x_mett3,
                  pos_y: imagePos_y_mett3,
                  center_x: WI_center_mett3,
                  center_y:  WI_center_mett3,
                  angle: startAngle_mett3,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett3.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
            

                
                             
         // заряд      
          // required variables
            const valueImg_mett4 = new Array(3);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett4 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett4[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett4 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett4 = 187;        // радиус
            const Circle_x_mett4 = 466/2;           // Circle center x relative to display
            const Circle_y_mett4 = 466/2;           // Circle center y relative to display
            const Angle_mett4 = 155;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett4 = 1;         // Угол между символами
            const ImageWidht_mett4 = 13;            // Ширина png
            const ImageHeight_mett4 = 19;           // Высота png
            const UnitsWidht_mett4 = 38;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett4 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett4 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett4 = 1;               // -1=Left Aligment_mett4; 0=Centr Aligment_mett4; 1=Right Aligment_mett4.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett4 = Circle_x_mett4 - Circle_Radius_mett4 - ImageHeight_mett4;        // Widget X position relative to display
            let WI_y_mett4 = Circle_y_mett4 - Circle_Radius_mett4 - ImageHeight_mett4;        // Widget Y position relative to display
            let WI_h_mett4 = Circle_Radius_mett4*2 + ImageHeight_mett4 * 2;             // Widget hight
            let WI_w_mett4 = Circle_Radius_mett4*2 + ImageHeight_mett4 * 2;             // Widget widht
            let WI_center_mett4 = WI_h_mett4/2;
            let startAngle_mett4 = Angle_mett4;
            let imagePos_x_mett4 = WI_center_mett4 - ImageWidht_mett4/2;
            let imagePos_y_mett4 = WI_center_mett4 - Circle_Radius_mett4 - (ImageHeight_mett4 + Vertical_Alignment_mett4*ImageHeight_mett4)/2;
            if (ReverseDirection_mett4) imagePos_y_mett4 = WI_center_mett4 + Circle_Radius_mett4 - ImageHeight_mett4 + (ImageHeight_mett4 - Vertical_Alignment_mett4*ImageHeight_mett4)/2;

            let WI_units_x_mett4 = Circle_x_mett4 - Circle_Radius_mett4 - ImageHeight_mett4 - ImageWidht_mett4/2;
            let WI_units_y_mett4 = Circle_y_mett4 - Circle_Radius_mett4 - ImageHeight_mett4 - ImageWidht_mett4/2;
            let WI_units_h_mett4 = Circle_Radius_mett4*2 + ImageHeight_mett4 * 2 + ImageWidht_mett4;
            let WI_units_w_mett4 = Circle_Radius_mett4*2 + ImageHeight_mett4 * 2 + ImageWidht_mett4; 
            let WI_units_center_mett4 = WI_units_h_mett4/2;
            let imagePos_units_x_mett4 = WI_units_center_mett4 - UnitsWidht_mett4/2;
            let imagePos_units_y_mett4 = WI_units_center_mett4 - Circle_Radius_mett4 - (ImageHeight_mett4 + Vertical_Alignment_mett4*ImageHeight_mett4)/2;
            if (ReverseDirection_mett4) imagePos_units_y_mett4 = WI_units_center_mett4 + Circle_Radius_mett4 - ImageHeight_mett4 + (ImageHeight_mett4 - Vertical_Alignment_mett4*ImageHeight_mett4)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett4 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett4=(toDegree_mett4(Math.atan2(ImageWidht_mett4/2, Circle_Radius_mett4)));
            let unitAngle_mett4=(toDegree_mett4(Math.atan2(UnitsWidht_mett4/2, Circle_Radius_mett4)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett4[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett4 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            const BATTERY = hmSensor.createSensor(hmSensor.id.BATTERY);
            BATTERY.addEventListener(hmSensor.event.CHANGE, function() { text_circle_mett4() });  // Should update the text on the AOD screen if the data has changed


            function text_circle_mett4() {  //  Get the parameter value and display it

              console.log('update BATTERY');
              
              let Current_mett4=BATTERY.current;
              let String_mett4 = String(Current_mett4);
              let index = 0;
              valueImg_mett4[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett4[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett4) && String_mett4.length>0 && String_mett4.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett4)
                {
                  case -1:
                    console.log('Left Aligment_mett4');
                    startAngle_mett4 = Angle_mett4;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett4');
                    startAngle_mett4 = Angle_mett4 - charAngle_mett4*(String_mett4.length-1) - CharSpaceAngle_mett4*(String_mett4.length-1)/2;
                    if (ReverseDirection_mett4) startAngle_mett4 = Angle_mett4 + charAngle_mett4*(String_mett4.length-1) + CharSpaceAngle_mett4*(String_mett4.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett4');
                    startAngle_mett4 = Angle_mett4 - 2*charAngle_mett4*(String_mett4.length-1) - CharSpaceAngle_mett4*(String_mett4.length-1);
                    if (ReverseDirection_mett4) startAngle_mett4 = Angle_mett4 + 2*charAngle_mett4*(String_mett4.length-1) + CharSpaceAngle_mett4*(String_mett4.length-1);
                    break;
                }
                if (ReverseDirection_mett4) startAngle_mett4 = startAngle_mett4 - 180;

                for (let char of String_mett4) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett4 = startAngle_mett4 + 2*charAngle_mett4*index + CharSpaceAngle_mett4*index;
                  if (ReverseDirection_mett4) char_Angle_mett4 = startAngle_mett4 - 2*charAngle_mett4*index - CharSpaceAngle_mett4*index;
                  console.log("char_Angle_mett4: {0}", char_Angle_mett4);

                  if(charCode >= 0 && charCode < 10) valueImg_mett4[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett4,
                    y: WI_y_mett4,
                    w: WI_w_mett4,
                    h: WI_h_mett4,
                    pos_x: imagePos_x_mett4,
                    pos_y: imagePos_y_mett4,
                    center_x: WI_center_mett4,
                    center_y:  WI_center_mett4,
                    angle: char_Angle_mett4,
                    src: ASCIIARRAY_mett4[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett4 + 2*charAngle_mett4*(String_mett4.length-0.5) + unitAngle_mett4 + CharSpaceAngle_mett4*String_mett4.length;
                  if (ReverseDirection_mett4) units_Angle = startAngle_mett4 - 2*charAngle_mett4*(String_mett4.length-0.5) - unitAngle_mett4  - CharSpaceAngle_mett4*String_mett4.length;
                  units_img_mett4.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett4.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett4,
                    y: WI_units_y_mett4,
                    w: WI_units_w_mett4,
                    h: WI_units_h_mett4,
                    pos_x: imagePos_units_x_mett4,
                    pos_y: imagePos_units_y_mett4,
                    center_x: WI_units_center_mett4,
                    center_y:  WI_units_center_mett4,
                    angle: units_Angle,
                    src: "dig_12.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett4.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett4 = Angle_mett4
                if (ReverseDirection_mett4) startAngle_mett4 = startAngle_mett4 - 180;
                valueImg_mett4[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett4,
                  y: WI_y_mett4,
                  w: WI_w_mett4,
                  h: WI_h_mett4,
                  pos_x: imagePos_x_mett4,
                  pos_y: imagePos_y_mett4,
                  center_x: WI_center_mett4,
                  center_y:  WI_center_mett4,
                  angle: startAngle_mett4,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett4.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
            

                
           //шаги     
          // required variables
            const valueImg_mett5 = new Array(5);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett5 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett5[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett5 = ''
            // *******************************************************************
            const Circle_Radius_mett5 = 187;        // радиус
            const Circle_x_mett5 = 466/2;           // Circle center x relative to display
            const Circle_y_mett5 = 466/2;           // Circle center y relative to display
            const Angle_mett5 = 310;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett5 = 1;         // Угол между символами
            const ImageWidht_mett5 = 13;            // Ширина png
            const ImageHeight_mett5 = 19;           // Высота png
            const UnitsWidht_mett5 = 50;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett5 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett5 = false;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett5 = 1;               // -1=Left Aligment_mett5; 0=Centr Aligment_mett5; 1=Right Aligment_mett5.
            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett5 = Circle_x_mett5 - Circle_Radius_mett5 - ImageHeight_mett5;        // Widget X position relative to display
            let WI_y_mett5 = Circle_y_mett5 - Circle_Radius_mett5 - ImageHeight_mett5;        // Widget Y position relative to display
            let WI_h_mett5 = Circle_Radius_mett5*2 + ImageHeight_mett5 * 2;             // Widget hight
            let WI_w_mett5 = Circle_Radius_mett5*2 + ImageHeight_mett5 * 2;             // Widget widht
            let WI_center_mett5 = WI_h_mett5/2;
            let startAngle_mett5 = Angle_mett5;
            let imagePos_x_mett5 = WI_center_mett5 - ImageWidht_mett5/2;
            let imagePos_y_mett5 = WI_center_mett5 - Circle_Radius_mett5 - (ImageHeight_mett5 + Vertical_Alignment_mett5*ImageHeight_mett5)/2;
            if (ReverseDirection_mett5) imagePos_y_mett5 = WI_center_mett5 + Circle_Radius_mett5 - ImageHeight_mett5 + (ImageHeight_mett5 - Vertical_Alignment_mett5*ImageHeight_mett5)/2;

            let WI_units_x_mett5 = Circle_x_mett5 - Circle_Radius_mett5 - ImageHeight_mett5 - ImageWidht_mett5/2;
            let WI_units_y_mett5 = Circle_y_mett5 - Circle_Radius_mett5 - ImageHeight_mett5 - ImageWidht_mett5/2;
            let WI_units_h_mett5 = Circle_Radius_mett5*2 + ImageHeight_mett5 * 2 + ImageWidht_mett5;
            let WI_units_w_mett5 = Circle_Radius_mett5*2 + ImageHeight_mett5 * 2 + ImageWidht_mett5; 
            let WI_units_center_mett5 = WI_units_h_mett5/2;
            let imagePos_units_x_mett5 = WI_units_center_mett5 - UnitsWidht_mett5/2;
            let imagePos_units_y_mett5 = WI_units_center_mett5 - Circle_Radius_mett5 - (ImageHeight_mett5 + Vertical_Alignment_mett5*ImageHeight_mett5)/2;
            if (ReverseDirection_mett5) imagePos_units_y_mett5 = WI_units_center_mett5 + Circle_Radius_mett5 - ImageHeight_mett5 + (ImageHeight_mett5 - Vertical_Alignment_mett5*ImageHeight_mett5)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett5 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett5=(toDegree_mett5(Math.atan2(ImageWidht_mett5/2, Circle_Radius_mett5)));
            let unitAngle_mett5=(toDegree_mett5(Math.atan2(UnitsWidht_mett5/2, Circle_Radius_mett5)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett5[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett5 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() { text_circle_mett5() });  // Should update the text on the AOD screen if the data has changed


            function text_circle_mett5() {  //  Get the parameter value and display it

              console.log('update STEP');
              
              let Current_mett5=step.current;
              let String_mett5 = String(Current_mett5);
              let index = 0;
              valueImg_mett5[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett5[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett5) && String_mett5.length>0 && String_mett5.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett5)
                {
                  case -1:
                    console.log('Left Aligment_mett5');
                    startAngle_mett5 = Angle_mett5;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett5');
                    startAngle_mett5 = Angle_mett5 - charAngle_mett5*(String_mett5.length-1) - CharSpaceAngle_mett5*(String_mett5.length-1)/2;
                    if (ReverseDirection_mett5) startAngle_mett5 = Angle_mett5 + charAngle_mett5*(String_mett5.length-1) + CharSpaceAngle_mett5*(String_mett5.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett5');
                    startAngle_mett5 = Angle_mett5 - 2*charAngle_mett5*(String_mett5.length-1) - CharSpaceAngle_mett5*(String_mett5.length-1);
                    if (ReverseDirection_mett5) startAngle_mett5 = Angle_mett5 + 2*charAngle_mett5*(String_mett5.length-1) + CharSpaceAngle_mett5*(String_mett5.length-1);
                    break;
                }
                if (ReverseDirection_mett5) startAngle_mett5 = startAngle_mett5 - 180;

                for (let char of String_mett5) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett5 = startAngle_mett5 + 2*charAngle_mett5*index + CharSpaceAngle_mett5*index;
                  if (ReverseDirection_mett5) char_Angle_mett5 = startAngle_mett5 - 2*charAngle_mett5*index - CharSpaceAngle_mett5*index;
                  console.log("char_Angle_mett5: {0}", char_Angle_mett5);

                  if(charCode >= 0 && charCode < 10) valueImg_mett5[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett5,
                    y: WI_y_mett5,
                    w: WI_w_mett5,
                    h: WI_h_mett5,
                    pos_x: imagePos_x_mett5,
                    pos_y: imagePos_y_mett5,
                    center_x: WI_center_mett5,
                    center_y:  WI_center_mett5,
                    angle: char_Angle_mett5,
                    src: ASCIIARRAY_mett5[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett5 + 2*charAngle_mett5*(String_mett5.length-0.5) + unitAngle_mett5 + CharSpaceAngle_mett5*String_mett5.length;
                  if (ReverseDirection_mett5) units_Angle = startAngle_mett5 - 2*charAngle_mett5*(String_mett5.length-0.5) - unitAngle_mett5  - CharSpaceAngle_mett5*String_mett5.length;
                  units_img_mett5.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett5.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett5,
                    y: WI_units_y_mett5,
                    w: WI_units_w_mett5,
                    h: WI_units_h_mett5,
                    pos_x: imagePos_units_x_mett5,
                    pos_y: imagePos_units_y_mett5,
                    center_x: WI_units_center_mett5,
                    center_y:  WI_units_center_mett5,
                    angle: units_Angle,
                    src: "transparent.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett5.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett5 = Angle_mett5
                if (ReverseDirection_mett5) startAngle_mett5 = startAngle_mett5 - 180;
                valueImg_mett5[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett5,
                  y: WI_y_mett5,
                  w: WI_w_mett5,
                  h: WI_h_mett5,
                  pos_x: imagePos_x_mett5,
                  pos_y: imagePos_y_mett5,
                  center_x: WI_center_mett5,
                  center_y:  WI_center_mett5,
                  angle: startAngle_mett5,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett5.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
				
				

			
                
         //час  восход                  
         // заряд      
          // required variables
            const valueImg_mett7 = new Array(2);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett7 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett7[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett7 = ''
            // *******************************************************************
            const Circle_Radius_mett7 = 187;        // радиус
            const Circle_x_mett7 = 466/2;           // Circle center x relative to display
            const Circle_y_mett7 = 466/2;           // Circle center y relative to display
            const Angle_mett7 = 255;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett7 = 1;         // Угол между символами
            const ImageWidht_mett7 = 13;            // Ширина png
            const ImageHeight_mett7 = 19;           // Высота png
            const UnitsWidht_mett7 = 38;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett7 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett7 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett7 = 1;               // -1=Left Aligment_mett7; 0=Centr Aligment_mett7; 1=Right Aligment_mett7.

            let WI_x_mett7 = Circle_x_mett7 - Circle_Radius_mett7 - ImageHeight_mett7;        // Widget X position relative to display
            let WI_y_mett7 = Circle_y_mett7 - Circle_Radius_mett7 - ImageHeight_mett7;        // Widget Y position relative to display
            let WI_h_mett7 = Circle_Radius_mett7*2 + ImageHeight_mett7 * 2;             // Widget hight
            let WI_w_mett7 = Circle_Radius_mett7*2 + ImageHeight_mett7 * 2;             // Widget widht
            let WI_center_mett7 = WI_h_mett7/2;
            let startAngle_mett7 = Angle_mett7;
            let imagePos_x_mett7 = WI_center_mett7 - ImageWidht_mett7/2;
            let imagePos_y_mett7 = WI_center_mett7 - Circle_Radius_mett7 - (ImageHeight_mett7 + Vertical_Alignment_mett7*ImageHeight_mett7)/2;
            if (ReverseDirection_mett7) imagePos_y_mett7 = WI_center_mett7 + Circle_Radius_mett7 - ImageHeight_mett7 + (ImageHeight_mett7 - Vertical_Alignment_mett7*ImageHeight_mett7)/2;

            let WI_units_x_mett7 = Circle_x_mett7 - Circle_Radius_mett7 - ImageHeight_mett7 - ImageWidht_mett7/2;
            let WI_units_y_mett7 = Circle_y_mett7 - Circle_Radius_mett7 - ImageHeight_mett7 - ImageWidht_mett7/2;
            let WI_units_h_mett7 = Circle_Radius_mett7*2 + ImageHeight_mett7 * 2 + ImageWidht_mett7;
            let WI_units_w_mett7 = Circle_Radius_mett7*2 + ImageHeight_mett7 * 2 + ImageWidht_mett7; 
            let WI_units_center_mett7 = WI_units_h_mett7/2;
            let imagePos_units_x_mett7 = WI_units_center_mett7 - UnitsWidht_mett7/2;
            let imagePos_units_y_mett7 = WI_units_center_mett7 - Circle_Radius_mett7 - (ImageHeight_mett7 + Vertical_Alignment_mett7*ImageHeight_mett7)/2;
            if (ReverseDirection_mett7) imagePos_units_y_mett7 = WI_units_center_mett7 + Circle_Radius_mett7 - ImageHeight_mett7 + (ImageHeight_mett7 - Vertical_Alignment_mett7*ImageHeight_mett7)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett7 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett7=(toDegree_mett7(Math.atan2(ImageWidht_mett7/2, Circle_Radius_mett7)));
            let unitAngle_mett7=(toDegree_mett7(Math.atan2(UnitsWidht_mett7/2, Circle_Radius_mett7)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett7[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett7 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            function text_circle_mett7() {  //  Get the parameter value and display it
                
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
            
            const { forecastData, tideData } = weatherData
            const {
                sunrise: { hour: sunriseHour, minute: sunriseMinute },
            sunset: { hour: sunsetHour, minute: sunsetMinute }
            } = tideData.data[0]

              console.log('update scales WEATHER');
              
              let Current_mett7=sunriseHour;//sunriseHour
              let String_mett7 = String(Current_mett7);
              let index = 0;
              valueImg_mett7[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett7[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett7) && String_mett7.length>0 && String_mett7.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett7)
                {
                  case -1:
                    console.log('Left Aligment_mett7');
                    startAngle_mett7 = Angle_mett7;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett7');
                    startAngle_mett7 = Angle_mett7 - charAngle_mett7*(String_mett7.length-1) - CharSpaceAngle_mett7*(String_mett7.length-1)/2;
                    if (ReverseDirection_mett7) startAngle_mett7 = Angle_mett7 + charAngle_mett7*(String_mett7.length-1) + CharSpaceAngle_mett7*(String_mett7.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett7');
                    startAngle_mett7 = Angle_mett7 - 2*charAngle_mett7*(String_mett7.length-1) - CharSpaceAngle_mett7*(String_mett7.length-1);
                    if (ReverseDirection_mett7) startAngle_mett7 = Angle_mett7 + 2*charAngle_mett7*(String_mett7.length-1) + CharSpaceAngle_mett7*(String_mett7.length-1);
                    break;
                }
                if (ReverseDirection_mett7) startAngle_mett7 = startAngle_mett7 - 180;

                for (let char of String_mett7) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett7 = startAngle_mett7 + 2*charAngle_mett7*index + CharSpaceAngle_mett7*index;
                  if (ReverseDirection_mett7) char_Angle_mett7 = startAngle_mett7 - 2*charAngle_mett7*index - CharSpaceAngle_mett7*index;
                  console.log("char_Angle_mett7: {0}", char_Angle_mett7);

                  if(charCode >= 0 && charCode < 10) valueImg_mett7[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett7,
                    y: WI_y_mett7,
                    w: WI_w_mett7,
                    h: WI_h_mett7,
                    pos_x: imagePos_x_mett7,
                    pos_y: imagePos_y_mett7,
                    center_x: WI_center_mett7,
                    center_y:  WI_center_mett7,
                    angle: char_Angle_mett7,
                    src: ASCIIARRAY_mett7[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett7 + 2*charAngle_mett7*(String_mett7.length-0.5) + unitAngle_mett7 + CharSpaceAngle_mett7*String_mett7.length;
                  if (ReverseDirection_mett7) units_Angle = startAngle_mett7 - 2*charAngle_mett7*(String_mett7.length-0.5) - unitAngle_mett7  - CharSpaceAngle_mett7*String_mett7.length;
                  units_img_mett7.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett7.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett7,
                    y: WI_units_y_mett7,
                    w: WI_units_w_mett7,
                    h: WI_units_h_mett7,
                    pos_x: imagePos_units_x_mett7,
                    pos_y: imagePos_units_y_mett7,
                    center_x: WI_units_center_mett7,
                    center_y:  WI_units_center_mett7,
                    angle: units_Angle,
                    src: "icon_11.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett7.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett7 = Angle_mett7
                if (ReverseDirection_mett7) startAngle_mett7 = startAngle_mett7 - 180;
                valueImg_mett7[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett7,
                  y: WI_y_mett7,
                  w: WI_w_mett7,
                  h: WI_h_mett7,
                  pos_x: imagePos_x_mett7,
                  pos_y: imagePos_y_mett7,
                  center_x: WI_center_mett7,
                  center_y:  WI_center_mett7,
                  angle: startAngle_mett7,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett7.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
                
                
                
                
   

                
         //минуты  восход                  
         // заряд      
          // required variables
            const valueImg_mett6 = new Array(2);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett6 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett6[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett6 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett6 = 187;        // радиус
            const Circle_x_mett6 = 466/2;           // Circle center x relative to display
            const Circle_y_mett6 = 466/2;           // Circle center y relative to display
            const Angle_mett6 = 246;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett6 = 1;         // Угол между символами
            const ImageWidht_mett6 = 13;            // Ширина png
            const ImageHeight_mett6 = 19;           // Высота png
            const UnitsWidht_mett6 = 38;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett6 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett6 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett6 = -1;               // -1=Left Aligment_mett6; 0=Centr Aligment_mett6; 1=Right Aligment_mett6.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett6 = Circle_x_mett6 - Circle_Radius_mett6 - ImageHeight_mett6;        // Widget X position relative to display
            let WI_y_mett6 = Circle_y_mett6 - Circle_Radius_mett6 - ImageHeight_mett6;        // Widget Y position relative to display
            let WI_h_mett6 = Circle_Radius_mett6*2 + ImageHeight_mett6 * 2;             // Widget hight
            let WI_w_mett6 = Circle_Radius_mett6*2 + ImageHeight_mett6 * 2;             // Widget widht
            let WI_center_mett6 = WI_h_mett6/2;
            let startAngle_mett6 = Angle_mett6;
            let imagePos_x_mett6 = WI_center_mett6 - ImageWidht_mett6/2;
            let imagePos_y_mett6 = WI_center_mett6 - Circle_Radius_mett6 - (ImageHeight_mett6 + Vertical_Alignment_mett6*ImageHeight_mett6)/2;
            if (ReverseDirection_mett6) imagePos_y_mett6 = WI_center_mett6 + Circle_Radius_mett6 - ImageHeight_mett6 + (ImageHeight_mett6 - Vertical_Alignment_mett6*ImageHeight_mett6)/2;

            let WI_units_x_mett6 = Circle_x_mett6 - Circle_Radius_mett6 - ImageHeight_mett6 - ImageWidht_mett6/2;
            let WI_units_y_mett6 = Circle_y_mett6 - Circle_Radius_mett6 - ImageHeight_mett6 - ImageWidht_mett6/2;
            let WI_units_h_mett6 = Circle_Radius_mett6*2 + ImageHeight_mett6 * 2 + ImageWidht_mett6;
            let WI_units_w_mett6 = Circle_Radius_mett6*2 + ImageHeight_mett6 * 2 + ImageWidht_mett6; 
            let WI_units_center_mett6 = WI_units_h_mett6/2;
            let imagePos_units_x_mett6 = WI_units_center_mett6 - UnitsWidht_mett6/2;
            let imagePos_units_y_mett6 = WI_units_center_mett6 - Circle_Radius_mett6 - (ImageHeight_mett6 + Vertical_Alignment_mett6*ImageHeight_mett6)/2;
            if (ReverseDirection_mett6) imagePos_units_y_mett6 = WI_units_center_mett6 + Circle_Radius_mett6 - ImageHeight_mett6 + (ImageHeight_mett6 - Vertical_Alignment_mett6*ImageHeight_mett6)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett6 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett6=(toDegree_mett6(Math.atan2(ImageWidht_mett6/2, Circle_Radius_mett6)));
            let unitAngle_mett6=(toDegree_mett6(Math.atan2(UnitsWidht_mett6/2, Circle_Radius_mett6)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett6[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett6 = hmUI.createWidget(hmUI.widget.IMG, { });

            // *******************************************************************

            function text_circle_mett6() {  //  Get the parameter value and display it
                
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
            
            const { forecastData, tideData } = weatherData
            const {
                sunrise: { hour: sunriseHour, minute: sunriseMinute },
            sunset: { hour: sunsetHour, minute: sunsetMinute }
            } = tideData.data[0]

              console.log('update scales WEATHER');
              
              let Current_mett6=sunriseMinute;//sunriseMinute
              let String_mett6 = String(Current_mett6);
              let index = 0;
              valueImg_mett6[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett6[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett6) && String_mett6.length>0 && String_mett6.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett6)
                {
                  case -1:
                    console.log('Left Aligment_mett6');
                    startAngle_mett6 = Angle_mett6;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett6');
                    startAngle_mett6 = Angle_mett6 - charAngle_mett6*(String_mett6.length-1) - CharSpaceAngle_mett6*(String_mett6.length-1)/2;
                    if (ReverseDirection_mett6) startAngle_mett6 = Angle_mett6 + charAngle_mett6*(String_mett6.length-1) + CharSpaceAngle_mett6*(String_mett6.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett6');
                    startAngle_mett6 = Angle_mett6 - 2*charAngle_mett6*(String_mett6.length-1) - CharSpaceAngle_mett6*(String_mett6.length-1);
                    if (ReverseDirection_mett6) startAngle_mett6 = Angle_mett6 + 2*charAngle_mett6*(String_mett6.length-1) + CharSpaceAngle_mett6*(String_mett6.length-1);
                    break;
                }
                if (ReverseDirection_mett6) startAngle_mett6 = startAngle_mett6 - 180;

                for (let char of String_mett6) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett6 = startAngle_mett6 + 2*charAngle_mett6*index + CharSpaceAngle_mett6*index;
                  if (ReverseDirection_mett6) char_Angle_mett6 = startAngle_mett6 - 2*charAngle_mett6*index - CharSpaceAngle_mett6*index;
                  console.log("char_Angle_mett6: {0}", char_Angle_mett6);

                  if(charCode >= 0 && charCode < 10) valueImg_mett6[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett6,
                    y: WI_y_mett6,
                    w: WI_w_mett6,
                    h: WI_h_mett6,
                    pos_x: imagePos_x_mett6,
                    pos_y: imagePos_y_mett6,
                    center_x: WI_center_mett6,
                    center_y:  WI_center_mett6,
                    angle: char_Angle_mett6,
                    src: ASCIIARRAY_mett6[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett6 + 2*charAngle_mett6*(String_mett6.length-0.5) + unitAngle_mett6 + CharSpaceAngle_mett6*String_mett6.length;
                  if (ReverseDirection_mett6) units_Angle = startAngle_mett6 - 2*charAngle_mett6*(String_mett6.length-0.5) - unitAngle_mett6  - CharSpaceAngle_mett6*String_mett6.length;
                  units_img_mett6.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett6.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett6,
                    y: WI_units_y_mett6,
                    w: WI_units_w_mett6,
                    h: WI_units_h_mett6,
                    pos_x: imagePos_units_x_mett6,
                    pos_y: imagePos_units_y_mett6,
                    center_x: WI_units_center_mett6,
                    center_y:  WI_units_center_mett6,
                    angle: units_Angle,
                    src: "icon_12.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett6.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett6 = Angle_mett6
                if (ReverseDirection_mett6) startAngle_mett6 = startAngle_mett6 - 180;
                valueImg_mett6[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett6,
                  y: WI_y_mett6,
                  w: WI_w_mett6,
                  h: WI_h_mett6,
                  pos_x: imagePos_x_mett6,
                  pos_y: imagePos_y_mett6,
                  center_x: WI_center_mett6,
                  center_y:  WI_center_mett6,
                  angle: startAngle_mett6,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett6.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
                
                
         //час закат                 
         // заряд      
          // required variables
            const valueImg_mett8 = new Array(2);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett8 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett8[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett8 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett8 = 187;        // радиус
            const Circle_x_mett8 = 466/2;           // Circle center x relative to display
            const Circle_y_mett8 = 466/2;           // Circle center y relative to display
            const Angle_mett8 = 218;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett8 = 1;         // Угол между символами
            const ImageWidht_mett8 = 13;            // Ширина png
            const ImageHeight_mett8 = 19;           // Высота png
            const UnitsWidht_mett8 = 38;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett8 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett8 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett8 = 1;               // -1=Left Aligment_mett8; 0=Centr Aligment_mett8; 1=Right Aligment_mett8.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett8 = Circle_x_mett8 - Circle_Radius_mett8 - ImageHeight_mett8;        // Widget X position relative to display
            let WI_y_mett8 = Circle_y_mett8 - Circle_Radius_mett8 - ImageHeight_mett8;        // Widget Y position relative to display
            let WI_h_mett8 = Circle_Radius_mett8*2 + ImageHeight_mett8 * 2;             // Widget hight
            let WI_w_mett8 = Circle_Radius_mett8*2 + ImageHeight_mett8 * 2;             // Widget widht
            let WI_center_mett8 = WI_h_mett8/2;
            let startAngle_mett8 = Angle_mett8;
            let imagePos_x_mett8 = WI_center_mett8 - ImageWidht_mett8/2;
            let imagePos_y_mett8 = WI_center_mett8 - Circle_Radius_mett8 - (ImageHeight_mett8 + Vertical_Alignment_mett8*ImageHeight_mett8)/2;
            if (ReverseDirection_mett8) imagePos_y_mett8 = WI_center_mett8 + Circle_Radius_mett8 - ImageHeight_mett8 + (ImageHeight_mett8 - Vertical_Alignment_mett8*ImageHeight_mett8)/2;

            let WI_units_x_mett8 = Circle_x_mett8 - Circle_Radius_mett8 - ImageHeight_mett8 - ImageWidht_mett8/2;
            let WI_units_y_mett8 = Circle_y_mett8 - Circle_Radius_mett8 - ImageHeight_mett8 - ImageWidht_mett8/2;
            let WI_units_h_mett8 = Circle_Radius_mett8*2 + ImageHeight_mett8 * 2 + ImageWidht_mett8;
            let WI_units_w_mett8 = Circle_Radius_mett8*2 + ImageHeight_mett8 * 2 + ImageWidht_mett8; 
            let WI_units_center_mett8 = WI_units_h_mett8/2;
            let imagePos_units_x_mett8 = WI_units_center_mett8 - UnitsWidht_mett8/2;
            let imagePos_units_y_mett8 = WI_units_center_mett8 - Circle_Radius_mett8 - (ImageHeight_mett8 + Vertical_Alignment_mett8*ImageHeight_mett8)/2;
            if (ReverseDirection_mett8) imagePos_units_y_mett8 = WI_units_center_mett8 + Circle_Radius_mett8 - ImageHeight_mett8 + (ImageHeight_mett8 - Vertical_Alignment_mett8*ImageHeight_mett8)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett8 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett8=(toDegree_mett8(Math.atan2(ImageWidht_mett8/2, Circle_Radius_mett8)));
            let unitAngle_mett8=(toDegree_mett8(Math.atan2(UnitsWidht_mett8/2, Circle_Radius_mett8)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett8[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett8 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            function text_circle_mett8() {  //  Get the parameter value and display it
                
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
            
            const { forecastData, tideData } = weatherData
            const {
                sunrise: { hour: sunriseHour, minute: sunriseMinute },
            sunset: { hour: sunsetHour, minute: sunsetMinute }
            } = tideData.data[0]

              console.log('update scales WEATHER');
              
              let Current_mett8=sunsetHour;
              let String_mett8 = String(Current_mett8);
              let index = 0;
              valueImg_mett8[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett8[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett8) && String_mett8.length>0 && String_mett8.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett8)
                {
                  case -1:
                    console.log('Left Aligment_mett8');
                    startAngle_mett8 = Angle_mett8;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett8');
                    startAngle_mett8 = Angle_mett8 - charAngle_mett8*(String_mett8.length-1) - CharSpaceAngle_mett8*(String_mett8.length-1)/2;
                    if (ReverseDirection_mett8) startAngle_mett8 = Angle_mett8 + charAngle_mett8*(String_mett8.length-1) + CharSpaceAngle_mett8*(String_mett8.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett8');
                    startAngle_mett8 = Angle_mett8 - 2*charAngle_mett8*(String_mett8.length-1) - CharSpaceAngle_mett8*(String_mett8.length-1);
                    if (ReverseDirection_mett8) startAngle_mett8 = Angle_mett8 + 2*charAngle_mett8*(String_mett8.length-1) + CharSpaceAngle_mett8*(String_mett8.length-1);
                    break;
                }
                if (ReverseDirection_mett8) startAngle_mett8 = startAngle_mett8 - 180;

                for (let char of String_mett8) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett8 = startAngle_mett8 + 2*charAngle_mett8*index + CharSpaceAngle_mett8*index;
                  if (ReverseDirection_mett8) char_Angle_mett8 = startAngle_mett8 - 2*charAngle_mett8*index - CharSpaceAngle_mett8*index;
                  console.log("char_Angle_mett8: {0}", char_Angle_mett8);

                  if(charCode >= 0 && charCode < 10) valueImg_mett8[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett8,
                    y: WI_y_mett8,
                    w: WI_w_mett8,
                    h: WI_h_mett8,
                    pos_x: imagePos_x_mett8,
                    pos_y: imagePos_y_mett8,
                    center_x: WI_center_mett8,
                    center_y:  WI_center_mett8,
                    angle: char_Angle_mett8,
                    src: ASCIIARRAY_mett8[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett8 + 2*charAngle_mett8*(String_mett8.length-0.5) + unitAngle_mett8 + CharSpaceAngle_mett8*String_mett8.length;
                  if (ReverseDirection_mett8) units_Angle = startAngle_mett8 - 2*charAngle_mett8*(String_mett8.length-0.5) - unitAngle_mett8  - CharSpaceAngle_mett8*String_mett8.length;
                  units_img_mett8.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett8.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett8,
                    y: WI_units_y_mett8,
                    w: WI_units_w_mett8,
                    h: WI_units_h_mett8,
                    pos_x: imagePos_units_x_mett8,
                    pos_y: imagePos_units_y_mett8,
                    center_x: WI_units_center_mett8,
                    center_y:  WI_units_center_mett8,
                    angle: units_Angle,
                    src: "icon_11.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett8.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett8 = Angle_mett8
                if (ReverseDirection_mett8) startAngle_mett8 = startAngle_mett8 - 180;
                valueImg_mett8[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett8,
                  y: WI_y_mett8,
                  w: WI_w_mett8,
                  h: WI_h_mett8,
                  pos_x: imagePos_x_mett8,
                  pos_y: imagePos_y_mett8,
                  center_x: WI_center_mett8,
                  center_y:  WI_center_mett8,
                  angle: startAngle_mett8,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett8.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
            

                
         //мин  закат              
         // заряд      
          // required variables
            const valueImg_mett9 = new Array(2);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY_mett9 = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY_mett9[i] = "dig_" + i + ".png";  // set of images with numbers
            }
            let units_img_mett9 = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius_mett9 = 187;        // радиус
            const Circle_x_mett9 = 466/2;           // Circle center x relative to display
            const Circle_y_mett9 = 466/2;           // Circle center y relative to display
            const Angle_mett9 = 210;                // Начальный угол, 0 degrees corresponds to the direction at 12 o'clock
            const CharSpaceAngle_mett9 = 1;         // Угол между символами
            const ImageWidht_mett9 = 13;            // Ширина png
            const ImageHeight_mett9 = 19;           // Высота png
            const UnitsWidht_mett9 = 38;            // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
               // Ширина изображения единиц. Высота единиц измерения должна быть такой же, как и высота изображений с числами.
            const Vertical_Alignment_mett9 = 0;     // Character vertical alignment relative to the circle: -1 = top, 0 = center, 1 = bottom
               // Вертикальное выравнивание персонажа относительно круга:
            const ReverseDirection_mett9 = true;    // Affects the direction of the text. It is advisable to use true if the text is located at the bottom of the circle
                //Влияет на направление текста. Желательно использовать True, если текст расположен в нижней части круга
            const Aligment_mett9 = -1;               // -1=Left Aligment_mett9; 0=Centr Aligment_mett9; 1=Right Aligment_mett9.

            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x_mett9 = Circle_x_mett9 - Circle_Radius_mett9 - ImageHeight_mett9;        // Widget X position relative to display
            let WI_y_mett9 = Circle_y_mett9 - Circle_Radius_mett9 - ImageHeight_mett9;        // Widget Y position relative to display
            let WI_h_mett9 = Circle_Radius_mett9*2 + ImageHeight_mett9 * 2;             // Widget hight
            let WI_w_mett9 = Circle_Radius_mett9*2 + ImageHeight_mett9 * 2;             // Widget widht
            let WI_center_mett9 = WI_h_mett9/2;
            let startAngle_mett9 = Angle_mett9;
            let imagePos_x_mett9 = WI_center_mett9 - ImageWidht_mett9/2;
            let imagePos_y_mett9 = WI_center_mett9 - Circle_Radius_mett9 - (ImageHeight_mett9 + Vertical_Alignment_mett9*ImageHeight_mett9)/2;
            if (ReverseDirection_mett9) imagePos_y_mett9 = WI_center_mett9 + Circle_Radius_mett9 - ImageHeight_mett9 + (ImageHeight_mett9 - Vertical_Alignment_mett9*ImageHeight_mett9)/2;

            let WI_units_x_mett9 = Circle_x_mett9 - Circle_Radius_mett9 - ImageHeight_mett9 - ImageWidht_mett9/2;
            let WI_units_y_mett9 = Circle_y_mett9 - Circle_Radius_mett9 - ImageHeight_mett9 - ImageWidht_mett9/2;
            let WI_units_h_mett9 = Circle_Radius_mett9*2 + ImageHeight_mett9 * 2 + ImageWidht_mett9;
            let WI_units_w_mett9 = Circle_Radius_mett9*2 + ImageHeight_mett9 * 2 + ImageWidht_mett9; 
            let WI_units_center_mett9 = WI_units_h_mett9/2;
            let imagePos_units_x_mett9 = WI_units_center_mett9 - UnitsWidht_mett9/2;
            let imagePos_units_y_mett9 = WI_units_center_mett9 - Circle_Radius_mett9 - (ImageHeight_mett9 + Vertical_Alignment_mett9*ImageHeight_mett9)/2;
            if (ReverseDirection_mett9) imagePos_units_y_mett9 = WI_units_center_mett9 + Circle_Radius_mett9 - ImageHeight_mett9 + (ImageHeight_mett9 - Vertical_Alignment_mett9*ImageHeight_mett9)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree_mett9 (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle_mett9=(toDegree_mett9(Math.atan2(ImageWidht_mett9/2, Circle_Radius_mett9)));
            let unitAngle_mett9=(toDegree_mett9(Math.atan2(UnitsWidht_mett9/2, Circle_Radius_mett9)));

            for ( let i = 0; i < 5; i++ ){
              valueImg_mett9[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img_mett9 = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************

            function text_circle_mett9() {  //  Get the parameter value and display it
                
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
            
            const { forecastData, tideData } = weatherData
            const {
                sunrise: { hour: sunriseHour, minute: sunriseMinute },
            sunset: { hour: sunsetHour, minute: sunsetMinute }
            } = tideData.data[0]

              console.log('update scales WEATHER');
              
              let Current_mett9=sunsetMinute;
              let String_mett9 = String(Current_mett9);
              let index = 0;
              valueImg_mett9[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg_mett9[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(Current_mett9) && String_mett9.length>0 && String_mett9.length<6) {  // display data if it was possible to get it
                switch(Aligment_mett9)
                {
                  case -1:
                    console.log('Left Aligment_mett9');
                    startAngle_mett9 = Angle_mett9;
                    break;
                  case 0:
                    console.log('Centr Aligment_mett9');
                    startAngle_mett9 = Angle_mett9 - charAngle_mett9*(String_mett9.length-1) - CharSpaceAngle_mett9*(String_mett9.length-1)/2;
                    if (ReverseDirection_mett9) startAngle_mett9 = Angle_mett9 + charAngle_mett9*(String_mett9.length-1) + CharSpaceAngle_mett9*(String_mett9.length-1)/2;
                    break;
                  case 1:
                    console.log('Right Aligment_mett9');
                    startAngle_mett9 = Angle_mett9 - 2*charAngle_mett9*(String_mett9.length-1) - CharSpaceAngle_mett9*(String_mett9.length-1);
                    if (ReverseDirection_mett9) startAngle_mett9 = Angle_mett9 + 2*charAngle_mett9*(String_mett9.length-1) + CharSpaceAngle_mett9*(String_mett9.length-1);
                    break;
                }
                if (ReverseDirection_mett9) startAngle_mett9 = startAngle_mett9 - 180;

                for (let char of String_mett9) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle_mett9 = startAngle_mett9 + 2*charAngle_mett9*index + CharSpaceAngle_mett9*index;
                  if (ReverseDirection_mett9) char_Angle_mett9 = startAngle_mett9 - 2*charAngle_mett9*index - CharSpaceAngle_mett9*index;
                  console.log("char_Angle_mett9: {0}", char_Angle_mett9);

                  if(charCode >= 0 && charCode < 10) valueImg_mett9[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x_mett9,
                    y: WI_y_mett9,
                    w: WI_w_mett9,
                    h: WI_h_mett9,
                    pos_x: imagePos_x_mett9,
                    pos_y: imagePos_y_mett9,
                    center_x: WI_center_mett9,
                    center_y:  WI_center_mett9,
                    angle: char_Angle_mett9,
                    src: ASCIIARRAY_mett9[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle_mett9 + 2*charAngle_mett9*(String_mett9.length-0.5) + unitAngle_mett9 + CharSpaceAngle_mett9*String_mett9.length;
                  if (ReverseDirection_mett9) units_Angle = startAngle_mett9 - 2*charAngle_mett9*(String_mett9.length-0.5) - unitAngle_mett9  - CharSpaceAngle_mett9*String_mett9.length;
                  units_img_mett9.setProperty(hmUI.prop.VISIBLE, true);
                  units_img_mett9.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x_mett9,
                    y: WI_units_y_mett9,
                    w: WI_units_w_mett9,
                    h: WI_units_h_mett9,
                    pos_x: imagePos_units_x_mett9,
                    pos_y: imagePos_units_y_mett9,
                    center_x: WI_units_center_mett9,
                    center_y:  WI_units_center_mett9,
                    angle: units_Angle,
                    src: "icon_12.png",  // Еденицы измерения
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img_mett9.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle_mett9 = Angle_mett9
                if (ReverseDirection_mett9) startAngle_mett9 = startAngle_mett9 - 180;
                valueImg_mett9[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x_mett9,
                  y: WI_y_mett9,
                  w: WI_w_mett9,
                  h: WI_h_mett9,
                  pos_x: imagePos_x_mett9,
                  pos_y: imagePos_y_mett9,
                  center_x: WI_center_mett9,
                  center_y:  WI_center_mett9,
                  angle: startAngle_mett9,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img_mett9.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
				
				
				
				
				

                
            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

                
            

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_circle();  // update text when screen turns on
                text_circle_mett2();  // update text when screen turns on
                text_circle_mett3();  // update text when screen turns on
                text_circle_mett4();  // update text when screen turns on
                text_circle_mett5();  // update text when screen turns on
                text_circle_mett6();  // update text when screen turns on
                text_circle_mett7();  // update text when screen turns on
                text_circle_mett8();  // update text when screen turns on
                text_circle_mett9();  // update text when screen turns on
              }),
            });
				
				
				
            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 92+30,
              w: 29,
              h: 36,
              src: 'icon_3.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 116,
              w: 60,
              h: 60,
              src: 'icon_6.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

				
            normal_calendar_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 94+30,
              w: 30,
              h: 33,
              src: 'icon_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calendar_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'ScheduleCalScreen',
                native: true
              })
            });

								
            normal_find_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 38,
              w: 36,
              h: 36,
              src: 'icon_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_find_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'FindPhoneScreen',
                native: true
              })
            });

                         

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
