﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start
    let normal_digital_clock_img_minute_units = "";
    let normal_digital_clock_img_minute_tens = "";
    let normal_digital_clock_img_hour_units = "";
    let normal_digital_clock_img_hour_tens = "";
    let minute_units = "";
    let minute_tens = "";
    let hour_units = "";
    let hour_tens = "";
    let normal_background_bg_img = "";
    let normal_date_img_date_week_img = "";
    let normal_date_img_date_day = "";
    let normal_calorie_circle_scale = "";
    let normal_battery_circle_scale = "";
    let normal_temperature_current_text_img = "";
    let normal_weather_image_progress_img_level = "";
    let normal_heart_rate_TextRotate = new Array(3);
    let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
    let normal_heart_rate_TextRotate_img_width = 13;
    let normal_heart_rate_TextRotate_unit = null;
    let normal_heart_rate_TextRotate_unit_width = 40;
    let normal_heart_rate_TextRotate_error_img_width = 23;
    let normal_step_TextRotate = new Array(5);
    let normal_step_TextRotate_ASCIIARRAY = new Array(10);
    let normal_step_TextRotate_img_width = 13;
    let normal_step_TextRotate_unit = null;
    let normal_step_TextRotate_unit_width = 45;
    let normal_step_TextRotate_error_img_width = 23;
    let idle_background_bg_img = "";
    let idle_date_img_date_week_img = "";
    let idle_date_img_date_day = "";
    let idle_temperature_current_text_img = "";
    let idle_weather_image_progress_img_level = "";
    let idle_digital_clock_img_time_minute = "";
    let idle_digital_clock_img_time_hour = "";

    let start_htX = 100;
    let start_htY = 113;
    let start_huX = 192;
    let start_huY = 176;
    let start_mtX = 170;
    let start_mtY = 4;
    let start_muX = 270;
    let start_muY = 48;
    let htX = 100;
    let htY = 113;
    let huX = 192;
    let huY = 176;
    let mtX = 170;
    let mtY = 4;
    let muX = 270;
    let muY = 48;

    let interval = 20;
    let ht_up = true;
    let hu_up = true;
    let mt_up = true;
    let mu_up = true;
    let tm;
    let speed_ht = 1;
    let speed_hu = 0.5;
    let speed_mt = 0.4;
    let speed_mu = 0.8;

    function PointUpdate() {
      //десятки часов
      if (htX >= start_htX + interval) ht_up = false;
      if (htX <= start_htX) ht_up = true;
      if (ht_up) {
        htX = htX + speed_ht;
        htY = htY + speed_ht;
      } else {
        htX = htX - speed_ht;
        htY = htY - speed_ht;
      }
      normal_digital_clock_img_hour_tens.setProperty(hmUI.prop.X, htX);
      normal_digital_clock_img_hour_tens.setProperty(hmUI.prop.Y, htY);
      //еденицы часов
      if (huX >= start_huX + interval) hu_up = false;
      if (huX <= start_huX) hu_up = true;
      if (hu_up) {
        huX = huX + speed_hu;
        huY = huY + speed_hu;
      } else {
        huX = huX - speed_hu;
        huY = huY - speed_hu;
      }
      normal_digital_clock_img_hour_units.setProperty(hmUI.prop.X, huX);
      normal_digital_clock_img_hour_units.setProperty(hmUI.prop.Y, huY);
      //десятки минут
      if (mtX >= start_mtX + interval) mt_up = false;
      if (mtX <= start_mtX) mt_up = true;
      if (mt_up) {
        mtX = mtX + speed_mt;
        mtY = mtY + speed_mt;
      } else {
        mtX = mtX - speed_mt;
        mtY = mtY - speed_mt;
      }
      normal_digital_clock_img_minute_tens.setProperty(hmUI.prop.X, mtX);
      normal_digital_clock_img_minute_tens.setProperty(hmUI.prop.Y, mtY);
      //еденицы минут
      if (muX >= start_muX + interval) mu_up = false;
      if (muX <= start_muX) mu_up = true;
      if (mu_up) {
        muX = muX + speed_mu;
        muY = muY + speed_mu;
      } else {
        muX = muX - speed_mu;
        muY = muY - speed_mu;
      }
      normal_digital_clock_img_minute_units.setProperty(hmUI.prop.X, muX);
      normal_digital_clock_img_minute_units.setProperty(hmUI.prop.Y, muY);
    }

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        let wfScreen =
          hmSetting.getScreenType() == hmSetting.screen_type.WATCHFACE;
        let aodScreen = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
        let editScreen =
          hmSetting.getScreenType() == hmSetting.screen_type.SETTINGS;
        const time = hmSensor.createSensor(hmSensor.id.TIME);

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        let screenType = hmSetting.getScreenType();
        normal_calorie_circle_scale = hmUI.createWidget(
          hmUI.widget.ARC_PROGRESS,
          {
            center_x: 233,
            center_y: 233,
            start_angle: -119,
            end_angle: -168,
            radius: 214,
            line_width: 13,
            corner_flag: 0,
            color: 0xff018fc4,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        calorie.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_battery_circle_scale = hmUI.createWidget(
          hmUI.widget.ARC_PROGRESS,
          {
            center_x: 233,
            center_y: 233,
            start_angle: -61,
            end_angle: -12,
            radius: 214,
            line_width: 13,
            corner_flag: 0,
            color: 0xffffb100,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_heart_rate_TextRotate_ASCIIARRAY[0] = "n_gray_0.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[1] = "n_gray_1.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[2] = "n_gray_2.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[3] = "n_gray_3.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[4] = "n_gray_4.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[5] = "n_gray_5.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[6] = "n_gray_6.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[7] = "n_gray_7.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[8] = "n_gray_8.png"; // set of images with numbers
        normal_heart_rate_TextRotate_ASCIIARRAY[9] = "n_gray_9.png"; // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 3; i++) {
          normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 90,
            center_y: 301,
            pos_x: 90,
            pos_y: 301,
            angle: 270,
            src: "n_gray_0.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
        }

        normal_heart_rate_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          center_x: 90,
          center_y: 301,
          pos_x: 90,
          pos_y: 301,
          angle: 270,
          src: "bpm.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
        //end of ignored block

        const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
        heart_rate.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
        });

        normal_step_TextRotate_ASCIIARRAY[0] = "n_gray_0.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[1] = "n_gray_1.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[2] = "n_gray_2.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[3] = "n_gray_3.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[4] = "n_gray_4.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[5] = "n_gray_5.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[6] = "n_gray_6.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[7] = "n_gray_7.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[8] = "n_gray_8.png"; // set of images with numbers
        normal_step_TextRotate_ASCIIARRAY[9] = "n_gray_9.png"; // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 5; i++) {
          normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 90,
            center_y: 199,
            pos_x: 90,
            pos_y: 199,
            angle: 270,
            src: "n_gray_0.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
        }

        normal_step_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          center_x: 90,
          center_y: 199,
          pos_x: 90,
          pos_y: 199,
          angle: 270,
          src: "step.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
        //end of ignored block

        const step = hmSensor.createSensor(hmSensor.id.STEP);
        step.addEventListener(hmSensor.event.CHANGE, function () {
          text_update();
        });

        normal_date_img_date_week_img = hmUI.createWidget(
          hmUI.widget.IMG_WEEK,
          {
            x: 84,
            y: 220,
            week_en: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            week_tc: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            week_sc: [
              "week_0.png",
              "week_1.png",
              "week_2.png",
              "week_3.png",
              "week_4.png",
              "week_5.png",
              "week_6.png",
            ],
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          }
        );

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 10,
          day_startY: 208,
          day_sc_array: [
            "0.png",
            "1.png",
            "2.png",
            "3.png",
            "4.png",
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
          ],
          day_tc_array: [
            "0.png",
            "1.png",
            "2.png",
            "3.png",
            "4.png",
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
          ],
          day_en_array: [
            "0.png",
            "1.png",
            "2.png",
            "3.png",
            "4.png",
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
          ],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        normal_temperature_current_text_img = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          {
            x: 9,
            y: 261,
            font_array: [
              "n_0.png",
              "n_1.png",
              "n_2.png",
              "n_3.png",
              "n_4.png",
              "n_5.png",
              "n_6.png",
              "n_7.png",
              "n_8.png",
              "n_9.png",
            ],
            padding: false,
            h_space: 0,
            unit_sc: "n_10.png",
            unit_tc: "n_10.png",
            unit_en: "n_10.png",
            negative_image: "n_12.png",
            invalid_image: "n_11.png",
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_weather_image_progress_img_level = hmUI.createWidget(
          hmUI.widget.IMG_LEVEL,
          {
            x: 24,
            y: 166,
            image_array: [
              "we1.png",
              "we10.png",
              "we11.png",
              "we12.png",
              "we13.png",
              "we14.png",
              "we15.png",
              "we15n.png",
              "we16.png",
              "we17.png",
              "we18.png",
              "we19.png",
              "we1n.png",
              "we2.png",
              "we20.png",
              "we21.png",
              "we22.png",
              "we23.png",
              "we24.png",
              "we25.png",
              "we26.png",
              "we2n.png",
              "we3.png",
              "we3n.png",
              "we4.png",
              "we4n.png",
              "we5.png",
              "we6.png",
              "we7.png",
            ],
            image_length: 29,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }
        );

        normal_digital_clock_img_minute_tens = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          {
            x: start_mtX,
            y: start_mtY,
            font_array: [
              "m_0.png",
              "m_1.png",
              "m_2.png",
              "m_3.png",
              "m_4.png",
              "m_5.png",
              "m_6.png",
              "m_7.png",
              "m_8.png",
              "m_9.png",
            ],
            text: minute_tens,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          }
        );

        normal_digital_clock_img_minute_units = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          {
            x: start_muX,
            y: start_muY,
            font_array: [
              "m_0.png",
              "m_1.png",
              "m_2.png",
              "m_3.png",
              "m_4.png",
              "m_5.png",
              "m_6.png",
              "m_7.png",
              "m_8.png",
              "m_9.png",
            ],
            text: minute_units,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          }
        );

        normal_digital_clock_img_hour_tens = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          {
            x: start_htX,
            y: start_htY,
            font_array: [
              "h_0.png",
              "h_1.png",
              "h_2.png",
              "h_3.png",
              "h_4.png",
              "h_5.png",
              "h_6.png",
              "h_7.png",
              "h_8.png",
              "h_9.png",
            ],
            text: hour_tens,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          }
        );

        normal_digital_clock_img_hour_units = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          {
            x: start_huX,
            y: start_huY,
            font_array: [
              "h_0.png",
              "h_1.png",
              "h_2.png",
              "h_3.png",
              "h_4.png",
              "h_5.png",
              "h_6.png",
              "h_7.png",
              "h_8.png",
              "h_9.png",
            ],
            text: hour_units,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          }
        );



/*
        idle_digital_clock_img_time_minute = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            minute_startX: 144,
            minute_startY: 10,
            minute_array: [
              "m_0.png",
              "m_1.png",
              "m_2.png",
              "m_3.png",
              "m_4.png",
              "m_5.png",
              "m_6.png",
              "m_7.png",
              "m_8.png",
              "m_9.png",
            ],
            minute_zero: 0,
            minute_space: -150,
            minute_angle: 5,
            minute_follow: 0,
            minute_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );

        idle_digital_clock_img_time_hour = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          {
            hour_startX: 100,
            hour_startY: 140,
            hour_array: [
              "h_0.png",
              "h_1.png",
              "h_2.png",
              "h_3.png",
              "h_4.png",
              "h_5.png",
              "h_6.png",
              "h_7.png",
              "h_8.png",
              "h_9.png",
            ],
            hour_zero: 0,
            hour_space: -220,
            hour_angle: 5,
            hour_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_AOD,
          }
        );*/

        function TimeUpdate() {
          let hrt = time.hour;
          let min = time.minute;
          hour_tens = String(Math.floor(hrt / 10));
          hour_units = String(hrt % 10);
          minute_tens = String(Math.floor(min / 10));
          minute_units = String(min % 10);
          normal_digital_clock_img_hour_tens.setProperty(
            hmUI.prop.TEXT,
            hour_tens
          );
          normal_digital_clock_img_hour_units.setProperty(
            hmUI.prop.TEXT,
            hour_units
          );
          normal_digital_clock_img_minute_tens.setProperty(
            hmUI.prop.TEXT,
            minute_tens
          );
          normal_digital_clock_img_minute_units.setProperty(
            hmUI.prop.TEXT,
            minute_units
          );
        }

        if (wfScreen) {
          timer.createTimer(0, 100, function () {
            PointUpdate();
          });
        }

        time.addEventListener(time.event.MINUTEEND, function () {
          TimeUpdate();
        });

        function text_update() {
          let valueHeartRate = heart_rate.last;
          let normal_heart_rate_rotate_string =
            parseInt(valueHeartRate).toString();

          if (screenType != hmSetting.screen_type.AOD) {
            for (var i = 1; i < 3; i++) {
              // hide all symbols
              normal_heart_rate_TextRotate[i].setProperty(
                hmUI.prop.VISIBLE,
                false
              );
            }
            normal_heart_rate_TextRotate_unit.setProperty(
              hmUI.prop.VISIBLE,
              false
            );
            if (
              valueHeartRate != null &&
              valueHeartRate != undefined &&
              isFinite(valueHeartRate) &&
              normal_heart_rate_rotate_string.length > 0 &&
              normal_heart_rate_rotate_string.length < 6
            ) {
              // display data if it was possible to get it
              let img_offset = 0;
              // alignment = RIGHT
              let normal_heart_rate_TextRotate_posOffset =
                normal_heart_rate_TextRotate_img_width *
                normal_heart_rate_rotate_string.length;
              img_offset -= normal_heart_rate_TextRotate_posOffset;
              // alignment end

              let index = 0;
              for (let char of normal_heart_rate_rotate_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 3) break;
                if (charCode >= 0 && charCode < 10) {
                  normal_heart_rate_TextRotate[index].setProperty(
                    hmUI.prop.POS_X,
                    90 + img_offset
                  );
                  normal_heart_rate_TextRotate[index].setProperty(
                    hmUI.prop.SRC,
                    normal_heart_rate_TextRotate_ASCIIARRAY[charCode]
                  );
                  normal_heart_rate_TextRotate[index].setProperty(
                    hmUI.prop.VISIBLE,
                    true
                  );
                  img_offset += normal_heart_rate_TextRotate_img_width;
                  index++;
                } // end if digit
              } // end char of string
              normal_heart_rate_TextRotate_unit.setProperty(
                hmUI.prop.POS_X,
                90 + img_offset
              );
              normal_heart_rate_TextRotate_unit.setProperty(
                hmUI.prop.VISIBLE,
                true
              );
            } // end isFinite
            else {
              normal_heart_rate_TextRotate[0].setProperty(
                hmUI.prop.POS_X,
                90 - normal_heart_rate_TextRotate_error_img_width / 2
              );
              normal_heart_rate_TextRotate[0].setProperty(
                hmUI.prop.SRC,
                "bpm_err.png"
              );
              normal_heart_rate_TextRotate[0].setProperty(
                hmUI.prop.VISIBLE,
                true
              );
            } // end else isFinite
          }

          let valueStep = step.current;
          let normal_step_rotate_string = parseInt(valueStep).toString();

          if (screenType != hmSetting.screen_type.AOD) {
            for (var i = 1; i < 5; i++) {
              // hide all symbols
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }
            normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            if (
              valueStep != null &&
              valueStep != undefined &&
              isFinite(valueStep) &&
              normal_step_rotate_string.length > 0 &&
              normal_step_rotate_string.length < 6
            ) {
              // display data if it was possible to get it
              let img_offset = 0;

              let index = 0;
              for (let char of normal_step_rotate_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 5) break;
                if (charCode >= 0 && charCode < 10) {
                  normal_step_TextRotate[index].setProperty(
                    hmUI.prop.POS_X,
                    90 + img_offset
                  );
                  normal_step_TextRotate[index].setProperty(
                    hmUI.prop.SRC,
                    normal_step_TextRotate_ASCIIARRAY[charCode]
                  );
                  normal_step_TextRotate[index].setProperty(
                    hmUI.prop.VISIBLE,
                    true
                  );
                  img_offset += normal_step_TextRotate_img_width;
                  index++;
                } // end if digit
              } // end char of string
              normal_step_TextRotate_unit.setProperty(
                hmUI.prop.POS_X,
                90 + img_offset
              );
              normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
            } // end isFinite
            else {
              normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 90);
              normal_step_TextRotate[0].setProperty(
                hmUI.prop.SRC,
                "bpm_err.png"
              );
              normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
            } // end else isFinite
          }
        }

        function scale_call() {
          let valueCalories = calorie.current;
          let targetCalories = calorie.target;
          let progressCalories = valueCalories / targetCalories;
          if (progressCalories > 1) progressCalories = 1;
          let progress_cs_normal_calorie = progressCalories;

          if (screenType != hmSetting.screen_type.AOD) {
            // normal_calorie_circle_scale_circle_scale
            let level = Math.round(progress_cs_normal_calorie * 100);
            if (level < 10) level == 10;
            if (normal_calorie_circle_scale) {
              normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                center_x: 233,
                center_y: 233,
                start_angle: -119,
                end_angle: -168,
                radius: 214,
                line_width: 13,
                corner_flag: 0,
                color: 0xff018fc4,
                show_level: hmUI.show_level.ONLY_NORMAL,
                level: level,
              });
            }
          }

          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_cs_normal_battery = progressBattery;

          if (screenType != hmSetting.screen_type.AOD) {
            // normal_battery_circle_scale_circle_scale
            let level = Math.round(progress_cs_normal_battery * 100);
            if (level < 10) level == 10;
            if (normal_battery_circle_scale) {
              normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                center_x: 233,
                center_y: 233,
                start_angle: -61,
                end_angle: -12,
                radius: 214,
                line_width: 13,
                corner_flag: 0,
                color: 0xffffb100,
                show_level: hmUI.show_level.ONLY_NORMAL,
                level: level,
              });
            }
          }
        }

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            scale_call();
            text_update();
            TimeUpdate();
          },
          pause_call: function () {
            TimeUpdate();
            timer.stopTimer();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
