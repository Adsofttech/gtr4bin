﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_stress_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'backG_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -65,
              second_startY: -6,
              second_array: ["Second_redline_0001.png","Second_redline_0002_1.png","Second_redline_0003.png","Second_redline_0004.png","Second_redline_0005.png","Second_redline_0006.png","Second_redline_0007.png","Second_redline_0008.png","Second_redline_0009.png","Second_redline_0010.png"],
              second_zero: 1,
              second_space: 13,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 0,
              src: 'Center_Grey_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: -204,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 48,
              minute_startY: 153,
              minute_array: ["Minute_white_0001.png","Minute_white_0002.png","Minute_white_0003.png","Minute_white_0004.png","Minute_white_0005.png","Minute_white_0006.png","Minute_white_0007.png","Minute_white_0008.png","Minute_white_0009.png","Minute_white_0010.png"],
              minute_zero: 1,
              minute_space: -204,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: -13,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 426,
              src: 'bluetoothoff (2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -43,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: -13,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: -204,
              hour_align: hmUI.align.LEFT,

              minute_startX: 48,
              minute_startY: 153,
              minute_array: ["Minute_white_0001.png","Minute_white_0002.png","Minute_white_0003.png","Minute_white_0004.png","Minute_white_0005.png","Minute_white_0006.png","Minute_white_0007.png","Minute_white_0008.png","Minute_white_0009.png","Minute_white_0010.png"],
              minute_zero: 1,
              minute_space: -204,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 426,
              src: 'bluetoothoff (2).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: 0,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  