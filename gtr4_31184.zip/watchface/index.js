﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_stress_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'index_modern03 (Custom).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 215,
              src: 'mini_back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 312,
              src: 'icon_DND_lightgrey.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 215,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 64,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 353,
              image_array: ["battry_small_red_0001.png","battry_small_red_0002.png","battry_small_red_0003.png","battry_small_red_0004.png","battry_small_red_0005.png","battry_small_red_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 202,
              day_sc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_tc_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_en_array: ["digi_googlesan_redsmallsize3_0001.png","digi_googlesan_redsmallsize3_0002.png","digi_googlesan_redsmallsize3_0003.png","digi_googlesan_redsmallsize3_0004.png","digi_googlesan_redsmallsize3_0005.png","digi_googlesan_redsmallsize3_0006.png","digi_googlesan_redsmallsize3_0007.png","digi_googlesan_redsmallsize3_0008.png","digi_googlesan_redsmallsize3_0009.png","digi_googlesan_redsmallsize3_0010.png"],
              day_zero: 0,
              day_space: -49,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 251,
              y: 208,
              week_en: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_tc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              week_sc: ["digi_googlesan_darksmallsize3_0001.png","digi_googlesan_darksmallsize3_0002.png","digi_googlesan_darksmallsize3_0003.png","digi_googlesan_darksmallsize3_0004.png","digi_googlesan_darksmallsize3_0005.png","digi_googlesan_darksmallsize3_0006.png","digi_googlesan_darksmallsize3_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0001.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 26,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0002.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 27,
              minute_posY: 211,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture25.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 357,
              y: 205,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0001.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 26,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0002.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 28,
              minute_posY: 211,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -25,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  