﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 300,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 303,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 300,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 300,
              src: '0188.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 407,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_018.png',
              unit_tc: 'A100_018.png',
              unit_en: 'A100_018.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 345,
              image_array: ["A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 353,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_019.png',
              unit_tc: 'A100_019.png',
              unit_en: 'A100_019.png',
              dot_image: '0091.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 353,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 69,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 72,
              src: '0080.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 69,
              font_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 78,
              image_array: ["Z1.png","Z2.png","Z3.png","Z4.png","Z5.png","Z6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 11,
              month_sc_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_tc_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_en_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 18,
              day_sc_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_tc_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_en_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 211,
              y: 355,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "run_anim",
              anim_fps: 40,
              anim_size: 25,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 135,
              hour_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 260,
              minute_startY: 135,
              minute_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 135,
              src: 'A100_005.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0269.png',
              // center_x: 233,
              // center_y: 233,
              // x: 9,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 9,
              pos_y: 233 - 231,
              center_x: 233,
              center_y: 233,
              src: '0269.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 356,
              week_en: ["A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png","A100_069.png"],
              week_tc: ["A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png","A100_069.png"],
              week_sc: ["A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png","A100_069.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 70,
              month_sc_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_tc_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_en_array: ["A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 75,
              day_sc_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_tc_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_en_array: ["A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 158,
              hour_array: ["015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 267,
              minute_startY: 158,
              minute_array: ["025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 158,
              src: 'A100_005.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0269.png',
              // center_x: 233,
              // center_y: 233,
              // x: 9,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 233 - 9,
              pos_y: 233 - 231,
              center_x: 233,
              center_y: 233,
              src: '0269.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 135,
              w: 191,
              h: 150,
              src: '23.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 135,
              w: 183,
              h: 154,
              src: '23.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 7,
              w: 194,
              h: 50,
              src: '23.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 294,
              w: 125,
              h: 50,
              src: '23.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 64,
              w: 148,
              h: 50,
              src: '23.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 296,
              w: 116,
              h: 46,
              src: '23.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 63,
              w: 143,
              h: 50,
              src: '23.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 350,
              w: 400,
              h: 50,
              src: '23.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}