﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Big_Time_Bckg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 119,
              y: 151,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "ANI_BLF",
              anim_fps: 15,
              anim_size: 13,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 330,
              font_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'MF_Small_Perc.png',
              unit_tc: 'MF_Small_Perc.png',
              unit_en: 'MF_Small_Perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 127,
              font_array: ["MF_Small_0.png","MF_Small_1.png","MF_Small_2.png","MF_Small_3.png","MF_Small_4.png","MF_Small_5.png","MF_Small_6.png","MF_Small_7.png","MF_Small_8.png","MF_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MF_Small_Deg.png',
              unit_tc: 'MF_Small_Deg.png',
              unit_en: 'MF_Small_Deg.png',
              negative_image: 'MF_Small_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 127,
              font_array: ["MF_Small_0.png","MF_Small_1.png","MF_Small_2.png","MF_Small_3.png","MF_Small_4.png","MF_Small_5.png","MF_Small_6.png","MF_Small_7.png","MF_Small_8.png","MF_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MF_Small_Deg.png',
              unit_tc: 'MF_Small_Deg.png',
              unit_en: 'MF_Small_Deg.png',
              negative_image: 'MF_Small_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 85,
              font_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'MF_Medium_Deg.png',
              unit_tc: 'MF_Medium_Deg.png',
              unit_en: 'MF_Medium_Deg.png',
              negative_image: 'MF_Medium_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 20,
              day_sc_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_tc_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_en_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 350,
              font_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 307,
              image_array: ["Batt_Green_0.png","Batt_Green_1.png","Batt_Green_2.png","Batt_Green_3.png","Batt_Green_4.png","Batt_Green_5.png","Batt_Green_6.png","Batt_Green_7.png","Batt_Green_8.png","Batt_Green_9.png","Batt_Green_10.png","Batt_Green_11.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 189,
              hour_array: ["DEG7_Big_White_0.png","DEG7_Big_White_1.png","DEG7_Big_White_2.png","DEG7_Big_White_3.png","DEG7_Big_White_4.png","DEG7_Big_White_5.png","DEG7_Big_White_6.png","DEG7_Big_White_7.png","DEG7_Big_White_8.png","DEG7_Big_White_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_unit_sc: 'DEG7_Big_White_DDot.png',
              hour_unit_tc: 'DEG7_Big_White_DDot.png',
              hour_unit_en: 'DEG7_Big_White_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DEG7_Big_White_0.png","DEG7_Big_White_1.png","DEG7_Big_White_2.png","DEG7_Big_White_3.png","DEG7_Big_White_4.png","DEG7_Big_White_5.png","DEG7_Big_White_6.png","DEG7_Big_White_7.png","DEG7_Big_White_8.png","DEG7_Big_White_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 329,
              second_startY: 327,
              second_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'GTR4_Big_Time_Bckg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 20,
              day_sc_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_tc_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_en_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 189,
              hour_array: ["DEG7_Big_White_0.png","DEG7_Big_White_1.png","DEG7_Big_White_2.png","DEG7_Big_White_3.png","DEG7_Big_White_4.png","DEG7_Big_White_5.png","DEG7_Big_White_6.png","DEG7_Big_White_7.png","DEG7_Big_White_8.png","DEG7_Big_White_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_unit_sc: 'DEG7_Big_White_DDot.png',
              hour_unit_tc: 'DEG7_Big_White_DDot.png',
              hour_unit_en: 'DEG7_Big_White_DDot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DEG7_Big_White_0.png","DEG7_Big_White_1.png","DEG7_Big_White_2.png","DEG7_Big_White_3.png","DEG7_Big_White_4.png","DEG7_Big_White_5.png","DEG7_Big_White_6.png","DEG7_Big_White_7.png","DEG7_Big_White_8.png","DEG7_Big_White_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 329,
              second_startY: 327,
              second_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  