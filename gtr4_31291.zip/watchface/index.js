﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -86,
              y: -19,
              src: 'Picture83.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 174,
              font_array: ["small_comple_blac_0001.png","small_comple_blac_0002.png","small_comple_blac_0003.png","small_comple_blac_0004.png","small_comple_blac_0005.png","small_comple_blac_0006.png","small_comple_blac_0007.png","small_comple_blac_0008.png","small_comple_blac_0009.png","small_comple_blac_0010.png"],
              padding: false,
              h_space: -58,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 352,
              y: 170,
              src: 'icon_haert_greyshade.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 1,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 275,
              font_array: ["small_comple_blac_0001.png","small_comple_blac_0002.png","small_comple_blac_0003.png","small_comple_blac_0004.png","small_comple_blac_0005.png","small_comple_blac_0006.png","small_comple_blac_0007.png","small_comple_blac_0008.png","small_comple_blac_0009.png","small_comple_blac_0010.png"],
              padding: false,
              h_space: -60,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 358,
              y: 265,
              src: 'Picture93.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 87,
              font_array: ["small_comple_blac_0001.png","small_comple_blac_0002.png","small_comple_blac_0003.png","small_comple_blac_0004.png","small_comple_blac_0005.png","small_comple_blac_0006.png","small_comple_blac_0007.png","small_comple_blac_0008.png","small_comple_blac_0009.png","small_comple_blac_0010.png"],
              padding: false,
              h_space: -57,
              unit_sc: 'perct.png',
              unit_tc: 'perct.png',
              unit_en: 'perct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 93,
              src: 'icon_batt_greyshade.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: -68,
              hour_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              hour_zero: 1,
              hour_space: -92,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 40,
              minute_startY: 47,
              minute_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              minute_zero: 1,
              minute_space: -90,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -86,
              y: -19,
              src: 'Picture83.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 277,
              font_array: ["small_comple_blac_0001.png","small_comple_blac_0002.png","small_comple_blac_0003.png","small_comple_blac_0004.png","small_comple_blac_0005.png","small_comple_blac_0006.png","small_comple_blac_0007.png","small_comple_blac_0008.png","small_comple_blac_0009.png","small_comple_blac_0010.png"],
              padding: false,
              h_space: -57,
              unit_sc: 'perct.png',
              unit_tc: 'perct.png',
              unit_en: 'perct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 364,
              y: 289,
              src: 'icon_batt_greyshade.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: -68,
              hour_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              hour_zero: 1,
              hour_space: -92,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 40,
              minute_startY: 47,
              minute_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              minute_zero: 1,
              minute_space: -90,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -49,
              y: -24,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  