﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

        //dynamic modify start
        let normal_background_bg_img = ''
		let alarm_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let chronoInterval;
		let chronoIsRunning = false;
		let chronoStart = 0;
		let chronoStoppedAt = 0;
		let normal_chrono_seconds_rotary = '';
		let normal_chrono_seconds_rotary_start_angle = 0;
		let normal_chrono_seconds_rotary_end_angle = 360;
		let normal_chrono_minutes_rotary = '';
		let normal_chrono_minutes_rotary_start_angle = 0;
		let normal_chrono_minutes_rotary_end_angle = 720;
		let normal_chrono_start_stop = '';
		let normal_chrono_start_stop_array = ['0026.png','0026.png'];
		let normal_chrono_reset = '';
		let normal_chrono_reset_array = ['0026.png','0027.png'];
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
               text: 'Steps Today'				
            });
          };
            if (zona2_num == 1) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
              text: 'Distance Today'				
            });
          };
           if (zona2_num == 2) {		  
		  	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
              text: 'Calorie Today' 				
            });
          };
        }


        //dynamic modify end

        // vibrate function
		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let timer_StopVibrate = null;

		function vibro(scene = 25) {
		  let stopDelay = 50;
		  stopVibro();
		  vibrate.stop();
		  vibrate.scene = scene;
		  if(scene < 23 || scene > 25) stopDelay = 1300;
		  vibrate.start();
		  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
		}

		function stopVibro(){
		  vibrate.stop();
		  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

		// end vibrate function



       //not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_chrono_seconds_rotary = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				center_x: 365,
				center_y: 165,
				pos_x: 355,
				pos_y: 113,
				src: '58.png',
				enable: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			

			normal_chrono_minutes_rotary = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				center_x: 110,
				center_y: 165,
				pos_x: 100,
				pos_y: 113,
				src: '58.png',
				enable: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 312,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dot.png',
			  invalid_image: 's_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 163,
              y: 104,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 103,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 410,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -3,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 405,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 265,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 261,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 265,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 48,
              y: 258,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 265,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 48,
              y: 258,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 229,
              font_array: ["59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              padding: false,
              h_space: -2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 290,
              y: 278,
              week_en: ["86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              week_tc: ["86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              week_sc: ["86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '58.png',
              center_x: 236,
              center_y: 161,
              posX: 10,
              posY: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 355,
              year_startY: 269,
              year_sc_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              year_tc_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              year_en_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 269,
              day_sc_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              day_tc_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              day_en_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 78,
              font_array: ["fnt_0.png","fnt_1.png","fnt_2.png","fnt_3.png","fnt_4.png","fnt_5.png","fnt_6.png","fnt_7.png","fnt_8.png","fnt_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 78,
              font_array: ["fnt_0.png","fnt_1.png","fnt_2.png","fnt_3.png","fnt_4.png","fnt_5.png","fnt_6.png","fnt_7.png","fnt_8.png","fnt_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 345,
              am_y: 370,
              am_sc_path: '135.png',
              am_en_path: '135.png',
              pm_x: 345,
              pm_y: 370,
              pm_sc_path: '136.png',
              pm_en_path: '136.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 340,
              hour_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 238,
              minute_startY: 340,
              minute_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 337,
              second_startY: 342,
              second_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 329,
              src: '11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '138.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 127,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '139.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 14,
              minute_posY: 192,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '140.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 42,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			     normal_chrono_start_stop = hmUI.createWidget(hmUI.widget.IMG, {
					x: 325,
					y: 125,
					w: 80,
					h: 80,
					src: '0026.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_start_stop.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoInterval = setInterval(updateChrono, 1);
						chronoIsRunning = true;
						chronoStart = chronoStart == 0 ? timeSensor.utc : chronoStart + (timeSensor.utc-chronoStoppedAt);
					} else {
						clearInterval(chronoInterval);
						chronoIsRunning = false;
						chronoStoppedAt = timeSensor.utc;
					}
					normal_chrono_start_stop.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_start_stop_array[Number(chronoIsRunning)]
					})
					normal_chrono_reset.setProperty(hmUI.prop.MORE, {
						src: normal_chrono_reset_array[Number(chronoIsRunning)],
						enable: !chronoIsRunning
					})
					vibro();
				});

				normal_chrono_reset = hmUI.createWidget(hmUI.widget.IMG, {
					x: 70,
					y: 125,
					w: 80,
					h: 80,
					src: '0027.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_chrono_reset.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					if (!chronoIsRunning) {
						chronoStart = 0;
						/*
						if (typeof normal_chrono_hours != 'undefined') {
							for (let i=0; i < normal_chrono_hours.length; i++) {
								normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_hours_array[0]
								})
							}
						}
						if (typeof normal_chrono_minutes != 'undefined') {
							for (let i=0; i < normal_chrono_minutes.length; i++) {
								normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_minutes_array[0]
								})
							}
						}
						if (typeof normal_chrono_seconds != 'undefined') {
							for (let i=0; i < normal_chrono_seconds.length; i++) {
								normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_seconds_array[0]
								})
							}
						}
						if (typeof normal_chrono_milliseconds != 'undefined') {
							for (let i=0; i < normal_chrono_milliseconds.length; i++) {
								normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
									src: normal_chrono_milliseconds_array[0]
								})
							}
						}

						if (typeof normal_chrono_hours_rotary != 'undefined') {
							normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_hours_rotary_start_angle
							})
						}
						*/
						if (typeof normal_chrono_minutes_rotary != 'undefined') {
							normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_minutes_rotary_start_angle
							})
						}

						if (typeof normal_chrono_seconds_rotary != 'undefined') {
							normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
								angle: normal_chrono_seconds_rotary_start_angle
							})
						}

						vibro();
					}
				});
				
				
			function updateChrono() {
					let curTime = timeSensor.utc;
					let curDiff = curTime-chronoStart;
					let curMilli = curDiff.toString().substr(curDiff.toString().length - 3).padStart(3, '0');
					let curSeconds = Math.floor((curDiff)/1000).toString().padStart(2, '0');
					let curMinutes = Math.floor(curSeconds/60).toString().padStart(2, '0');
					let curHours = Math.floor(curMinutes/60).toString().padStart(2, '0');
					/*
					if (typeof normal_chrono_hours != 'undefined' && normal_chrono_hours.length > 0) {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[curHours.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_minutes != 'undefined' && normal_chrono_minutes.length > 0) {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[curMinutes.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_seconds != 'undefined' && normal_chrono_seconds.length > 0) {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[curSeconds.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_milliseconds != 'undefined' && normal_chrono_milliseconds.length > 0) {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[curMilli.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_hours_rotary != 'undefined') {
						let hsa = normal_chrono_hours_rotary_start_angle;
						let hea = normal_chrono_hours_rotary_end_angle;
						let hcw = hea > hsa;
						let hd = hcw ? hea - hsa : hsa - hea;
						let hfac = hd / 360;
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: (hcw ? (hsa + (parseInt(curHours) * (6 * hfac))) : (hsa - (parseInt(curHours) * (6 * hfac))))
						})
					}
*/
					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						let msa = normal_chrono_minutes_rotary_start_angle;
						let mea = normal_chrono_minutes_rotary_end_angle;
						let mcw = mea > msa;
						let md = mcw ? mea - msa : msa - mea;
						let mfac = md / 360;
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: (mcw ? (msa + (parseInt(curMinutes) * (6 * mfac))) : (msa - (parseInt(curMinutes) * (6 * mfac))))
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						let ssa = normal_chrono_seconds_rotary_start_angle;
						let sea = normal_chrono_seconds_rotary_end_angle;
						let scw = sea > ssa;
						let sd = scw ? sea - ssa : ssa - sea;
						let sfac = sd / 360;
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: (scw ? (ssa + ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))) : (ssa - ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))))
						})
					}

				}


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 163,
              y: 104,
              src: 'bluetooth_(10).png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 103,
              src: 'free-icon-notification-bell-3541850.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '138.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 16,
              hour_posY: 127,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '139.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 14,
              minute_posY: 192,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '140.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 42,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Signal LOST,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Signal FIND,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Signal LOST"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Signal FIND"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 59,
              w: 60,
              h: 40,
              src: 'Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 250,        
				 y: 263,      
				 w: 175,       
				 h: 50,     
				 text: '',      
				 normal_src: 'Empty.png',        
				 press_src: 'Empty.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });      
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50, 
              y: 257, 
              text: '',
              w: 135, 
              h: 40, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_zona2();
                click_Vibrate(); 
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                if (chronoIsRunning) {
					chronoInterval = setInterval(updateChrono, 50);
				}
				checkConnection();
                stopVibro();
              }),
              pause_call: (function () {
                clearInterval(chronoInterval);
				stopVibro();
              }),
            });
			
		},	

                //dynamic modify end
        onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
        },
        });	})()
} catch (e) {
	console.log(e)
}