﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */
    // import { Barometer } from '@zos/sensor'

    try {
     (() => {

      const {
       beforeModuleCreate = () => {}, afterModuleCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforeModuleCreate()

      const {
       beforePageCreate = () => {}, afterPageCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforePageCreate()
      const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__

       //dynamic modify start

       ! function (context) {
        with(context) {

         const hmUI = __$$R$$__('@zos/ui');
         const hmSensor = __$$R$$__('@zos/sensor');
         const hmScene = __$$R$$__('@zos/app');
         const hmRouter = __$$R$$__('@zos/router');
         const hmDevice = __$$R$$__('@zos/device');
         const hmBle = __$$R$$__('@zos/ble');
         const hmStorage = __$$R$$__('@zos/storage');

         const gettext = console.log;
         const barometer = new hmSensor.Barometer();
         const altitude = barometer.getAltitude();
         let airPressure = barometer.getAirPressure() * 0.750064;
         const {
          width: DEVICE_WIDTH,
          height: DEVICE_HEIGHT
         } = hmDevice.getDeviceInfo();


         //const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
         //const battery = new hmSensor.Battery();
         //const distance = new hmSensor.Distance();
         const calorie = new hmSensor.Calorie();
         const step = new hmSensor.Step();


         const curTime = new hmSensor.Time();
         let MonthClok = curTime.getMonth();
			
         const weather = new hmSensor.Weather();
         let weatherData = weather.getForecast();
         let forecastData = weatherData.forecastData;

			
			


         let normal_background_bg = ''
         let normal_analog_clock_pro_second_pointer_img = ''
         let normal_timerUpdateSec = undefined;
         let normal_image_img = ''
         let normal_battery_image_progress_img_level = ''
         let normal_week_pointer_progress_date_pointer = ''
         let normal_date_img_date_week_img = ''
         let normal_date_img_date_month_img = ''
         let normal_digital_clock_img_time = ''
         let normal_pai_icon_img = ''
         let normal_step_icon_img = ''
         let normal_step_circle_scale = ''
         let normal_step_current_text_img = ''
         let normal_calorie_icon_img = ''
         let normal_calorie_circle_scale = ''
         let normal_calorie_current_text_img = ''
         let normal_distance_icon_img = ''
         let normal_distance_text_text_img = ''
         let normal_date_img_date_day = ''
         let normal_heart_rate_text_text_img = ''
         let normal_heart_rate_image_progress_img_level = ''
         let normal_stand_circle_scale = ''
         let normal_temperature_icon_img = ''
         let normal_temperature_high_text_img = ''
         let normal_temperature_high_separator_img = ''
         let normal_temperature_low_text_img = ''
         let normal_temperature_current_text_img = ''
         let normal_weather_image_progress_img_level = ''
         let normal_sun_current_text_img = ''
         let normal_system_disconnect_img = ''
         let normal_system_clock_img = ''
         let normal_analog_clock_time_pointer_hour = ''
         let normal_analog_clock_time_pointer_minute = ''
         let normal_analog_clock_time_pointer_second = ''
         let timeSensor = ''
         
    let bgColor = [0xf87202, 0xf80202, 0x0ef802, 0xf8f502, 0x02bbf8, 0xf502f8];
         

         let btn_color = ''
         let color = 0

         function click_color() {

          color = (color + 1) % 6;
             
//          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, color == 0);
             
             
            normal_stress_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: 'bg_' + color + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
             
             
           normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 347,
            start_angle: 0,
            end_angle: 360,
            radius: 76,
            line_width: 3,
            corner_flag: 0,
        		color: bgColor[color],
            level: level,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
             
             

           normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 347,
            start_angle: 0,
            end_angle: 360,
            radius: 76,
            line_width: 3,
            corner_flag: 0,
        		color: bgColor[color],
            level: level2,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });             
             
          normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
           center_x: 233,
           center_y: 347,
           start_angle: -180,
           end_angle: 180,
           radius: 76,
           line_width: 3,
           corner_flag: 0,
        		color: bgColor[color],
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });  
             
             normal_ALTIMETER_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 347,
              start_angle: -180,
              end_angle: 180,
              radius: 76,
              line_width: 3,
              corner_flag: 0,
        		color: bgColor[color], 
              level: level3,
              show_level: hmUI.show_level.ONLY_NORMAL,
             });
             
             
            if (str == 0) {
          str_color(color);}

          //hmFS.SysProSetInt('dtec_zona_midle', zona_midle);
         }
            
         function str_color(handsnumberMin) {
          switch (handsnumberMin) {
           case 1:
            Hourstring_color = 'str_H_1.png';
            Minutestring_color = 'str_M_1.png';
            break;

           case 2:
            Hourstring_color = 'str_H_2.png';
            Minutestring_color = 'str_M_2.png';
            break;

           case 3:
            Hourstring_color = 'str_H_3.png';
            Minutestring_color = 'str_M_3.png';
            break;

           case 4:
            Hourstring_color = 'str_H_4.png';
            Minutestring_color = 'str_M_4.png';
            break;

           case 5:
            Hourstring_color = 'str_H_5.png';
            Minutestring_color = 'str_M_5.png';
            break;

              default:
            Hourstring_color = 'str_H_0.png';
            Minutestring_color = 'str_M_0.png';

            break;
          }

          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
           hour_path: Hourstring_color,
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 30,
           hour_posY: 132,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
           minute_path: Minutestring_color,
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 30,
           minute_posY: 175,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


         }
            


         
         

         let btn_str = ''
         let str = 0

         function click_str() {

          str = (str + 1) % 2;

          call_change_Min(str);

            if (str == 0) {
          str_color(color);}


          //hmFS.SysProSetInt('dtec_zona_midle', zona_midle);
         }

         function call_change_Min(handsnumberMin) {
          switch (handsnumberMin) {
           case 1:
            Hourstring = '0_Empty.png';
            Minutestring = '0_Empty.png';
            Secondstring = '0_Empty.png';
            break;

           default:
            Hourstring = 'str_H_0.png';
            Minutestring = 'str_M_0.png';
            Secondstring = 'str_SS.png';
            break;
          }

          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
           hour_path: Hourstring,
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 30,
           hour_posY: 132,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
           minute_path: Minutestring,
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 30,
           minute_posY: 175,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
           second_path: Secondstring,
           second_centerX: 233,
           second_centerY: 233,
           second_posX: 23,
           second_posY: 217,
           second_cover_path: 'cap_sec.png',
           second_cover_x: 201,
           second_cover_y: 201,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


         }


         let btn_zona = ''
         let zona = 0

         function click_zona() {

          zona = (zona + 1) % 5;


          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, zona < 2);

          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, zona == 2);

          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, zona == 1);

          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 3);
          normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, zona == 3);
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, zona == 3);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, zona == 3);
          normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, zona == 3);


          ALTIMETER_txt.setProperty(hmUI.prop.VISIBLE, zona == 4);
          normal_ALTIMETER_circle_scale.setProperty(hmUI.prop.VISIBLE, zona == 4);
          normal_ALTIMETER_icon_img.setProperty(hmUI.prop.VISIBLE, zona == 4);

          //hmFS.SysProSetInt('dtec_zona_midle', zona_midle);
         }


         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }


         let vibrate = new hmSensor.Vibrator();
         let stopVibro_Timer = null;


         function vibro(mode = 25) {
          let stopDelay = 25;
          vibrate.stop();
          //vibrate.setMode(mode);
          vibrate.start(mode);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
          stopVibro_Timer = setTimeout(() => {
           stopVibro();
          }, stopDelay);
         }

         function stopVibro() {
          vibrate.stop();
          //timer.stopTimer(stopVibro_Timer);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
         }


         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }


         //	---------------------------------------------------------		

         //переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
         let weatherTxtImgArray = []
         let weatherTxtImgArrayN = []
         let pointred = new Array(6);
         let pointblue = new Array(5);
         let linered = new Array(6);
         let lineblue = new Array(5);
         let yArrH = new Array(6);
         let yArrL = new Array(5);
         let y_pogodaH = new Array(6);
         let y_pogodaL = new Array(5);
         let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
         let week_weater_img = []
         let day_weater_img = []
         const ROOTPATH = "images/"

         let normal_city_name_text = ''


         //-------------------------------- 

         //массив иконок для графика       
         for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
         }


         //обновление для   графика           
         function updateGrafik() {

          const weather = new hmSensor.Weather();
          let weatherData = weather.getForecast();
          let forecastData = weatherData.forecastData;

          //normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);


          if (forecastData.count == 0) {
           for (let i = 0; i < 6; i++) {
            var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
           }
          } else {
           let weekDay = curTime.getDay() - 1;
           for (let i = 0; i < 6; i++) {
            yArrH[i] = forecastData.data[i].high;
            let element = forecastData.data[i];
            let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
            // let date = new Date(curTime.utc + 86400000 * i);
            let date = new Date(curTime.getTime() + 86400000 * i);
            let data = date.getDate();
            let week = week_weater[weekDay];
            week_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: week,
            });
            day_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: data,
            });
            weekDay = (weekDay + 1) % 7;
           }
          }


          for (let i = 0; i < 5; i++) {
           yArrL[i] = forecastData.data[i].low;
          }
          let maxH = Math.max(...yArrH)
          let maxL = Math.min(...yArrL)
          var shag = 46;
          var x0 = 119;
          for (let i = 0; i < 6; i++) {
           pointred[i].setProperty(hmUI.prop.MORE, {
            x: 119 + shag * [i] - 5,
            y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFFFF0000,
            line_width: 10,
           });
          };

          for (let i = 0; i < 5; i++) {
           yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            linered[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i,
             h: 466,
             pos_x: -31 + shag * i,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_red.png',
            });
          };
          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 4; i++) {
           yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            lineblue[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i + 23,
             h: 466,
             pos_x: -31 + shag * i + 23,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i + 23,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_blue.png',
            });
          };

          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 6; i++) {
           y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
           weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + i * 45 * 1.02,
            y: y_pogodaH[i] - 38, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrH[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }

          for (let i = 0; i < 5; i++) {
           y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
           weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + 23 + i * 45 * 1.02,
            y: y_pogodaL[i] - 1, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrL[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }
         }


         function makeAOD() {


         }


         //dynamic modify end

         function init_view() {
          //dynamic modify start


          normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: '0xFFDCDCDC',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 187,
              src: 'fix_bg_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



          //const timeSensor = new hmSensor.Time();
          if (!timeSensor) timeSensor = new hmSensor.Time();


          normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           pos_x: 233 - 233,
           pos_y: 233 - 233,
           center_x: 233,
           center_y: 233,
           src: 'str_S.png',
           angle: 0,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_' + color + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


          //let screenType = hmSetting.getScreenType();
          normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: '0000_1.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 305,
           y: 125,
           image_array: ["pr_bat_0.png", "pr_bat_1.png", "pr_bat_2.png", "pr_bat_3.png", "pr_bat_4.png", "pr_bat_5.png", "pr_bat_6.png", "pr_bat_7.png", "pr_bat_8.png", "pr_bat_9.png"],
           image_length: 10,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 153,
              y: 38,
           week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           month_startX: 213,
           month_startY: 135,
           month_sc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_tc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_en_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_is_character: true,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
           hour_startX: 40,
           hour_startY: 163,
           hour_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           hour_zero: 1,
           hour_space: 0,
           hour_angle: 0,
           hour_align: hmUI.align.CENTER_H,

           minute_startX: 40,
           minute_startY: 237,
           minute_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           minute_zero: 1,
           minute_space: 0,
           minute_angle: 0,
           minute_follow: 0,
           minute_align: hmUI.align.CENTER_H,

           second_startX: 154,
           second_startY: 221,
           second_array: ["S_0.png", "S_1.png", "S_2.png", "S_3.png", "S_4.png", "S_5.png", "S_6.png", "S_7.png", "S_8.png", "S_9.png"],
           second_zero: 1,
           second_space: 0,
           second_angle: 0,
           second_follow: 0,
           second_align: hmUI.align.CENTER_H,

           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 385,
           src: 'ic_step.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 347,
           start_angle: 0,
           end_angle: 360,
           radius: 76,
           line_width: 3,
           corner_flag: 0,
           color: 0xFFF87202,
           level: 50,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 187,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 385,
           src: 'ic_kcal.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 347,
           start_angle: 0,
           end_angle: 180,
           radius: 76,
           line_width: 3,
           corner_flag: 0,
           color: 0xFFF87202,
           level: 50,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 194,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_ALTIMETER_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 347,
           start_angle: -180,
           end_angle: 180,
           radius: 76,
           line_width: 3,
           corner_flag: 0,
           color: 0xFFF87202,
           level: 50,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          ALTIMETER_txt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 195-10,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           text: Math.round(airPressure).toString(),
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 385,
           src: 'ic_km.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 186,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           dot_image: 'dig_a_dot.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.DISTANCE,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 100,
           day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_zero: 1,
            day_space: 0,
           day_align: hmUI.align.CENTER_H,
           day_is_character: false,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
          normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 322,
           image_array: ["pr_puls_0.png", "pr_puls_1.png", "pr_puls_2.png", "pr_puls_3.png", "pr_puls_4.png", "pr_puls_5.png"],
           image_length: 6,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             

          normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 301,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_bpm.png',
           unit_tc: 'dig_a_bpm.png',
           unit_en: 'dig_a_bpm.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });



          normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
           center_x: 233,
           center_y: 347,
           start_angle: -180,
           end_angle: 180,
           radius: 76,
           line_width: 3,
           corner_flag: 0,
        		color: bgColor[color],
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 385,
           src: 'ic_temp.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_ALTIMETER_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 385,
           src: 'ic_mrs.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 169,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_g.png',
           unit_tc: 'dig_a_g.png',
           unit_en: 'dig_a_g.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_v.png',
           align_h: hmUI.align.RIGHT,
           type: hmUI.data_type.WEATHER_HIGH,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 227,
           y: 358,
           src: 'dig_a_raz.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 242,
           y: 358,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_a_g.png',
           unit_tc: 'dig_a_g.png',
           unit_en: 'dig_a_g.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_v.png',
           align_h: hmUI.align.LEFT,
           type: hmUI.data_type.WEATHER_LOW,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 58,
           y: 133,
           font_array: ["dig_t_1.png", "dig_t_2.png", "dig_t_3.png", "dig_t_4.png", "dig_t_5.png", "dig_t_6.png", "dig_t_7.png", "dig_t_8.png", "dig_t_9.png", "dig_t_10.png"],
           padding: false,
           h_space: 0,
           unit_sc: 'dig_t_c.png',
           unit_tc: 'dig_t_c.png',
           unit_en: 'dig_t_c.png',
           negative_image: 'dig_t_m.png',
           invalid_image: 'dig_t_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 270,
           y: 127,
           image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 73,
           y: 315,
           font_array: ["dig_b_0.png", "dig_b_1.png", "dig_b_2.png", "dig_b_3.png", "dig_b_4.png", "dig_b_5.png", "dig_b_6.png", "dig_b_7.png", "dig_b_8.png", "dig_b_9.png"],
           padding: false,
           h_space: 0,
           invalid_image: 'dig_b_p.png',
           dot_image: 'dig_b_dot2.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALARM_CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 91,
           y: 60,
           src: 'slider_B_off.png',
           type: hmUI.system_status.DISCONNECT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 56,
           y: 313,
           src: 'slider_H_on.png',
           type: hmUI.system_status.CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_sun_vos = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           pos_x: 466 / 2 - 9 / 2,
           pos_y: 466 / 2 - 233,
           center_x: 233,
           center_y: 233,
           angle: 0,
           src: 'icon_sun_st.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sun_zak = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           pos_x: 466 / 2 - 9 / 2,
           pos_y: 466 / 2 - 233,
           center_x: 233,
           center_y: 233,
           angle: 0,
           src: 'icon_lun_st.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H_0.png',
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 30,
           hour_posY: 132,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M_0.png',
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 30,
           minute_posY: 175,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
           second_path: 'str_SS.png',
           second_centerX: 233,
           second_centerY: 233,
           second_posX: 23,
           second_posY: 217,
           second_cover_path: 'cap_sec.png',
           second_cover_x: 201,
           second_cover_y: 201,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          function scale_call() {

          weatherData = weather.getForecast();

    					const {
    						forecastData,
    						tideData
    					} = weatherData
    					const {
    						sunrise: {
    							hour: sunriseHour,
    							minute: sunriseMinute
    						},
    						sunset: {
    							hour: sunsetHour,
    							minute: sunsetMinute
    						}
    					} = tideData.data[0]

    					let san_vos_h = sunriseHour;
    					let san_vos_m = sunriseMinute;
    					let Angle_sun_vos = san_vos_h * 60 / 2 + san_vos_m / 2;
    					normal_sun_vos.setProperty(hmUI.prop.MORE, {
    						angle: Angle_sun_vos,
    					});

    					let san_zak_h = sunsetHour;
    					let san_zak_m = sunsetMinute;
    					let Angle_sun_zak = san_zak_h * 60 / 2 + san_zak_m / 2;
    					normal_sun_zak.setProperty(hmUI.prop.MORE, {
    						angle: Angle_sun_zak,
    					});
           console.log('update scales STEP');

           let valueStep = step.getCurrent();
           //let targetStep = step.target;
           let targetStep = step.getTarget();
           let progressStep = valueStep / targetStep;
           if (progressStep > 1) progressStep = 1;
           let progress_cs_normal_step = progressStep;

           let level = Math.round(progress_cs_normal_step * 100);
           normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 347,
            start_angle: 0,
            end_angle: 360,
            radius: 76,
            line_width: 3,
            corner_flag: 0,
        		color: bgColor[color],
            level: level,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });


           let valueCalories = calorie.getCurrent();
           let targetCalories = calorie.getTarget();
           let progressCalories = valueCalories / targetCalories;
           if (progressCalories > 1) progressCalories = 1;
           let progress_cs_normal_calorie = progressCalories;


           let level2 = Math.round(progress_cs_normal_calorie * 100);
           normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 347,
            start_angle: 0,
            end_angle: 360,
            radius: 76,
            line_width: 3,
            corner_flag: 0,
        		color: bgColor[color],
            level: level2,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });


          };
			 

          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });

          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();
			   
		   
			   
			   
            scale_call();
            updateGrafik();


            let animRepeat = 1000;
            update_sec = setInterval(() => {


             let airPressure = barometer.getAirPressure() * 0.750064;

             let valueALTIMETER = airPressure;
             let targetALTIMETER = 760 + 760;
             let progressALTIMETER = valueALTIMETER / targetALTIMETER;
             if (progressALTIMETER > 1) progressALTIMETER = 1;
             let progress_cs_normal_calorie = progressALTIMETER;

             let level3 = Math.round(progress_cs_normal_calorie * 100);

             normal_ALTIMETER_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 347,
              start_angle: -180,
              end_angle: 180,
              radius: 76,
              line_width: 3,
              corner_flag: 0,
        		color: bgColor[color], 
              level: level3,
              show_level: hmUI.show_level.ONLY_NORMAL,
             });


             ALTIMETER_txt.setProperty(hmUI.prop.TEXT, {
              text: Math.round(airPressure).toString(),
             });


             let second = curTime.getSeconds();

             let normal_fullAngle_second = -360;
             let normal_angle_second = 0 + normal_fullAngle_second * second / 60;
             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);


            }, animRepeat); // end timer


           }),

           pause_call: (function () {

            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
            clearInterval(update_sec)
            stopVibro();
           }),
          });
			 
			 

          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });


          btn_zona = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 299, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            click_zona();
            vibro(); //имя вызываемой функции
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
           longpress_func: () => {
            vibro();
            click_str();
           },

           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
          btn_color = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 292, //x кнопки
           y: 48, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_color();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             


          groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 24,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_run();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_zona_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }

          //--------------------------------------------------------- 




          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
             
             


          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);

          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_stand_circle_scale.setProperty(hmUI.prop.VISIBLE, false);

          ALTIMETER_txt.setProperty(hmUI.prop.VISIBLE, false);
          normal_ALTIMETER_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
          normal_ALTIMETER_icon_img.setProperty(hmUI.prop.VISIBLE, false);

          //dynamic modify end
         }


         __$$module$$__.module = WatchFace({
          onInit() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) loadSettings();
          },
          build() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) {
            makeAOD();
           } else {
            init_view();
           }
          },
          onPause() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: Ставлюсь на паузу!"});
           //else hmUI.showToast({text: "Ставлюсь на паузу!"});
          },
          onResume() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: И снова здравствуйте!!!"});
           //else hmUI.showToast({text: "И снова здравствуйте!!!"});
          },
          onDestroy() {
           vibrate && vibrate.stop();
          }
         });

        }
       }.bind(__$$G$$__)(__$$G$$__);


      afterPageCreate()
      afterModuleCreate()

     })()
    } catch (e) {

     console.log('Mini Program Error', e)
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i))

     /* todo */
    }
