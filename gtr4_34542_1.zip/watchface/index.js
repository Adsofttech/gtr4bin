﻿     /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
 
try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block


        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = '' //Sky Change
        let normal_weather_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather2_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather_text_en_img_level = ''  //Night Weather Icon
        let normal_weather_text_ru_img_level = ''  //Night Weather Icon
        let normal_weather_text_uk_img_level = ''  //Night Weather Icon
        let normal_weather_languege_change_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_bg_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_paiw_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_SLEEP_text_text_img = ''
        let normal_SLEEP_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_training_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_aod_mask_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
		let con_rest = 'Connection Restored'  // text change
		let con_lost = 'Connection Lost'  // text change
		let AOD_Hollow = 'AOD Hollow Font'  // text change
		let AOD_Solid = 'AOD Solid Font'  // text change

		const lang = DeviceRuntimeCore.HmUtils.getLanguage()
		let nor_week = ["Week-en-1.png","Week-en-2.png","Week-en-3.png","Week-en-4.png","Week-en-5.png","Week-en-6.png","Week-en-7.png"];
		let	nor_month = ["Month-en-1.png","Month-en-2.png","Month-en-3.png","Month-en-4.png","Month-en-5.png","Month-en-6.png","Month-en-7.png","Month-en-8.png","Month-en-9.png","Month-en-10.png","Month-en-11.png","Month-en-12.png"];
		let	aod_week = ["AOD-Week-1.png","AOD-Week-2.png","AOD-Week-3.png","AOD-Week-4.png","AOD-Week-5.png","AOD-Week-6.png","AOD-Week-7.png"];
		let	aod_month = ["AOD-Month-1.png","AOD-Month-2.png","AOD-Month-3.png","AOD-Month-4.png","AOD-Month-5.png","AOD-Month-6.png","AOD-Month-7.png","AOD-Month-8.png","AOD-Month-9.png","AOD-Month-10.png","AOD-Month-11.png","AOD-Month-12.png"];

		if(lang=='uk-UA'){
			nor_week=["Week-uk-1.png","Week-uk-2.png","Week-uk-3.png","Week-uk-4.png","Week-uk-5.png","Week-uk-6.png","Week-uk-7.png"];
			nor_month=["Month-uk-1.png","Month-uk-2.png","Month-uk-3.png","Month-uk-4.png","Month-uk-5.png","Month-uk-6.png","Month-uk-7.png","Month-uk-8.png","Month-uk-9.png","Month-uk-10.png","Month-uk-11.png","Month-uk-12.png"];
			aod_week=["AOD-Week-uk-1.png","AOD-Week-uk-2.png","AOD-Week-uk-3.png","AOD-Week-uk-4.png","AOD-Week-uk-5.png","AOD-Week-uk-6.png","AOD-Week-uk-7.png"];
			aod_month=["AOD-Month-uk-1.png","AOD-Month-uk-2.png","AOD-Month-uk-3.png","AOD-Month-uk-4.png","AOD-Month-uk-5.png","AOD-Month-uk-6.png","AOD-Month-uk-7.png","AOD-Month-uk-8.png","AOD-Month-uk-9.png","AOD-Month-uk-10.png","AOD-Month-uk-11.png","AOD-Month-uk-12.png"];
		}
		if(lang=='ru-RU'){
			nor_week=["Week-ru-1.png","Week-ru-2.png","Week-ru-3.png","Week-ru-4.png","Week-ru-5.png","Week-ru-6.png","Week-ru-7.png"];
			nor_month=["Month-ru-1.png","Month-ru-2.png","Month-ru-3.png","Month-ru-4.png","Month-ru-5.png","Month-ru-6.png","Month-ru-7.png","Month-ru-8.png","Month-ru-9.png","Month-ru-10.png","Month-ru-11.png","Month-ru-12.png"];
			aod_week=["AOD-Week-ru-1.png","AOD-Week-ru-2.png","AOD-Week-ru-3.png","AOD-Week-ru-4.png","AOD-Week-ru-5.png","AOD-Week-ru-6.png","AOD-Week-ru-7.png"];
			aod_month=["AOD-Month-ru-1.png","AOD-Month-ru-2.png","AOD-Month-ru-3.png","AOD-Month-ru-4.png","AOD-Month-ru-5.png","AOD-Month-ru-6.png","AOD-Month-ru-7.png","AOD-Month-ru-8.png","AOD-Month-ru-9.png","AOD-Month-ru-10.png","AOD-Month-ru-11.png","AOD-Month-ru-12.png"];
		}

        //dynamic modify end

//vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }


// Autocorrect night weather icons Start
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        let weather_icons = ["Weather-0.png","Weather-1.png","Weather-2.png","Weather-3.png","Weather-4.png","Weather-5.png","Weather-6.png","Weather-.png","Weather-8.png","Weather-9.png","Weather-10.png","Weather-11.png","Weather-.png","Weather-13.png","Weather-14.png","Weather-15.png","Weather-16.png","Weather-17.png","Weather-18.png","Weather-19.png","Weather-20.png","Weather-21.png","Weather-22.png","Weather-23.png","Weather-24.png","Weather-25.png","Weather-0n.png","Weather-1n.png","Weather-3n.png"]
        let weather2_icons = ["Weather2-0.png","Weather2-1.png","Weather2-2.png","Weather2-3.png","Weather2-4.png","Weather2-5.png","Weather2-6.png","Weather2-.png","Weather2-8.png","Weather2-9.png","Weather2-10.png","Weather2-11.png","Weather2-.png","Weather2-13.png","Weather2-14.png","Weather2-15.png","Weather2-16.png","Weather2-17.png","Weather2-18.png","Weather2-19.png","Weather2-20.png","Weather2-21.png","Weather2-22.png","Weather2-23.png","Weather2-24.png","Weather2-25.png","Weather2-0n.png","Weather2-1n.png","Weather2-3n.png"]
        let weather_text_ru	= ["Weather-ru-0.png","Weather-ru-1.png","Weather-ru-2.png","Weather-ru-3.png","Weather-ru-4.png","Weather-ru-5.png","Weather-ru-6.png","Weather-ru-.png","Weather-ru-8.png","Weather-ru-9.png","Weather-ru-10.png","Weather-ru-11.png","Weather-ru-.png","Weather-ru-13.png","Weather-ru-14.png","Weather-ru-15.png","Weather-ru-16.png","Weather-ru-17.png","Weather-ru-18.png","Weather-ru-19.png","Weather-ru-20.png","Weather-ru-21.png","Weather-ru-22.png","Weather-ru-23.png","Weather-ru-24.png","Weather-ru-25.png","Weather-ru-0n.png","Weather-ru-1n.png","Weather-ru-3n.png"]
        let weather_text_uk	= ["Weather-uk-0.png","Weather-uk-1.png","Weather-uk-2.png","Weather-uk-3.png","Weather-uk-4.png","Weather-uk-5.png","Weather-uk-6.png","Weather-uk-.png","Weather-uk-8.png","Weather-uk-9.png","Weather-uk-10.png","Weather-uk-11.png","Weather-uk-.png","Weather-uk-13.png","Weather-uk-14.png","Weather-uk-15.png","Weather-uk-16.png","Weather-uk-17.png","Weather-uk-18.png","Weather-uk-19.png","Weather-uk-20.png","Weather-uk-21.png","Weather-uk-22.png","Weather-uk-23.png","Weather-uk-24.png","Weather-uk-25.png","Weather-uk-0n.png","Weather-uk-1n.png","Weather-uk-3n.png"]
        let weather_text_en = ["Weather-en-0.png","Weather-en-1.png","Weather-en-2.png","Weather-en-3.png","Weather-en-4.png","Weather-en-5.png","Weather-en-6.png","Weather-en-.png","Weather-en-8.png","Weather-en-9.png","Weather-en-10.png","Weather-en-11.png","Weather-en-.png","Weather-en-13.png","Weather-en-14.png","Weather-en-15.png","Weather-en-16.png","Weather-en-17.png","Weather-en-18.png","Weather-en-19.png","Weather-en-20.png","Weather-en-21.png","Weather-en-22.png","Weather-en-23.png","Weather-en-24.png","Weather-en-25.png","Weather-en-0n.png","Weather-en-1n.png","Weather-en-3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// sunrise time
        let sunsetMins_def = 20 * 60;			//and default sunset
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3];		// icon indexes for day-night replacement
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons) //Day Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_ru[wiReplacement[i]] = "Weather-ru-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_uk[wiReplacement[i]] = "Weather-uk-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG.png");
          }
          isDayIcons = true;}
		}
		else {
        if(isDayIcons) //Night Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_ru[wiReplacement[i]] = "Weather-ru-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_uk[wiReplacement[i]] = "Weather-uk-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG-n.png");
          }
          isDayIcons = false;}
		}
        }
        
// Autocorrect night weather icons End


// Click Zona Start
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2

		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
              if (zona1_num == 0) {		  
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_text_ru_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_uk_img_level.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = 'Connection Restored';
			con_lost = 'Connection Lost';
			AOD_Hollow = 'AOD Hollow Font';
			AOD_Solid = 'AOD Solid Font';
		    hmUI.showToast({		  		  
				text: 'English'
            });
          };
           if (zona1_num == 1) {		  
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_ru_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_text_uk_img_level.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = 'СОЕДИНЕНИЕ ВОССТАНОВЛЕНО';
			con_lost = 'СОЕДИНЕНИЕ ПОТЕРЯНО';
			AOD_Hollow = 'AOD Полый шрифт';
			AOD_Solid = 'AOD Сплошной шрифт';
		    hmUI.showToast({		  		  
				text: 'Русский'
            });
          };
           if (zona1_num == 2) {		  
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_ru_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_uk_img_level.setProperty(hmUI.prop.VISIBLE, true);
			con_rest = "З'ЄДНАННЯ ВІДНОВЛЕНО";
			con_lost = "ЗВ'ЯЗОК ВТРАЧЕНО";
			AOD_Hollow = 'AOD Порожнистий шрифт';
			AOD_Solid = 'AOD Суцільний шрифт';
		    hmUI.showToast({		  		  
				text: 'українська'
            });
          };
       }
// Click Zona End

//START AOD CHANGE

        let btn_aod = ''
		let curAODmode = 0;		// 0 - AOD Hollow Text
                                // 1 - AOD Solid Text

        let AODmodes = [AOD_Hollow, AOD_Solid];
        let AODmodeCaption;

        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = AOD_Hollow;
                    break;
                case 1:
                    AODmodeCaption = AOD_Solid;
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: AODmodeCaption });
        }

        function makeAOD() {

            let mode = hmFS.SysProGetInt('parkur_aod');
			
			if (mode == 0) {    // Hollow Text

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 49,
              src: 'Bat-lvl-AOD-0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 49,
              image_array: ["Bat-lvl-AOD-1.png","Bat-lvl-AOD-2.png","Bat-lvl-AOD-3.png","Bat-lvl-AOD-4.png","Bat-lvl-AOD-5.png","Bat-lvl-AOD-6.png","Bat-lvl-AOD-7.png","Bat-lvl-AOD-8.png","Bat-lvl-AOD-9.png","Bat-lvl-AOD-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 49,
              font_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png","BA6.png","BA7.png","BA8.png","BA9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-BA%.png',
              unit_tc: 'AOD-BA%.png',
              unit_en: 'AOD-BA%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 49,
              src: 'AOD-BA.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 170,
              am_sc_path: 'AOD-AM.png',
              am_en_path: 'AOD-AM.png',
              pm_x: 320,
              pm_y: 170,
              pm_sc_path: 'AOD-PM.png',
              pm_en_path: 'AOD-PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 89,
              hour_array: ["AOD-H0.png","AOD-H1.png","AOD-H2.png","AOD-H3.png","AOD-H4.png","AOD-H5.png","AOD-H6.png","AOD-H7.png","AOD-H8.png","AOD-H9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 229,
              minute_startY: 234,
              minute_array: ["AOD-M0.png","AOD-M1.png","AOD-M2.png","AOD-M3.png","AOD-M4.png","AOD-M5.png","AOD-M6.png","AOD-M7.png","AOD-M8.png","AOD-M9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 75,
              day_startY: 273,
              day_sc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_tc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_en_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 127,
              month_startY: 268,
              month_sc_array: aod_month,
              month_tc_array: aod_month,
              month_en_array: aod_month,
               month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 44,
              y: 312,
              week_en: aod_week,
              week_tc: aod_week,
              week_sc: aod_week,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Step.png',
              unit_tc: 'AOD-Step.png',
              unit_en: 'AOD-Step.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Heart.png',
              unit_tc: 'AOD-Heart.png',
              unit_en: 'AOD-Heart.png',
              invalid_image: 'Number--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_aod_mask_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD-Mask.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 210,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 336,
              y: 88,
              src: 'AOD-Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            }

			if (mode == 1) {    // Solid Text

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 49,
              src: 'Bat-lvl-AOD-0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 49,
              image_array: ["Bat-lvl-AOD-1.png","Bat-lvl-AOD-2.png","Bat-lvl-AOD-3.png","Bat-lvl-AOD-4.png","Bat-lvl-AOD-5.png","Bat-lvl-AOD-6.png","Bat-lvl-AOD-7.png","Bat-lvl-AOD-8.png","Bat-lvl-AOD-9.png","Bat-lvl-AOD-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 49,
              font_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png","BA6.png","BA7.png","BA8.png","BA9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-BA%.png',
              unit_tc: 'AOD-BA%.png',
              unit_en: 'AOD-BA%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 49,
              src: 'AOD-BA.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 170,
              am_sc_path: 'AOD-sc-AM.png',
              am_en_path: 'AOD-AM.png',
              pm_x: 320,
              pm_y: 170,
              pm_sc_path: 'AOD-sc-PM.png',
              pm_en_path: 'AOD-PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 89,
              hour_array: ["AOD-Solid-H0.png","AOD-Solid-H1.png","AOD-Solid-H2.png","AOD-Solid-H3.png","AOD-Solid-H4.png","AOD-Solid-H5.png","AOD-Solid-H6.png","AOD-Solid-H7.png","AOD-Solid-H8.png","AOD-Solid-H9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 229,
              minute_startY: 234,
              minute_array: ["AOD-Solid-M0.png","AOD-Solid-M1.png","AOD-Solid-M2.png","AOD-Solid-M3.png","AOD-Solid-M4.png","AOD-Solid-M5.png","AOD-Solid-M6.png","AOD-Solid-M7.png","AOD-Solid-M8.png","AOD-Solid-M9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 75,
              day_startY: 273,
              day_sc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_tc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_en_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 127,
              month_startY: 273,
              month_sc_array: aod_month,
              month_tc_array: aod_month,
              month_en_array: aod_month,
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 312,
              week_en: aod_week,
              week_tc: aod_week,
              week_sc: aod_week,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Step.png',
              unit_tc: 'AOD-Step.png',
              unit_en: 'AOD-Step.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Heart.png',
              unit_tc: 'AOD-Heart.png',
              unit_en: 'AOD-Heart.png',
              invalid_image: 'Number--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 210,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 336,
              y: 88,
              src: 'AOD-Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            }
         }

        function loadSettings() {
            if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                curAODmode = 1;
                hmFS.SysProSetInt('parkur_aod', curAODmode);
            } else {
                curAODmode = hmFS.SysProGetInt('parkur_aod');
            }
        }
//END AOD CHANGE


//dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
          init_view() {
  
//dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Day-2.png","Day-3.png","Day-4.png","Day-5.png","Day-6.png","Day-7.png","Day-8.png","Day-9.png","Day-10.png","Day-11.png","Day-12.png"],
              image_length: 11,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather2_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 227,
              image_array:  weather2_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_en_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_en,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             normal_weather_text_ru_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_ru,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_uk_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_uk,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 201,
              w: 234,
              h: 39,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_languege_change_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 70,
              src: 'Icon-Language.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 127,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp.png',
              unit_tc: 'Temp.png',
              unit_en: 'Temp.png',
              negative_image: 'Number--.png',
              invalid_image: 'Number--.png',
              align_h: hmUI.align.Left,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 130,
              src: 'Logo-Temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 167,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 167,
              src: 'Logo-BA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 225,
              src: 'Bat-lvl-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 225,
              image_array: ["Bat-lvl-1.png","Bat-lvl-2.png","Bat-lvl-3.png","Bat-lvl-4.png","Bat-lvl-5.png","Bat-lvl-6.png","Bat-lvl-7.png","Bat-lvl-8.png","Bat-lvl-9.png","Bat-lvl-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 83,
              hour_array: ["Time-H1-0.png","Time-H1-1.png","Time-H1-2.png","Time-H1-3.png","Time-H1-4.png","Time-H1-5.png","Time-H1-6.png","Time-H1-7.png","Time-H1-8.png","Time-H1-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 248,
              minute_startY: 224,
              minute_array: ["Time-M1-0.png","Time-M1-1.png","Time-M1-2.png","Time-M1-3.png","Time-M1-4.png","Time-M1-5.png","Time-M1-6.png","Time-M1-7.png","Time-M1-8.png","Time-M1-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 398,
              second_startY: 229,
              second_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 227,
              src: 'Time-Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 175,
              am_sc_path: 'Time-AM.png',
              am_en_path: 'Time-AM.png',
              pm_x: 395,
              pm_y: 175,
              pm_sc_path: 'Time-PM.png',
              pm_en_path: 'Time-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 253,
              day_startY: 38,
              day_sc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_tc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_en_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 48,
              month_sc_array: nor_month,
              month_tc_array: nor_month,
              month_en_array: nor_month,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,  //219,
              y: 39,
              week_en: nor_week,
              week_tc: nor_week,
              week_sc: nor_week,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 302,
              src: 'pai00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 302,
              image_array: ["pai01.png","pai02.png","pai03.png","pai04.png","pai05.png","pai06.png","pai07.png","pai08.png","pai09.png","pai10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_paiw_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 302,
              image_array: ["PaiW01.png","PaiW02.png","PaiW03.png","PaiW04.png","PaiW05.png","PaiW06.png","PaiW07.png","PaiW08.png","PaiW09.png","PaiW10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 317,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 248,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 248,
              src: 'Logo-Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 248,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 248,
              src: 'Logo-Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 288,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_en: 'Number-km.png',
              unit_sc: 'Number-km.png',
              unit_tc: 'Number-km.png',
              imperial_unit_en: 'Number-mi.png',
              imperial_unit_sc: 'Number-mi.png',
              imperial_unit_tc: 'Number-mi.png',
              dot_image: 'Number-..png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 288,
              src: 'Logo-Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 328,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 328,
              src: 'Logo-O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 368,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 368,
              src: 'Logo-Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 409,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 400,
              src: 'Logo-Stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
			normal_SLEEP_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 368,
              w: 59,
              h: 39,
              type: hmUI.data_type.SLEEP,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: "Number-..png", //小数点图片
              padding: true,
              isCharacter: false
           });

			normal_SLEEP_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
				x:360,
				y:368,
				src:"Logo-Sleep.png",
				show_level:hmUI.show_level.ONLY_NORMAL
				}),

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 104,
              src: 'Statuses-Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 141,
              src: 'Statuses-Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 279,
              src: 'Statuses-DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 316,
              src: 'Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


// Zona ShortCut Start
            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50, 
              y: 70, 
              text: '',
              w: 51, 
              h: 51, 
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
                click_zona1();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_ru_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_uk_img_level.setProperty(hmUI.prop.VISIBLE, false);


// Zona ShortCut End


            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,(0=Medium,9=Long,25=Short,27=Long Continuous),
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: con_lost});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: con_rest});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function


//Shortcut Jumable start
  
//START Battery Shortcut            
           normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 117,
              w: 88,
              h: 44,
              src: 'shortcut.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 161,
              w: 88,
              h: 44,
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'Settings_batteryManagerScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

//START Sport List Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 100,
				 y: 0,  
				 w: 118,     
				 h: 100,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'SportListScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 117,
              w: 118,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START World Clock Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 0,
				 y: 205,  
				 w: 244,     
				 h: 41,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'WorldClockScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 246,
              w: 244,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 285,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 325,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 365,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 298,
              w: 68,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 405,
              w: 175,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START Workout History Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 216,
				 y: 34,  
				 w: 39,     
				 h: 170,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'SportRecordListScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

 //START Calendar Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 34,
              w: 141,
              h: 49,
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 90,
              w: 130,
              h: 134,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 224,
              w: 130,
              h: 134,
              src: 'shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 136,
              w: 97,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 224,
              w: 97,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 366,
              w: 107,
              h: 78,
              src: 'shortcut.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//Shortcut Jumpable end


//START AOD Button
			btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 258,
              y: 195,
              text: '',
              w: 132,
              h: 58,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
                toggleAODmode();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btn_aod.setProperty(hmUI.prop.VISIBLE, true);
//END AOD Button

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
				autoToggleWeatherIcons(); // Night Weather Icon
                checkConnection(); // DisconnectAlert
                stopVibro();
               }),
               pause_call: (function () { // DisconnectAlert
                stopVibro(); // DisconnectAlert

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
				const currentScreenType = hmSetting.getScreenType();
                switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}		
