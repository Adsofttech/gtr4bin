﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_stand_icon_img = ''
        let editableZone_1_step_circle_scale = null;
        let editableZone_1_calorie_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_pai_circle_scale = null;
        let editableZone_1_fat_burning_circle_scale = null;
        let editableZone_1_battery_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editableZone_2_battery_circle_scale = null;
        let editableZone_2_pai_circle_scale = null;
        let editableZone_2_fat_burning_circle_scale = null;
        let editableZone_2_heart_rate_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editableZone_3_pai_circle_scale = null;
        let editableZone_3_fat_burning_circle_scale = null;
        let editableZone_3_battery_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 390,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 390,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 42,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 390,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 75,
              month_sc_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_tc_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_en_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 75,
              day_sc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_tc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_en_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 360,
              week_en: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              week_tc: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              week_sc: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 110,
              hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 150,
              minute_startY: 238,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 390,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 390,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 42,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 390,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 75,
              month_sc_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_tc_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_en_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 75,
              day_sc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_tc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_en_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 360,
              week_en: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              week_tc: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              week_sc: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 110,
              hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 150,
              minute_startY: 238,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();            
            const step = hmSensor.createSensor(hmSensor.id.STEP);

                        
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

                        
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);

                        
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

                        
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);

                        
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 202,
              y: 402,
              w: 67,
              h: 67,
              select_image: '0076.png',
              un_select_image: '0077.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0096.png' },
                { type: hmUI.edit_type.CAL, preview: '0102.png' },
                { type: hmUI.edit_type.HEART, preview: '0101.png' },
                { type: hmUI.edit_type.PAI, preview: '0095.png' },
                { type: 1300002, preview: '0100.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.BATTERY, preview: '0099.png' },
              ],
              count: 6,
              tips_BG: '0086.png',
              tips_x: -32,
              tips_y: -47,
              tips_width: 129,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 208,
                  y: 415,
                  src: '0099.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 210,
                  y: 415,
                  src: '0096.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 210,
                  y: 415,
                  src: '0102.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 208,
                  y: 415,
                  src: '0101.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 208,
                  y: 415,
                  src: '0095.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 415,
              src: '0100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 231,
                  // center_y: 234,
                  // start_angle: -167,
                  // end_angle: -73,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF0080C0,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.FAT_BURNING,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;
            }; // end switch

            
            
            
            
            
            
            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 375,
              y: 100,
              w: 67,
              h: 67,
              select_image: '0076.png',
              un_select_image: '0077.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0080.png' },
                { type: hmUI.edit_type.CAL, preview: '0085.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0078.png' },
                { type: hmUI.edit_type.PAI, preview: '0079.png' },
                { type: 1300002, preview: '0083.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.HEART, preview: '0084.png' },
              ],
              count: 6,
              tips_BG: '0086.png',
              tips_x: -81,
              tips_y: 65,
              tips_width: 129,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 385,
                  y: 110,
                  src: '0078.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 380,
                  y: 110,
                  src: '0080.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 385,
                  y: 107,
                  src: '0085.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 385,
                  y: 110,
                  src: '0084.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 385,
                  y: 110,
                  src: '0079.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 385,
              y: 110,
              src: '0083.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 234,
                  // center_y: 233,
                  // start_angle: 73,
                  // end_angle: 167,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFF80FF00,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.FAT_BURNING,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;
            }; // end switch

            
            
            
            
            
            
            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 29,
              y: 100,
              w: 67,
              h: 67,
              select_image: '0076.png',
              un_select_image: '0077.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0087.png' },
                { type: hmUI.edit_type.CAL, preview: '0094.png' },
                { type: hmUI.edit_type.PAI, preview: '0088.png' },
                { type: 1300002, preview: '0092.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.BATTERY, preview: '0091.png' },
                { type: hmUI.edit_type.HEART, preview: '0093.png' },
              ],
              count: 6,
              tips_BG: '0086.png',
              tips_x: 48,
              tips_y: 55,
              tips_width: 129,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 29,
                  y: 103,
                  src: '0091.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFDB0000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 29,
                  y: 103,
                  src: '0087.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFD90000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 29,
                  y: 103,
                  src: '0094.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFDB0000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 29,
                  y: 103,
                  src: '0093.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFDB0000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 29,
                  y: 103,
                  src: '0088.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFDB0000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 103,
              src: '0092.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 233,
                  // center_y: 230,
                  // start_angle: -48,
                  // end_angle: 48,
                  // radius: 217,
                  // line_width: 22,
                  // color: 0xFFDB0000,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.FAT_BURNING,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0104.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0103.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            function scale_call() {

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_step = -257;
                  let end_angle_editableZone_1_step = -163;
                  let center_x_editableZone_1_step = 231;
                  let center_y_editableZone_1_step = 234;
                  let radius_editableZone_1_step = 217;
                  let line_width_cs_editableZone_1_step = 22;
                  let color_cs_editableZone_1_step = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_step = center_x_editableZone_1_step - radius_editableZone_1_step;
                  let arcY_editableZone_1_step = center_y_editableZone_1_step - radius_editableZone_1_step;
                  let CircleWidth_editableZone_1_step = 2 * radius_editableZone_1_step;
                  let angle_offset_editableZone_1_step = end_angle_editableZone_1_step - start_angle_editableZone_1_step;
                  angle_offset_editableZone_1_step = angle_offset_editableZone_1_step * progress_cs_editableZone_1_step;
                  let end_angle_editableZone_1_step_draw = start_angle_editableZone_1_step + angle_offset_editableZone_1_step;
                  
                  editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_step,
                    y: arcY_editableZone_1_step,
                    w: CircleWidth_editableZone_1_step,
                    h: CircleWidth_editableZone_1_step,
                    start_angle: start_angle_editableZone_1_step,
                    end_angle: end_angle_editableZone_1_step_draw,
                    color: color_cs_editableZone_1_step,
                    line_width: line_width_cs_editableZone_1_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_1_calorie = progressCalories;

                if (editableZone_1_calorie_circle_scale) {

                  // editableZone_1_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_calorie = -257;
                  let end_angle_editableZone_1_calorie = -163;
                  let center_x_editableZone_1_calorie = 231;
                  let center_y_editableZone_1_calorie = 234;
                  let radius_editableZone_1_calorie = 217;
                  let line_width_cs_editableZone_1_calorie = 22;
                  let color_cs_editableZone_1_calorie = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_calorie = center_x_editableZone_1_calorie - radius_editableZone_1_calorie;
                  let arcY_editableZone_1_calorie = center_y_editableZone_1_calorie - radius_editableZone_1_calorie;
                  let CircleWidth_editableZone_1_calorie = 2 * radius_editableZone_1_calorie;
                  let angle_offset_editableZone_1_calorie = end_angle_editableZone_1_calorie - start_angle_editableZone_1_calorie;
                  angle_offset_editableZone_1_calorie = angle_offset_editableZone_1_calorie * progress_cs_editableZone_1_calorie;
                  let end_angle_editableZone_1_calorie_draw = start_angle_editableZone_1_calorie + angle_offset_editableZone_1_calorie;
                  
                  editableZone_1_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_calorie,
                    y: arcY_editableZone_1_calorie,
                    w: CircleWidth_editableZone_1_calorie,
                    h: CircleWidth_editableZone_1_calorie,
                    start_angle: start_angle_editableZone_1_calorie,
                    end_angle: end_angle_editableZone_1_calorie_draw,
                    color: color_cs_editableZone_1_calorie,
                    line_width: line_width_cs_editableZone_1_calorie,
                  });
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_heart_rate = -257;
                  let end_angle_editableZone_1_heart_rate = -163;
                  let center_x_editableZone_1_heart_rate = 231;
                  let center_y_editableZone_1_heart_rate = 234;
                  let radius_editableZone_1_heart_rate = 217;
                  let line_width_cs_editableZone_1_heart_rate = 22;
                  let color_cs_editableZone_1_heart_rate = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_heart_rate = center_x_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let arcY_editableZone_1_heart_rate = center_y_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let CircleWidth_editableZone_1_heart_rate = 2 * radius_editableZone_1_heart_rate;
                  let angle_offset_editableZone_1_heart_rate = end_angle_editableZone_1_heart_rate - start_angle_editableZone_1_heart_rate;
                  angle_offset_editableZone_1_heart_rate = angle_offset_editableZone_1_heart_rate * progress_cs_editableZone_1_heart_rate;
                  let end_angle_editableZone_1_heart_rate_draw = start_angle_editableZone_1_heart_rate + angle_offset_editableZone_1_heart_rate;
                  
                  editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_heart_rate,
                    y: arcY_editableZone_1_heart_rate,
                    w: CircleWidth_editableZone_1_heart_rate,
                    h: CircleWidth_editableZone_1_heart_rate,
                    start_angle: start_angle_editableZone_1_heart_rate,
                    end_angle: end_angle_editableZone_1_heart_rate_draw,
                    color: color_cs_editableZone_1_heart_rate,
                    line_width: line_width_cs_editableZone_1_heart_rate,
                  });
                };

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_1_pai = progressPAI;

                if (editableZone_1_pai_circle_scale) {

                  // editableZone_1_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_pai = -257;
                  let end_angle_editableZone_1_pai = -163;
                  let center_x_editableZone_1_pai = 231;
                  let center_y_editableZone_1_pai = 234;
                  let radius_editableZone_1_pai = 217;
                  let line_width_cs_editableZone_1_pai = 22;
                  let color_cs_editableZone_1_pai = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_pai = center_x_editableZone_1_pai - radius_editableZone_1_pai;
                  let arcY_editableZone_1_pai = center_y_editableZone_1_pai - radius_editableZone_1_pai;
                  let CircleWidth_editableZone_1_pai = 2 * radius_editableZone_1_pai;
                  let angle_offset_editableZone_1_pai = end_angle_editableZone_1_pai - start_angle_editableZone_1_pai;
                  angle_offset_editableZone_1_pai = angle_offset_editableZone_1_pai * progress_cs_editableZone_1_pai;
                  let end_angle_editableZone_1_pai_draw = start_angle_editableZone_1_pai + angle_offset_editableZone_1_pai;
                  
                  editableZone_1_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_pai,
                    y: arcY_editableZone_1_pai,
                    w: CircleWidth_editableZone_1_pai,
                    h: CircleWidth_editableZone_1_pai,
                    start_angle: start_angle_editableZone_1_pai,
                    end_angle: end_angle_editableZone_1_pai_draw,
                    color: color_cs_editableZone_1_pai,
                    line_width: line_width_cs_editableZone_1_pai,
                  });
                };

                console.log('update editable circle_scale FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_editableZone_1_fat_burning = progressFatBurning;

                if (editableZone_1_fat_burning_circle_scale) {

                  // editableZone_1_fat_burning_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_fat_burning = -257;
                  let end_angle_editableZone_1_fat_burning = -163;
                  let center_x_editableZone_1_fat_burning = 231;
                  let center_y_editableZone_1_fat_burning = 234;
                  let radius_editableZone_1_fat_burning = 217;
                  let line_width_cs_editableZone_1_fat_burning = 22;
                  let color_cs_editableZone_1_fat_burning = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_fat_burning = center_x_editableZone_1_fat_burning - radius_editableZone_1_fat_burning;
                  let arcY_editableZone_1_fat_burning = center_y_editableZone_1_fat_burning - radius_editableZone_1_fat_burning;
                  let CircleWidth_editableZone_1_fat_burning = 2 * radius_editableZone_1_fat_burning;
                  let angle_offset_editableZone_1_fat_burning = end_angle_editableZone_1_fat_burning - start_angle_editableZone_1_fat_burning;
                  angle_offset_editableZone_1_fat_burning = angle_offset_editableZone_1_fat_burning * progress_cs_editableZone_1_fat_burning;
                  let end_angle_editableZone_1_fat_burning_draw = start_angle_editableZone_1_fat_burning + angle_offset_editableZone_1_fat_burning;
                  
                  editableZone_1_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_fat_burning,
                    y: arcY_editableZone_1_fat_burning,
                    w: CircleWidth_editableZone_1_fat_burning,
                    h: CircleWidth_editableZone_1_fat_burning,
                    start_angle: start_angle_editableZone_1_fat_burning,
                    end_angle: end_angle_editableZone_1_fat_burning_draw,
                    color: color_cs_editableZone_1_fat_burning,
                    line_width: line_width_cs_editableZone_1_fat_burning,
                  });
                };

                console.log('update editable circle_scale BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_editableZone_1_battery = progressBattery;

                if (editableZone_1_battery_circle_scale) {

                  // editableZone_1_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_battery = -257;
                  let end_angle_editableZone_1_battery = -163;
                  let center_x_editableZone_1_battery = 231;
                  let center_y_editableZone_1_battery = 234;
                  let radius_editableZone_1_battery = 217;
                  let line_width_cs_editableZone_1_battery = 22;
                  let color_cs_editableZone_1_battery = 0xFF0080C0;
                  
                  // calculated parameters
                  let arcX_editableZone_1_battery = center_x_editableZone_1_battery - radius_editableZone_1_battery;
                  let arcY_editableZone_1_battery = center_y_editableZone_1_battery - radius_editableZone_1_battery;
                  let CircleWidth_editableZone_1_battery = 2 * radius_editableZone_1_battery;
                  let angle_offset_editableZone_1_battery = end_angle_editableZone_1_battery - start_angle_editableZone_1_battery;
                  angle_offset_editableZone_1_battery = angle_offset_editableZone_1_battery * progress_cs_editableZone_1_battery;
                  let end_angle_editableZone_1_battery_draw = start_angle_editableZone_1_battery + angle_offset_editableZone_1_battery;
                  
                  editableZone_1_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_battery,
                    y: arcY_editableZone_1_battery,
                    w: CircleWidth_editableZone_1_battery,
                    h: CircleWidth_editableZone_1_battery,
                    start_angle: start_angle_editableZone_1_battery,
                    end_angle: end_angle_editableZone_1_battery_draw,
                    color: color_cs_editableZone_1_battery,
                    line_width: line_width_cs_editableZone_1_battery,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_step = -17;
                  let end_angle_editableZone_2_step = 77;
                  let center_x_editableZone_2_step = 234;
                  let center_y_editableZone_2_step = 233;
                  let radius_editableZone_2_step = 217;
                  let line_width_cs_editableZone_2_step = 22;
                  let color_cs_editableZone_2_step = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_step = center_x_editableZone_2_step - radius_editableZone_2_step;
                  let arcY_editableZone_2_step = center_y_editableZone_2_step - radius_editableZone_2_step;
                  let CircleWidth_editableZone_2_step = 2 * radius_editableZone_2_step;
                  let angle_offset_editableZone_2_step = end_angle_editableZone_2_step - start_angle_editableZone_2_step;
                  angle_offset_editableZone_2_step = angle_offset_editableZone_2_step * progress_cs_editableZone_2_step;
                  let end_angle_editableZone_2_step_draw = start_angle_editableZone_2_step + angle_offset_editableZone_2_step;
                  
                  editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_step,
                    y: arcY_editableZone_2_step,
                    w: CircleWidth_editableZone_2_step,
                    h: CircleWidth_editableZone_2_step,
                    start_angle: start_angle_editableZone_2_step,
                    end_angle: end_angle_editableZone_2_step_draw,
                    color: color_cs_editableZone_2_step,
                    line_width: line_width_cs_editableZone_2_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_2_calorie = progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_calorie = -17;
                  let end_angle_editableZone_2_calorie = 77;
                  let center_x_editableZone_2_calorie = 234;
                  let center_y_editableZone_2_calorie = 233;
                  let radius_editableZone_2_calorie = 217;
                  let line_width_cs_editableZone_2_calorie = 22;
                  let color_cs_editableZone_2_calorie = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_calorie = center_x_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let arcY_editableZone_2_calorie = center_y_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let CircleWidth_editableZone_2_calorie = 2 * radius_editableZone_2_calorie;
                  let angle_offset_editableZone_2_calorie = end_angle_editableZone_2_calorie - start_angle_editableZone_2_calorie;
                  angle_offset_editableZone_2_calorie = angle_offset_editableZone_2_calorie * progress_cs_editableZone_2_calorie;
                  let end_angle_editableZone_2_calorie_draw = start_angle_editableZone_2_calorie + angle_offset_editableZone_2_calorie;
                  
                  editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_calorie,
                    y: arcY_editableZone_2_calorie,
                    w: CircleWidth_editableZone_2_calorie,
                    h: CircleWidth_editableZone_2_calorie,
                    start_angle: start_angle_editableZone_2_calorie,
                    end_angle: end_angle_editableZone_2_calorie_draw,
                    color: color_cs_editableZone_2_calorie,
                    line_width: line_width_cs_editableZone_2_calorie,
                  });
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_2_battery = progressBattery;

                if (editableZone_2_battery_circle_scale) {

                  // editableZone_2_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_battery = -17;
                  let end_angle_editableZone_2_battery = 77;
                  let center_x_editableZone_2_battery = 234;
                  let center_y_editableZone_2_battery = 233;
                  let radius_editableZone_2_battery = 217;
                  let line_width_cs_editableZone_2_battery = 22;
                  let color_cs_editableZone_2_battery = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_battery = center_x_editableZone_2_battery - radius_editableZone_2_battery;
                  let arcY_editableZone_2_battery = center_y_editableZone_2_battery - radius_editableZone_2_battery;
                  let CircleWidth_editableZone_2_battery = 2 * radius_editableZone_2_battery;
                  let angle_offset_editableZone_2_battery = end_angle_editableZone_2_battery - start_angle_editableZone_2_battery;
                  angle_offset_editableZone_2_battery = angle_offset_editableZone_2_battery * progress_cs_editableZone_2_battery;
                  let end_angle_editableZone_2_battery_draw = start_angle_editableZone_2_battery + angle_offset_editableZone_2_battery;
                  
                  editableZone_2_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_battery,
                    y: arcY_editableZone_2_battery,
                    w: CircleWidth_editableZone_2_battery,
                    h: CircleWidth_editableZone_2_battery,
                    start_angle: start_angle_editableZone_2_battery,
                    end_angle: end_angle_editableZone_2_battery_draw,
                    color: color_cs_editableZone_2_battery,
                    line_width: line_width_cs_editableZone_2_battery,
                  });
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_2_pai = progressPAI;

                if (editableZone_2_pai_circle_scale) {

                  // editableZone_2_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_pai = -17;
                  let end_angle_editableZone_2_pai = 77;
                  let center_x_editableZone_2_pai = 234;
                  let center_y_editableZone_2_pai = 233;
                  let radius_editableZone_2_pai = 217;
                  let line_width_cs_editableZone_2_pai = 22;
                  let color_cs_editableZone_2_pai = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_pai = center_x_editableZone_2_pai - radius_editableZone_2_pai;
                  let arcY_editableZone_2_pai = center_y_editableZone_2_pai - radius_editableZone_2_pai;
                  let CircleWidth_editableZone_2_pai = 2 * radius_editableZone_2_pai;
                  let angle_offset_editableZone_2_pai = end_angle_editableZone_2_pai - start_angle_editableZone_2_pai;
                  angle_offset_editableZone_2_pai = angle_offset_editableZone_2_pai * progress_cs_editableZone_2_pai;
                  let end_angle_editableZone_2_pai_draw = start_angle_editableZone_2_pai + angle_offset_editableZone_2_pai;
                  
                  editableZone_2_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_pai,
                    y: arcY_editableZone_2_pai,
                    w: CircleWidth_editableZone_2_pai,
                    h: CircleWidth_editableZone_2_pai,
                    start_angle: start_angle_editableZone_2_pai,
                    end_angle: end_angle_editableZone_2_pai_draw,
                    color: color_cs_editableZone_2_pai,
                    line_width: line_width_cs_editableZone_2_pai,
                  });
                };

                console.log('update editable circle_scale FAT_BURNING');
                let progress_cs_editableZone_2_fat_burning = progressFatBurning;

                if (editableZone_2_fat_burning_circle_scale) {

                  // editableZone_2_fat_burning_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_fat_burning = -17;
                  let end_angle_editableZone_2_fat_burning = 77;
                  let center_x_editableZone_2_fat_burning = 234;
                  let center_y_editableZone_2_fat_burning = 233;
                  let radius_editableZone_2_fat_burning = 217;
                  let line_width_cs_editableZone_2_fat_burning = 22;
                  let color_cs_editableZone_2_fat_burning = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_fat_burning = center_x_editableZone_2_fat_burning - radius_editableZone_2_fat_burning;
                  let arcY_editableZone_2_fat_burning = center_y_editableZone_2_fat_burning - radius_editableZone_2_fat_burning;
                  let CircleWidth_editableZone_2_fat_burning = 2 * radius_editableZone_2_fat_burning;
                  let angle_offset_editableZone_2_fat_burning = end_angle_editableZone_2_fat_burning - start_angle_editableZone_2_fat_burning;
                  angle_offset_editableZone_2_fat_burning = angle_offset_editableZone_2_fat_burning * progress_cs_editableZone_2_fat_burning;
                  let end_angle_editableZone_2_fat_burning_draw = start_angle_editableZone_2_fat_burning + angle_offset_editableZone_2_fat_burning;
                  
                  editableZone_2_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_fat_burning,
                    y: arcY_editableZone_2_fat_burning,
                    w: CircleWidth_editableZone_2_fat_burning,
                    h: CircleWidth_editableZone_2_fat_burning,
                    start_angle: start_angle_editableZone_2_fat_burning,
                    end_angle: end_angle_editableZone_2_fat_burning_draw,
                    color: color_cs_editableZone_2_fat_burning,
                    line_width: line_width_cs_editableZone_2_fat_burning,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_heart_rate = -17;
                  let end_angle_editableZone_2_heart_rate = 77;
                  let center_x_editableZone_2_heart_rate = 234;
                  let center_y_editableZone_2_heart_rate = 233;
                  let radius_editableZone_2_heart_rate = 217;
                  let line_width_cs_editableZone_2_heart_rate = 22;
                  let color_cs_editableZone_2_heart_rate = 0xFF80FF00;
                  
                  // calculated parameters
                  let arcX_editableZone_2_heart_rate = center_x_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let arcY_editableZone_2_heart_rate = center_y_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let CircleWidth_editableZone_2_heart_rate = 2 * radius_editableZone_2_heart_rate;
                  let angle_offset_editableZone_2_heart_rate = end_angle_editableZone_2_heart_rate - start_angle_editableZone_2_heart_rate;
                  angle_offset_editableZone_2_heart_rate = angle_offset_editableZone_2_heart_rate * progress_cs_editableZone_2_heart_rate;
                  let end_angle_editableZone_2_heart_rate_draw = start_angle_editableZone_2_heart_rate + angle_offset_editableZone_2_heart_rate;
                  
                  editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_heart_rate,
                    y: arcY_editableZone_2_heart_rate,
                    w: CircleWidth_editableZone_2_heart_rate,
                    h: CircleWidth_editableZone_2_heart_rate,
                    start_angle: start_angle_editableZone_2_heart_rate,
                    end_angle: end_angle_editableZone_2_heart_rate_draw,
                    color: color_cs_editableZone_2_heart_rate,
                    line_width: line_width_cs_editableZone_2_heart_rate,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_step = -138;
                  let end_angle_editableZone_3_step = -42;
                  let center_x_editableZone_3_step = 233;
                  let center_y_editableZone_3_step = 230;
                  let radius_editableZone_3_step = 217;
                  let line_width_cs_editableZone_3_step = 22;
                  let color_cs_editableZone_3_step = 0xFFD90000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_step = center_x_editableZone_3_step - radius_editableZone_3_step;
                  let arcY_editableZone_3_step = center_y_editableZone_3_step - radius_editableZone_3_step;
                  let CircleWidth_editableZone_3_step = 2 * radius_editableZone_3_step;
                  let angle_offset_editableZone_3_step = end_angle_editableZone_3_step - start_angle_editableZone_3_step;
                  angle_offset_editableZone_3_step = angle_offset_editableZone_3_step * progress_cs_editableZone_3_step;
                  let end_angle_editableZone_3_step_draw = start_angle_editableZone_3_step + angle_offset_editableZone_3_step;
                  
                  editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_step,
                    y: arcY_editableZone_3_step,
                    w: CircleWidth_editableZone_3_step,
                    h: CircleWidth_editableZone_3_step,
                    start_angle: start_angle_editableZone_3_step,
                    end_angle: end_angle_editableZone_3_step_draw,
                    color: color_cs_editableZone_3_step,
                    line_width: line_width_cs_editableZone_3_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_calorie = -138;
                  let end_angle_editableZone_3_calorie = -42;
                  let center_x_editableZone_3_calorie = 233;
                  let center_y_editableZone_3_calorie = 230;
                  let radius_editableZone_3_calorie = 217;
                  let line_width_cs_editableZone_3_calorie = 22;
                  let color_cs_editableZone_3_calorie = 0xFFDB0000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_calorie = center_x_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let arcY_editableZone_3_calorie = center_y_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let CircleWidth_editableZone_3_calorie = 2 * radius_editableZone_3_calorie;
                  let angle_offset_editableZone_3_calorie = end_angle_editableZone_3_calorie - start_angle_editableZone_3_calorie;
                  angle_offset_editableZone_3_calorie = angle_offset_editableZone_3_calorie * progress_cs_editableZone_3_calorie;
                  let end_angle_editableZone_3_calorie_draw = start_angle_editableZone_3_calorie + angle_offset_editableZone_3_calorie;
                  
                  editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_calorie,
                    y: arcY_editableZone_3_calorie,
                    w: CircleWidth_editableZone_3_calorie,
                    h: CircleWidth_editableZone_3_calorie,
                    start_angle: start_angle_editableZone_3_calorie,
                    end_angle: end_angle_editableZone_3_calorie_draw,
                    color: color_cs_editableZone_3_calorie,
                    line_width: line_width_cs_editableZone_3_calorie,
                  });
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_3_pai = progressPAI;

                if (editableZone_3_pai_circle_scale) {

                  // editableZone_3_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_pai = -138;
                  let end_angle_editableZone_3_pai = -42;
                  let center_x_editableZone_3_pai = 233;
                  let center_y_editableZone_3_pai = 230;
                  let radius_editableZone_3_pai = 217;
                  let line_width_cs_editableZone_3_pai = 22;
                  let color_cs_editableZone_3_pai = 0xFFDB0000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_pai = center_x_editableZone_3_pai - radius_editableZone_3_pai;
                  let arcY_editableZone_3_pai = center_y_editableZone_3_pai - radius_editableZone_3_pai;
                  let CircleWidth_editableZone_3_pai = 2 * radius_editableZone_3_pai;
                  let angle_offset_editableZone_3_pai = end_angle_editableZone_3_pai - start_angle_editableZone_3_pai;
                  angle_offset_editableZone_3_pai = angle_offset_editableZone_3_pai * progress_cs_editableZone_3_pai;
                  let end_angle_editableZone_3_pai_draw = start_angle_editableZone_3_pai + angle_offset_editableZone_3_pai;
                  
                  editableZone_3_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_pai,
                    y: arcY_editableZone_3_pai,
                    w: CircleWidth_editableZone_3_pai,
                    h: CircleWidth_editableZone_3_pai,
                    start_angle: start_angle_editableZone_3_pai,
                    end_angle: end_angle_editableZone_3_pai_draw,
                    color: color_cs_editableZone_3_pai,
                    line_width: line_width_cs_editableZone_3_pai,
                  });
                };

                console.log('update editable circle_scale FAT_BURNING');
                let progress_cs_editableZone_3_fat_burning = progressFatBurning;

                if (editableZone_3_fat_burning_circle_scale) {

                  // editableZone_3_fat_burning_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_fat_burning = -138;
                  let end_angle_editableZone_3_fat_burning = -42;
                  let center_x_editableZone_3_fat_burning = 233;
                  let center_y_editableZone_3_fat_burning = 230;
                  let radius_editableZone_3_fat_burning = 217;
                  let line_width_cs_editableZone_3_fat_burning = 22;
                  let color_cs_editableZone_3_fat_burning = 0xFFDB0000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_fat_burning = center_x_editableZone_3_fat_burning - radius_editableZone_3_fat_burning;
                  let arcY_editableZone_3_fat_burning = center_y_editableZone_3_fat_burning - radius_editableZone_3_fat_burning;
                  let CircleWidth_editableZone_3_fat_burning = 2 * radius_editableZone_3_fat_burning;
                  let angle_offset_editableZone_3_fat_burning = end_angle_editableZone_3_fat_burning - start_angle_editableZone_3_fat_burning;
                  angle_offset_editableZone_3_fat_burning = angle_offset_editableZone_3_fat_burning * progress_cs_editableZone_3_fat_burning;
                  let end_angle_editableZone_3_fat_burning_draw = start_angle_editableZone_3_fat_burning + angle_offset_editableZone_3_fat_burning;
                  
                  editableZone_3_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_fat_burning,
                    y: arcY_editableZone_3_fat_burning,
                    w: CircleWidth_editableZone_3_fat_burning,
                    h: CircleWidth_editableZone_3_fat_burning,
                    start_angle: start_angle_editableZone_3_fat_burning,
                    end_angle: end_angle_editableZone_3_fat_burning_draw,
                    color: color_cs_editableZone_3_fat_burning,
                    line_width: line_width_cs_editableZone_3_fat_burning,
                  });
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_3_battery = progressBattery;

                if (editableZone_3_battery_circle_scale) {

                  // editableZone_3_battery_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_battery = -138;
                  let end_angle_editableZone_3_battery = -42;
                  let center_x_editableZone_3_battery = 233;
                  let center_y_editableZone_3_battery = 230;
                  let radius_editableZone_3_battery = 217;
                  let line_width_cs_editableZone_3_battery = 22;
                  let color_cs_editableZone_3_battery = 0xFFDB0000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_battery = center_x_editableZone_3_battery - radius_editableZone_3_battery;
                  let arcY_editableZone_3_battery = center_y_editableZone_3_battery - radius_editableZone_3_battery;
                  let CircleWidth_editableZone_3_battery = 2 * radius_editableZone_3_battery;
                  let angle_offset_editableZone_3_battery = end_angle_editableZone_3_battery - start_angle_editableZone_3_battery;
                  angle_offset_editableZone_3_battery = angle_offset_editableZone_3_battery * progress_cs_editableZone_3_battery;
                  let end_angle_editableZone_3_battery_draw = start_angle_editableZone_3_battery + angle_offset_editableZone_3_battery;
                  
                  editableZone_3_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_battery,
                    y: arcY_editableZone_3_battery,
                    w: CircleWidth_editableZone_3_battery,
                    h: CircleWidth_editableZone_3_battery,
                    start_angle: start_angle_editableZone_3_battery,
                    end_angle: end_angle_editableZone_3_battery_draw,
                    color: color_cs_editableZone_3_battery,
                    line_width: line_width_cs_editableZone_3_battery,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_heart_rate = -138;
                  let end_angle_editableZone_3_heart_rate = -42;
                  let center_x_editableZone_3_heart_rate = 233;
                  let center_y_editableZone_3_heart_rate = 230;
                  let radius_editableZone_3_heart_rate = 217;
                  let line_width_cs_editableZone_3_heart_rate = 22;
                  let color_cs_editableZone_3_heart_rate = 0xFFDB0000;
                  
                  // calculated parameters
                  let arcX_editableZone_3_heart_rate = center_x_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let arcY_editableZone_3_heart_rate = center_y_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let CircleWidth_editableZone_3_heart_rate = 2 * radius_editableZone_3_heart_rate;
                  let angle_offset_editableZone_3_heart_rate = end_angle_editableZone_3_heart_rate - start_angle_editableZone_3_heart_rate;
                  angle_offset_editableZone_3_heart_rate = angle_offset_editableZone_3_heart_rate * progress_cs_editableZone_3_heart_rate;
                  let end_angle_editableZone_3_heart_rate_draw = start_angle_editableZone_3_heart_rate + angle_offset_editableZone_3_heart_rate;
                  
                  editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_heart_rate,
                    y: arcY_editableZone_3_heart_rate,
                    w: CircleWidth_editableZone_3_heart_rate,
                    h: CircleWidth_editableZone_3_heart_rate,
                    start_angle: start_angle_editableZone_3_heart_rate,
                    end_angle: end_angle_editableZone_3_heart_rate_draw,
                    color: color_cs_editableZone_3_heart_rate,
                    line_width: line_width_cs_editableZone_3_heart_rate,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
              pause_call: (function () {
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
