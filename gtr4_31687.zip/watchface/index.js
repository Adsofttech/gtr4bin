﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 410,
              font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0029.png',
              unit_tc: '0029.png',
              unit_en: '0029.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 348,
              week_en: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png"],
              week_tc: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png"],
              week_sc: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 317,
              day_sc_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png"],
              day_tc_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png"],
              day_en_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 250,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 202,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0073.png',
              center_x: 351,
              center_y: 233,
              x: 14,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 250,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              dot_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 203,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0073.png',
              center_x: 125,
              center_y: 233,
              x: 17,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 87,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0141.png',
              unit_tc: '0141.png',
              unit_en: '0141.png',
              negative_image: '0140.png',
              invalid_image: '0142.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 87,
              font_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0141.png',
              unit_tc: '0141.png',
              unit_en: '0141.png',
              negative_image: '0140.png',
              invalid_image: '0142.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 166,
              font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0114.png',
              unit_tc: '0114.png',
              unit_en: '0114.png',
              negative_image: '0113.png',
              invalid_image: '0115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 47,
              image_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0143.png',
              hour_centerX: 234,
              hour_centerY: 233,
              hour_posX: 106,
              hour_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0144.png',
              minute_centerX: 234,
              minute_centerY: 233,
              minute_posX: 92,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0145.png',
              second_centerX: 234,
              second_centerY: 233,
              second_posX: 160,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0143.png',
              hour_centerX: 234,
              hour_centerY: 233,
              hour_posX: 106,
              hour_posY: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0144.png',
              minute_centerX: 234,
              minute_centerY: 233,
              minute_posX: 92,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0145.png',
              second_centerX: 234,
              second_centerY: 233,
              second_posX: 160,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 212,
              y: 209,
              w: 66,
              h: 66,
              src: '0147.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 66,
              w: 66,
              h: 66,
              src: '0147.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 175,
              w: 54,
              h: 47,
              src: '0147.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 179,
              w: 59,
              h: 47,
              src: '0147.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
