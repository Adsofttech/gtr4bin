/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_random_bg0 = '';
		let normal_random_bg0_array = ['0002.png','0003.png','0004.png','0005.png','0006.png'];
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let timeInterval;
		let normal_hour_high_imageset15 = '';
		let normal_hour_high_imageset15_array = ['0017.png','0018.png','0019.png'];
		let normal_hour_low_imageset16 = '';
		let normal_hour_low_imageset16_array = ['0020.png','0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png'];
		let normal_minute_high_imageset17 = '';
		let normal_minute_high_imageset17_array = ['0030.png','0031.png','0032.png','0033.png','0034.png','0035.png'];
		let normal_minute_low_imageset18 = '';
		let normal_minute_low_imageset18_array = ['0036.png','0037.png','0038.png','0039.png','0040.png','0041.png','0042.png','0043.png','0044.png','0045.png'];
		let normal_week_imageset20 = '';
		let normal_date_high_imageset21 = '';
		let normal_date_high_imageset21_array = ['0053.png','0054.png','0055.png','0056.png'];
		let normal_date_low_imageset22 = '';
		let normal_date_low_imageset22_array = ['0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0064.png','0065.png','0066.png'];
		let normal_month_imageset23 = '';
		let normal_temperature_current_imagecombo25 = '';
		let normal_img26 = '';
		let normal_humidity_imagecombo28 = '';
		let normal_img29 = '';
		let normal_battery_imagecombo31 = '';
		let normal_battery_imageset32 = '';
		let normal_steps_imagecombo34 = '';
		let normal_img35 = '';
		let normal_distance_imagecombo37 = '';
		let normal_img38 = '';
		let normal_heart_current_imagecombo40 = '';
		let normal_img41 = '';
		let normal_calories_imagecombo43 = '';
		let normal_img44 = '';
		let normal_alarm_status46 = '';
		let normal_bt_status47 = '';
		let normal_lock_status48 = '';
		let normal_random_bg_trigger50 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_random_bg0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -4,
					y: 231,
					w: 474,
					h: 5,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 132,
					y: 212,
					w: 200,
					h: 42,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 132,
					y: 423,
					w: 200,
					h: 45,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 132,
					y: -4,
					w: 200,
					h: 47,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 350,
					y: 154,
					w: 105,
					h: 5,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 350,
					y: 309,
					w: 105,
					h: 5,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 12,
					y: 309,
					w: 105,
					h: 5,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 11,
					y: 154,
					w: 105,
					h: 5,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 269,
					y: 432,
					w: 26,
					h: 36,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 167,
					y: 432,
					w: 26,
					h: 36,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 215,
					y: -2,
					w: 35,
					h: 40,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 275,
					y: 10,
					w: 18,
					h: 25,
					src: '0015.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 168,
					y: 10,
					w: 21,
					h: 25,
					src: '0016.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 133,
					y: 48,
					w: 133,
					h: 48,
					src: '0019.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 238,
					y: 48,
					w: 238,
					h: 48,
					src: '0029.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 133,
					y: 256,
					w: 133,
					h: 256,
					src: '0035.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 238,
					y: 256,
					w: 238,
					h: 256,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_week_imageset20 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 136,
					y: 216,
					week_en: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					week_tc: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					week_sc: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 368,
					y: 245,
					w: 368,
					h: 245,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 405,
					y: 245,
					w: 405,
					h: 245,
					src: '0066.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_month_imageset23 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 357,
					month_startY: 172,
					month_sc_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_tc_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_en_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 354,
					y: 116,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0090.png"],
					unit_tc: ["0090.png"],
					unit_en: ["0090.png"],
					negative_image: ["0089.png"],
					invalid_image: ["0089.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 374,
					y: 77,
					w: 24,
					h: 32,
					src: '0091.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_humidity_imagecombo28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 358,
					y: 321,
					font_array: ["0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 374,
					y: 361,
					w: 27,
					h: 31,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo31 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 196,
					y: 436,
					font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0113.png',
					unit_tc: '0113.png',
					unit_en: '0113.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset32 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 134,
					y: 425,
					image_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					image_length: 14,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 8,
					y: 190,
					font_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 48,
					y: 160,
					w: 29,
					h: 25,
					src: '0138.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo37 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 14,
					y: 240,
					font_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					padding: false,
					h_space: 0,
					dot_image: '0139.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 39,
					y: 273,
					w: 50,
					h: 40,
					src: '0140.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo40 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 46,
					y: 111,
					font_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0151.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 65,
					y: 78,
					w: 36,
					h: 30,
					src: '0152.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo43 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 35,
					y: 321,
					font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 67,
					y: 361,
					w: 30,
					h: 30,
					src: '0163.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status46 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 215,
					y: -2,
					w: 35,
					h: 40,
					type: hmUI.system_status.CLOCK,
					src: '0164.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status47 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 275,
					y: 10,
					w: 18,
					h: 25,
					type: hmUI.system_status.DISCONNECT,
					src: '0165.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_lock_status48 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 168,
					y: 10,
					w: 21,
					h: 25,
					type: hmUI.system_status.LOCK,
					src: '0166.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger50 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0167.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger50.addEventListener(hmUI.event.CLICK_DOWN, function() {
					normal_random_bg0.setProperty(hmUI.prop.SRC, normal_random_bg0_array[Math.floor(Math.random() * normal_random_bg0_array.length)])
				});

				function updateTime() {
					normal_hour_high_imageset15.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset15_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset16_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset17.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset17_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset18.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset18_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_date_high_imageset21.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset21_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset22.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset22_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}