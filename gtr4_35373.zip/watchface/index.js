﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */
    // import { Barometer } from '@zos/sensor'

    try {
     (() => {

      const {
       beforeModuleCreate = () => {}, afterModuleCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforeModuleCreate()

      const {
       beforePageCreate = () => {}, afterPageCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforePageCreate()
      const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__

       //dynamic modify start

       ! function (context) {
        with(context) {

         const hmUI = __$$R$$__('@zos/ui');
         const hmSensor = __$$R$$__('@zos/sensor');
         const hmScene = __$$R$$__('@zos/app');
         const hmRouter = __$$R$$__('@zos/router');
         const hmDevice = __$$R$$__('@zos/device');
         const hmBle = __$$R$$__('@zos/ble');
         const hmStorage = __$$R$$__('@zos/storage');

         const gettext = console.log;
         const barometer = new hmSensor.Barometer();
         const altitude = barometer.getAltitude();
         let airPressure = barometer.getAirPressure() * 0.750064;
         const {
          width: DEVICE_WIDTH,
          height: DEVICE_HEIGHT
         } = hmDevice.getDeviceInfo();


        // const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
         const battery = new hmSensor.Battery();
         const distance = new hmSensor.Distance();
         const calorie = new hmSensor.Calorie();
        const step = new hmSensor.Step();
            
        const heart = new hmSensor.HeartRate();
            
            
         const curTime = new hmSensor.Time();
         let MonthClok = curTime.getMonth();
			
         const weather = new hmSensor.Weather();
         let weatherData = weather.getForecast();
         let forecastData = weatherData.forecastData;

			
			


        let normal_background_bg_img = ''
        let normal_stand_circle_scale = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 19;
        let normal_heart_rate_TextCircle_img_height = 17;
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 19;
        let normal_battery_TextCircle_img_height = 17;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 33;
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 19;
        let normal_step_TextCircle_img_height = 17;
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_text_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 19;
        let normal_sunrise_TextCircle_img_height = 17;
        let normal_sunrise_TextCircle_dot_width = 4;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 19;
        let normal_sunset_TextCircle_img_height = 17;
        let normal_sunset_TextCircle_dot_width = 4;
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_uvi_text_text_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 19;
        let normal_calorie_TextCircle_img_height = 17;
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_current_text_img = ''
        let normal_high_TextCircle = new Array(4);
        let normal_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_high_TextCircle_img_width = 19;
        let normal_high_TextCircle_img_height = 17;
        let normal_high_TextCircle_unit = null;
        let normal_high_TextCircle_unit_width = 7;
        let normal_high_TextCircle_dot_width = 7;
        let normal_high_TextCircle_error_img_width = 19;
        let normal_low_TextCircle = new Array(4);
        let normal_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_low_TextCircle_img_width = 19;
        let normal_low_TextCircle_img_height = 17;
        let normal_low_TextCircle_unit = null;
        let normal_low_TextCircle_unit_width = 7;
        let normal_low_TextCircle_dot_width = 7;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
         



         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }


         let vibrate = new hmSensor.Vibrator();
         let stopVibro_Timer = null;


         function vibro(mode = 25) {
          let stopDelay = 25;
          vibrate.stop();
          //vibrate.setMode(mode);
          vibrate.start(mode);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
          stopVibro_Timer = setTimeout(() => {
           stopVibro();
          }, stopDelay);
         }

         function stopVibro() {
          vibrate.stop();
          //timer.stopTimer(stopVibro_Timer);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
         }


         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }


         //	---------------------------------------------------------		

         //переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
         let weatherTxtImgArray = []
         let weatherTxtImgArrayN = []
         let pointred = new Array(6);
         let pointblue = new Array(5);
         let linered = new Array(6);
         let lineblue = new Array(5);
         let yArrH = new Array(6);
         let yArrL = new Array(5);
         let y_pogodaH = new Array(6);
         let y_pogodaL = new Array(5);
         let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
         let week_weater_img = []
         let day_weater_img = []
         const ROOTPATH = "images/"

         let normal_city_name_text = ''


         //-------------------------------- 

         //массив иконок для графика       
         for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
         }


         //обновление для   графика           
         function updateGrafik() {

          const weather = new hmSensor.Weather();
          let weatherData = weather.getForecast();
          let forecastData = weatherData.forecastData;

          //normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);


          if (forecastData.count == 0) {
           for (let i = 0; i < 6; i++) {
            var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
           }
          } else {
           let weekDay = curTime.getDay() - 1;
           for (let i = 0; i < 6; i++) {
            yArrH[i] = forecastData.data[i].high;
            let element = forecastData.data[i];
            let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
            // let date = new Date(curTime.utc + 86400000 * i);
            let date = new Date(curTime.getTime() + 86400000 * i);
            let data = date.getDate();
            let week = week_weater[weekDay];
            week_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: week,
            });
            day_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: data,
            });
            weekDay = (weekDay + 1) % 7;
           }
          }


          for (let i = 0; i < 5; i++) {
           yArrL[i] = forecastData.data[i].low;
          }
          let maxH = Math.max(...yArrH)
          let maxL = Math.min(...yArrL)
          var shag = 46;
          var x0 = 119;
          for (let i = 0; i < 6; i++) {
           pointred[i].setProperty(hmUI.prop.MORE, {
            x: 119 + shag * [i] - 5,
            y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFFFF0000,
            line_width: 10,
           });
          };

          for (let i = 0; i < 5; i++) {
           yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            linered[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i,
             h: 466,
             pos_x: -31 + shag * i,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_red.png',
            });
          };
          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 4; i++) {
           yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            lineblue[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i + 23,
             h: 466,
             pos_x: -31 + shag * i + 23,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i + 23,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_blue.png',
            });
          };

          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 6; i++) {
           y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
           weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + i * 45 * 1.02,
            y: y_pogodaH[i] - 38, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrH[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }

          for (let i = 0; i < 5; i++) {
           y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
           weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + 23 + i * 45 * 1.02,
            y: y_pogodaL[i] - 1, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrL[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }
         }


         function makeAOD() {


         }


         //dynamic modify end

         function init_view() {
          //dynamic modify start


            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
             
//            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
//              center_x: 233,
//              center_y: 233,
//              start_angle: 120,
//              end_angle: 60,
//              radius: 199,
//              line_width: 3,
//              corner_flag: 3,
//              color: 0xFFFFFFFF,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });
             
            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 233 + 208,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -30,
              // end_angle: 30,
              // radius: 200,
              // line_width: 2,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -30,
              end_angle: 30,
              radius: 199,
              line_width: 2,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 202,
              start_angle: -30,
              end_angle: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             
            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 400,
              y: 131,
              image_array: ["puls_pr_0.png","puls_pr_1.png","puls_pr_2.png","puls_pr_3.png","puls_pr_4.png","puls_pr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             
             
//            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
//            battery.addEventListener(hmSensor.event.CHANGE, function() {
//              text_update();
//              scale_call();
//            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 216,
              // angle: 7,
              // char_space_angle: 1,
              // unit: 'dig_a_pr.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_battery_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 233 - 224,
              src: 'dig_a_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: -120,
              // end_angle: -60,
              // radius: 200,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF00FFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: -120,
              end_angle: -60,
              radius: 199,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 202,
              start_angle: -120,
              end_angle: -60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             
             
            normal_ALTIMETER_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 130,
              end_angle: 50,
              radius: 168,
              line_width: 11,
              corner_flag: 3,
              color: 0xFF8080FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });             
             
            
//            const step = hmSensor.createSensor(hmSensor.id.STEP);
//            step.addEventListener(hmSensor.event.CHANGE, function() {
//              text_update();
//              scale_call();
//            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 216,
              // angle: -90,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 109,
              y: 316,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_wind.png',
              center_x: 233,
              center_y: 233,
              x: 175,
              y: 112,
              start_angle: -79,
              end_angle: 0,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 316,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 216,
              // angle: -130,
              // char_space_angle: 1,
              // dot_image: 'dig_a_dot2.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
             
             
            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 233 + 208,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
             
             
             
          normal_sunset_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_vos.png',
              center_x: 233,
              center_y: 233,
              x: 193,
              y: 167,
              start_angle: -115,
              end_angle: 0,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
             
             
             
             
                
//            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
//              src: 'str_press.png',
//              center_x: 233,
//              center_y: 233,
//              x: 175,
//              y: 112,
//              start_angle: -100,
//              end_angle: -180,
//              type: hmUI.data_type.ALTIMETER,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });
                

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_vlg.png',
              center_x: 233,
              center_y: 233,
              x: 187,
              y: 120,
              start_angle: -79,
              end_angle: 0,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             

             
             

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 95,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_UF.png',
              center_x: 233,
              center_y: 233,
              x: 187,
              y: 120,
              start_angle: -100,
              end_angle: -180,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 95,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
             
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap_progress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
           normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 244,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 251,
              minute_startY: 244,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 163,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 212,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
//              x: 272,
//              y: 316,
//              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
//              padding: false,
//              h_space: 1,
//              align_h: hmUI.align.CENTER_H,
//              type: hmUI.data_type.ALTIMETER,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });
             
          ALTIMETER_txt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 272-20,
           y: 316,
           font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
           padding: false,
           h_space: 1,
           text: Math.round(airPressure).toString(),
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
             
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 210,
              end_angle: 150,
              radius: 199,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 201,
              start_angle: 210,
              end_angle: 150,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             
             
             
            
            //const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
//            calorie.addEventListener(hmSensor.event.CHANGE, function() {
//              text_update();
//              scale_call();
//            });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 233 + 208,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 233,
              // center_y: 233,
              // start_angle: 146,
              // end_angle: 30,
              // radius: 192,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFFFF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
             


             
             

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 233,
              center_y: 233,
              start_angle: 146,
              end_angle: 30,
              radius: 191,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              type: hmUI.data_type.WEATHER_CURRENT,  
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
            normal_fat_burning_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 194,
              start_angle: 146,
              end_angle: 30,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
             
             
             
            
//            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
//            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
//              scale_call();
//            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272-15,
              y: 369,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 216,
              // angle: 48,
              // char_space_angle: 1,
              // unit: 'dig_a_g.png',
              // dot_image: 'dig_a_m.png',
              // error_image: 'dig_a_v.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_high_TextCircle_img_width / 2,
                pos_y: 233 - 224,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_high_TextCircle_unit_width / 2,
              pos_y: 233 - 224,
              src: 'dig_a_g.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 216,
              // angle: 132,
              // char_space_angle: 1,
              // unit: 'dig_a_g.png',
              // dot_image: 'dig_a_m.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_low_TextCircle_img_width / 2,
                pos_y: 233 + 208,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_low_TextCircle_unit_width / 2,
              pos_y: 233 + 208,
              src: 'dig_a_g.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 355,
              font_array: ["dig_t_0.png","dig_t_1.png","dig_t_2.png","dig_t_3.png","dig_t_4.png","dig_t_5.png","dig_t_6.png","dig_t_7.png","dig_t_8.png","dig_t_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dig_t_p.png',
              unit_tc: 'dig_t_p.png',
              unit_en: 'dig_t_p.png',
              negative_image: 'dig_t_m.png',
              invalid_image: 'dig_t_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 49,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 368,
              image_array: ["wi_0.png","wi_1.png","wi_2.png","wi_3.png","wi_4.png","wi_5.png","wi_6.png","wi_7.png","wi_8.png","wi_9.png","wi_10.png","wi_11.png","wi_12.png","wi_13.png","wi_14.png","wi_15.png","wi_16.png","wi_17.png","wi_18.png","wi_19.png","wi_20.png","wi_21.png","wi_22.png","wi_23.png","wi_24.png","wi_25.png","wi_26.png","wi_27.png","wi_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
                
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 95,
              src: 'slider_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 184,
              src: 'slider_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 187,
              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dig_a_p.png',
              dot_image: 'dig_a_dot2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 129,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
             
            normal_sun_pointer_progress_img_pointer2 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 233,
              center_y: 233,
              x: 2,
              y: 194,
              start_angle: -147,
              end_angle: -30,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            })

             
             
          function text_update() {

              //console.log('update text circle heart_rate_HEART');
              //let valueHeartRate = heart_rate.last;
                let valueHeartRate = heart.getLast();
              
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle_heart = 256;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 216));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle_heart -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_heart -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_heart);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_heart -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              
              
              

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.getCurrent();
              let normal_battery_circle_string = parseInt(valueBattery).toString();

             // if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 7;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 216));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

             // };

              let valueStep = step.getCurrent();
              let normal_step_circle_string = parseInt(valueStep).toString();

                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle_step = -77;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 216));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  char_Angle_step -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_step += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_step);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_step += normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
//

              
          weatherData = weather.getForecast();
              
    					const {
    						forecastData,
    						tideData
    					} = weatherData
    					const {
    						sunrise: {
    							hour: sunriseHour,
    							minute: sunriseMinute
    						},
    						sunset: {
    							hour: sunsetHour,
    							minute: sunsetMinute
    						}
    					} = tideData.data[0]
                        
                sunrise_hour = sunriseHour;
                sunrise_minute = sunriseMinute;
              

              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour != 0 && sunrise_minute != 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour) + '.' + String(sunrise_minute).padStart(2, '0');
              };

                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle_sunrise = 50;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 216));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_sunrise -= normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_sunrise -= normal_sunrise_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle_sunrise -= normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_dot2.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_sunrise -= normal_sunrise_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite


              
              let sunset_hour = 0;
              let sunset_minute = 0;
              if (tideData.count > 0) {
                sunset_hour = sunsetHour;
                sunset_minute = sunsetMinute;
              }; // end tideData;

              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour != 0 && sunset_minute != 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
              };

                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle_sunset = -50;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 216));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_sunset += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_sunset += normal_sunset_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle_sunset += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_dot2.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_sunset += normal_sunset_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              
//
              let valueCalories = calorie.getCurrent();
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle_calorie = -13;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_calorie -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_calorie);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_calorie -= normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              
              
              
              //let forecastData = weatherData.forecastData;
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              let temperatureHigh = undefined;
              let normal_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_circle_string = String(high_temp)
              };

                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle_high = 48;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_high_TextCircle_img_angle = 0;
                  let normal_high_TextCircle_dot_img_angle = 0;
                  let normal_high_TextCircle_unit_angle = 0;
                  normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width/2, 216));
                  normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width/2, 216));
                  normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width/2, 216));
                  // alignment = CENTER_H
                  let normal_high_TextCircle_angleOffset = normal_high_TextCircle_img_angle * (normal_high_circle_string.length - 1);
                  normal_high_TextCircle_angleOffset = normal_high_TextCircle_angleOffset + 1 * (normal_high_circle_string.length - 1) / 2;
                  normal_high_TextCircle_angleOffset = normal_high_TextCircle_angleOffset + (normal_high_TextCircle_img_angle + normal_high_TextCircle_unit_angle + 1) / 2;
                  char_Angle_high -= normal_high_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_high += normal_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_high);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_img_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_high += normal_high_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle_high += normal_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_high);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_dot_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_m.png');
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_high += normal_high_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle_high += normal_high_TextCircle_unit_angle;
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle_high);
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_high_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle_high);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_error_img_width / 2);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.SRC, 'dig_a_v.png');
                  normal_high_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              
              
              
              
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle low_forecastData');
              let temperatureLow = undefined;
              let normal_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_circle_string = String(low_temp)
              };

                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle_low = 312;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_low_TextCircle_img_angle = 0;
                  let normal_low_TextCircle_dot_img_angle = 0;
                  let normal_low_TextCircle_unit_angle = 0;
                  normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width/2, 216));
                  normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width/2, 216));
                  normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width/2, 216));
                  // alignment = CENTER_H
                  let normal_low_TextCircle_angleOffset = normal_low_TextCircle_img_angle * (normal_low_circle_string.length - 1);
                  normal_low_TextCircle_angleOffset = normal_low_TextCircle_angleOffset + 1 * (normal_low_circle_string.length - 1) / 2;
                  normal_low_TextCircle_angleOffset = normal_low_TextCircle_angleOffset + (normal_low_TextCircle_img_angle + normal_low_TextCircle_unit_angle + 1) / 2;
                  normal_low_TextCircle_angleOffset = -normal_low_TextCircle_angleOffset;
                  char_Angle_low -= normal_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle_low -= normal_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_low);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_img_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_low -= normal_low_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle_low -= normal_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_low);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_dot_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_m.png');
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle_low -= normal_low_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle_low -= normal_low_TextCircle_unit_angle;
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle_low);
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite


            };             
             
             
             
             
             
             

             
             
            function scale_call() {

//                console.log('update scales STAND');
//                
//                let valueStand = stand.current;
//                let targetStand = stand.target;
//                let progressStand = valueStand/targetStand;
//                if (progressStand > 1) progressStand = 1;
//                let progress_cs_normal_stand = progressStand;
//
//                if (screenType != hmSetting.screen_type.AOD) {
//
//                  // normal_stand_circle_scale_circle_scale
//                  let level = Math.round(progress_cs_normal_stand * 100);
//                  if (normal_stand_circle_scale) {
//                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
//                      center_x: 233,
//                      center_y: 233,
//                      start_angle: 130,
//                      end_angle: 50,
//                      radius: 168,
//                      line_width: 11,
//                      corner_flag: 3,
//                      color: 0xFF8080FF,
//                      show_level: hmUI.show_level.ONLY_NORMAL,
//                      level: level,
//                    });
//                  };
//                };
                

                
                //let valueHeartRate = heart_rate.last;
                let valueHeartRate = heart.getLast();
//                let targetHeartRate = 179;
//                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
//                if (progressHeartRate < 0) progressHeartRate = 0;
//                if (progressHeartRate > 1) progressHeartRate = 1;
//                let progress_cs_normal_heart_rate = progressHeartRate;
//
//
//                 // let level = Math.round(progress_cs_normal_heart_rate * 100);
//                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
//                      center_x: 233,
//                      center_y: 233,
//                      start_angle: 120,
//                      end_angle: 60,
//                      radius: 199,
//                      line_width: 3,
//                      corner_flag: 3,
//                      color: 0xFFFFFFFF,
//                      show_level: hmUI.show_level.ONLY_NORMAL,
//                      level: Math.round(progress_cs_normal_heart_rate * 100),
//                    });

                console.log('update scales BATTERY');
                
                let valueBattery = battery.getCurrent();
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

               // if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                 // if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: -30,
                      end_angle: 30,
                      radius: 199,
                      line_width: 2,
                      corner_flag: 0,
                      color: valueBattery < 20 ? 0xFFff0000 : 0xFFffffff,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                 // };
               // };

                console.log('update scales STEP');
                
                let valueStep = step.getCurrent();
                let targetStep = step.getTarget();
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

              //  if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                 //level = Math.round(progress_cs_normal_step * 100);
                //  if (normal_step_circle_scale) {
           normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                      center_x: 233,
                      center_y: 233,
                      start_angle: -120,
                      end_angle: -60,
                      radius: 199,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: Math.round(progress_cs_normal_step * 100),
                    });
                
                //  };
               // };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.getCurrent();
                let targetCalories = calorie.getTarget();
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

               // if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  //let level = Math.round(progress_cs_normal_calorie * 100);
                 // if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 210,
                      end_angle: 150,
                      radius: 199,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: Math.round(progress_cs_normal_calorie * 100),
                    });
                  //};
               // };

/*                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 233,
                      center_y: 233,
                      start_angle: 146,
                      end_angle: 30,
                      radius: 191,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFFFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };*/

            };
             
             
  
			 

          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });

          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();
			   
		   
			   
			   
            scale_call();
                text_update();
            updateGrafik();


            let animRepeat = 1000;
            update_sec = setInterval(() => {


//             let airPressure = barometer.getAirPressure() * 0.750064;

             let valueALTIMETER = airPressure;
             let targetALTIMETER = 760 + 760;
             let progressALTIMETER = valueALTIMETER / targetALTIMETER;
             if (progressALTIMETER > 1) progressALTIMETER = 1;
             let progress_cs_normal_ALTIMETER = progressALTIMETER;

             let level3 = Math.round(progress_cs_normal_ALTIMETER * 100);
//
             normal_ALTIMETER_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 233,
              center_y: 233,
              start_angle: 130,
              end_angle: 50,
              radius: 168,
              line_width: 11,
              corner_flag: 3,
              color: valueALTIMETER > 760 ? 0xFFff0000 : 0xFF00ff00,
              level: level3,
              show_level: hmUI.show_level.ONLY_NORMAL,
             });
                
                
//
//
             ALTIMETER_txt.setProperty(hmUI.prop.TEXT, {
              text: Math.round(airPressure).toString(),
             });
//
//
//             let second = curTime.getSeconds();
//
//             let normal_fullAngle_second = -360;
//             let normal_angle_second = 0 + normal_fullAngle_second * second / 60;
//             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);


            }, animRepeat); // end timer


           }),

           pause_call: (function () {

            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
            clearInterval(update_sec)
            stopVibro();
           }),
          });
			 
			 

          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });


          btn_zona = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 299, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            click_zona();
            vibro(); //имя вызываемой функции
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
//           longpress_func: () => {
//            vibro();
//            click_str();
//           },

           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
             


          groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });



          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 24,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_run();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_zona_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }

          //--------------------------------------------------------- 




          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
             
             
             


          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);



          //dynamic modify end
         }


         __$$module$$__.module = WatchFace({
          onInit() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) loadSettings();
          },
          build() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) {
            makeAOD();
           } else {
            init_view();
           }
          },
          onPause() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: Ставлюсь на паузу!"});
           //else hmUI.showToast({text: "Ставлюсь на паузу!"});
          },
          onResume() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: И снова здравствуйте!!!"});
           //else hmUI.showToast({text: "И снова здравствуйте!!!"});
          },
          onDestroy() {
           vibrate && vibrate.stop();
          }
         });

        }
       }.bind(__$$G$$__)(__$$G$$__);


      afterPageCreate()
      afterModuleCreate()

     })()
    } catch (e) {

     console.log('Mini Program Error', e)
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i))

     /* todo */
    }
