﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'back_black_001a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -201,
              hour_startY: -94,
              hour_array: ["digi_dewata_54_0001.png","digi_dewata_54_0002.png","digi_dewata_54_0003.png","digi_dewata_54_0004.png","digi_dewata_54_0005.png","digi_dewata_54_0006.png","digi_dewata_54_0007.png","digi_dewata_54_0008.png","digi_dewata_54_0009.png","digi_dewata_54_0010.png"],
              hour_zero: 1,
              hour_space: -527,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -29,
              second_startY: 136,
              second_array: ["disc_shad_0001.png","disc_shad_0002.png","disc_shad_0003.png","disc_shad_0004.png","disc_shad_0005.png","disc_shad_0006.png","disc_shad_0007.png","disc_shad_0008.png","disc_shad_0009.png","disc_shad_0010.png"],
              second_zero: 0,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 178,
              minute_startY: 240,
              minute_array: ["digi_dewata_small_34_0001.png","digi_dewata_small_34_0002.png","digi_dewata_small_34_0003.png","digi_dewata_small_34_0004.png","digi_dewata_small_34_0005.png","digi_dewata_small_34_0006.png","digi_dewata_small_34_0007.png","digi_dewata_small_34_0008.png","digi_dewata_small_34_0009.png","digi_dewata_small_34_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Ring_sec_blacwhited-5.png',
              // center_x: 233,
              // center_y: 233,
              // x: 357,
              // y: 358,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Ring_sec_blacwhited-5.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 357,
              second_posY: 358,
              fresh_frequency: 30,
              fresh_freqency: 30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 30,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'back_black_001a.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -201,
              hour_startY: -94,
              hour_array: ["digi_dewata_54_0001.png","digi_dewata_54_0002.png","digi_dewata_54_0003.png","digi_dewata_54_0004.png","digi_dewata_54_0005.png","digi_dewata_54_0006.png","digi_dewata_54_0007.png","digi_dewata_54_0008.png","digi_dewata_54_0009.png","digi_dewata_54_0010.png"],
              hour_zero: 1,
              hour_space: -527,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -29,
              second_startY: 136,
              second_array: ["disc_shad_0001.png","disc_shad_0002.png","disc_shad_0003.png","disc_shad_0004.png","disc_shad_0005.png","disc_shad_0006.png","disc_shad_0007.png","disc_shad_0008.png","disc_shad_0009.png","disc_shad_0010.png"],
              second_zero: 0,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 178,
              minute_startY: 240,
              minute_array: ["digi_dewata_small_34_0001.png","digi_dewata_small_34_0002.png","digi_dewata_small_34_0003.png","digi_dewata_small_34_0004.png","digi_dewata_small_34_0005.png","digi_dewata_small_34_0006.png","digi_dewata_small_34_0007.png","digi_dewata_small_34_0008.png","digi_dewata_small_34_0009.png","digi_dewata_small_34_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: -22,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
