﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.0.1
     ** Copyright © CashaCX75. All Rights Reserved
     */

    try {
      (() => {
        //dynamic modify start
        let weather_animation = ''

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_image_progress_img_progress = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        //let normal_digital_clock_img_time = ''
        let normal_city_name_text = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_current_text_img = ''
        //let normal_weather_image_progress_img_level = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        //let normal_fat_burning_image_progress_img_level = ''
        let normal_floor_icon_img = ''
        let normal_floor_current_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_DIRECTION_img_LEVEL = ''
        let normal_stand_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_image_progress_img_progress = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_calendar_img_click = ''
        //let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_find_img_click = ''
        //let normal_pai_jumpable_img_click = ''


        let normal_rain_icon_img = ''
        let normal_frost_icon_img = ''
        let normal_fog_large_icon_img = ''
        let normal_weather_image_progress_img_index = ''
        let prefix = ''
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_frame_animation_5 = ''
        let normal_frame_animation_6 = ''
        let hour_tens = -1;
        let hour_ones = -1;
        let minute_tens = -1;
        let minute_ones = -1;
        let timer_1;
          
    const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
    function click_Vibrate() {
      vibrate.stop()
      vibrate.scene = 25
      vibrate.start()
    }
          
          
    let btn_zona1 = ''
    let zona1_num = 0
    let zona1_all = 2

    function click_zona1() {
      zona1_num = (zona1_num + 1) % (zona1_all + 1);
      if (zona1_num == 0) {
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false); normal_wind_DIRECTION_img_LEVEL.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false); 
        hmUI.showToast({
          text: 'Калории Пульс'
        });
      };

      if (zona1_num == 1) {
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img .setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true); normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true); normal_wind_DIRECTION_img_LEVEL.setProperty(hmUI.prop.VISIBLE, true);
        normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false); 
        hmUI.showToast({
          text: 'Давление Ветер'
        });
      };
        
      if (zona1_num == 2) {
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img .setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false); normal_wind_DIRECTION_img_LEVEL.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true); normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, true); 
        hmUI.showToast({
          text: 'Этаж Жир'
        });
      };
        
    }


    let btn_zona2 = ''
    let zona2_num = 0
    let zona2_all = 2

    function click_zona2() {
      zona2_num = (zona2_num + 1) % (zona2_all + 1);
      if (zona2_num == 0) {
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          
        hmUI.showToast({
          text: 'Температура'
        });
      };

      if (zona2_num == 1) {
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          
        hmUI.showToast({
          text: 'Восход Закат'
        });
      };

      if (zona2_num == 2) {
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
          
        hmUI.showToast({
          text: 'Влажность УФ'
        });
      };

    }          
          
          



        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current,
          {
            px: i
          } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o)),
            e.__globals__),
          n = Logger.getLogger("watchface6");


        //--------------------- анимация погоды  ---------------------


        let weather_animation_frames = [21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21];
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;

        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60; // время восхода
        let sunsetMins_def = 20 * 60; // и заката по умолчанию
        let curMins = '';
        let isDayIcons = true;


        function setWeatherAnimation() {


          weatherData = weather.getForecastWeather();
          forecastData = weatherData.forecastData;
          let index = 25; // неизвестная погода
          if (forecastData.count > 0) { // если погодные данные получены
            index = forecastData.data[0].index; // меняем индекс на текущий
            //index = 21 // тест
          };

          normal_weather_image_progress_img_index.setProperty(hmUI.prop.SRC, "weat_" + index + ".png");

          // одинаковый дождь
          if (index == 5 || index == 7 || index == 10 || index == 18 || index == 21 || index == 24) { // одинаковая анимация
            index = 5;
          };

          // одинаковый снег
          if (index == 6 || index == 8 || index == 9 || index == 16) { // одинаковая анимация
            index = 6;
          };

          // одинаковый ветер
          if (index == 11 || index == 17) { // одинаковая анимация
            index = 11;
          };

          // одинаковый туман
          if (index == 13 || index == 14) { // одинаковая анимация
            index = 13;
          };

          // одинаковый дождь с градом
          if (index == 19 || index == 20) { // одинаковая анимация
            index = 19;
          };

          // одинаковый пыльная буря
          if (index == 22 || index == 23) { // одинаковая анимация
            index = 22;
          };

          //------------------------ автозамена иконок погоды -----------------------------------


          sunData = weatherData.tideData;
          if (sunData.count > 0) {
            today = sunData.data[0];
            sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
            sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          } else {
            sunriseMins = sunriseMins_def;
            sunsetMins = sunsetMins_def;
          }
          curMins = curTime.hour * 60 + curTime.minute;
          let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
          if (isDayNow) {
            if (!isDayIcons) {
              prefix = "";
              isDayIcons = true;
            }
          } else {
            if (isDayIcons) {
              if (index == 4 || index == 5 || index == 6 || index == 11 || index == 12 || index == 15 || index == 19 || index == 25) // нет ночной анимации
              {
                prefix = "";
              } else {
                prefix = "_night";
              }
            }
            isDayIcons = false;
          }

          //------------------------ автозамена иконок погоды ----------------------------------- \\            


          hmUI.deleteWidget(weather_animation);
          weather_animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 133,
            y: 274,
            anim_path: `weather/${index}`,
            anim_ext: "png",
            anim_prefix: "anim" + prefix,
            anim_fps: 7,
            anim_size: weather_animation_frames[index],
            repeat_count: 1,
            anim_repeat: false,
            anim_status: hmUI.anim_status.START,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }

        function stopWeatherAnimation() {
          weather_animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
        }

        //---------------------------------------------------------------


        o.module = DeviceRuntimeCore.WatchFace({
          init_view() {
            //dynamic modify start


            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 172,
              src: '0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 409,
              y: 170,
              src: '0044.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 115,
              font_array: ["dig_sm_0.png", "dig_sm_1.png", "dig_sm_2.png", "dig_sm_3.png", "dig_sm_4.png", "dig_sm_5.png", "dig_sm_6.png", "dig_sm_7.png", "dig_sm_8.png", "dig_sm_9.png"],

              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 0,
              image_array: ["bat_pr_1.png", "bat_pr_2.png", "bat_pr_3.png", "bat_pr_4.png", "bat_pr_5.png", "bat_pr_6.png", "bat_pr_7.png", "bat_pr_8.png", "bat_pr_9.png", "bat_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 333,
              font_array: ["dig_sm_0.png", "dig_sm_1.png", "dig_sm_2.png", "dig_sm_3.png", "dig_sm_4.png", "dig_sm_5.png", "dig_sm_6.png", "dig_sm_7.png", "dig_sm_8.png", "dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 329,
              src: 'icon_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 242,
              image_array: ["cal_pr_1.png", "cal_pr_2.png", "cal_pr_3.png", "cal_pr_4.png", "cal_pr_5.png", "cal_pr_6.png", "cal_pr_7.png", "cal_pr_8.png", "cal_pr_9.png", "cal_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 365,
              font_array: ["dig_sm_0.png", "dig_sm_1.png", "dig_sm_2.png", "dig_sm_3.png", "dig_sm_4.png", "dig_sm_5.png", "dig_sm_6.png", "dig_sm_7.png", "dig_sm_8.png", "dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 408,
              y: 248,
              image_array: ["0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 365,
              src: 'icon_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 115,
              font_array: ["dig_sm_0.png", "dig_sm_1.png", "dig_sm_2.png", "dig_sm_3.png", "dig_sm_4.png", "dig_sm_5.png", "dig_sm_6.png", "dig_sm_7.png", "dig_sm_8.png", "dig_sm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dig_sm_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 115,
              font_array: ["dig_sm_0.png", "dig_sm_1.png", "dig_sm_2.png", "dig_sm_3.png", "dig_sm_4.png", "dig_sm_5.png", "dig_sm_6.png", "dig_sm_7.png", "dig_sm_8.png", "dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["step_pr_1.png", "step_pr_2.png", "step_pr_3.png", "step_pr_4.png", "step_pr_5.png", "step_pr_6.png", "step_pr_7.png", "step_pr_8.png", "step_pr_9.png", "step_pr_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [302, 302, 302, 302, 302, 302, 302, 302, 302, 302],
              y: [118, 118, 118, 118, 118, 118, 118, 118, 118, 118],
              image_array: ["0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 65,
              week_en: ["0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],
              week_tc: ["0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],
              week_sc: ["0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 274,
              month_startY: 60,
              month_sc_array: ["0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png"],
              month_tc_array: ["0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png"],
              month_en_array: ["0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png"],
              month_is_character: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 57,
              day_sc_array: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png"],
              day_tc_array: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png"],
              day_en_array: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dig_sm_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 361,
              src: 'icon_zak.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 333,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dig_sm_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 328,
              src: 'icon_vos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 358,
              y: 328,
              src: 'icon_vlag.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 333,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 352,
              y: 356,
              src: 'icon_UF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 363,
              src: 'icon_jir.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 328,
              src: 'icon_lest.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 333,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 73,
              y: 324,
              src: 'icon_davlen.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'icon_davlen_st.png',
              center_x: 95,
              center_y: 345,
              x: 7,
              y: 11,
              start_angle: -140,
              end_angle: 140,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 333,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              
            normal_heart_rate_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [242, 242, 242, 242, 242, 242],
              y: [240, 240, 240, 240, 240, 240],
              image_array: ["pul_pr_1.png", "pul_pr_2.png", "pul_pr_3.png", "pul_pr_4.png", "pul_pr_5.png", "pul_pr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              
            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 363,
              font_array: ["t_s_0.png", "t_s_1.png", "t_s_2.png", "t_s_3.png", "t_s_4.png", "t_s_5.png", "t_s_6.png", "t_s_7.png", "t_s_8.png", "t_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_s_13.png',
              unit_tc: 't_s_13.png',
              unit_en: 't_s_13.png',
              negative_image: 't_s_12.png',
              invalid_image: 't_s_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 333,
              font_array: ["t_s_0.png", "t_s_1.png", "t_s_2.png", "t_s_3.png", "t_s_4.png", "t_s_5.png", "t_s_6.png", "t_s_7.png", "t_s_8.png", "t_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_s_13.png',
              unit_tc: 't_s_13.png',
              unit_en: 't_s_13.png',
              negative_image: 't_s_12.png',
              invalid_image: 't_s_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              
            normal_wind_DIRECTION_img_LEVEL = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 364,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 336,
              font_array: ["t_b_0.png", "t_b_1.png", "t_b_2.png", "t_b_3.png", "t_b_4.png", "t_b_5.png", "t_b_6.png", "t_b_7.png", "t_b_8.png", "t_b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_b_13.png',
              unit_tc: 't_b_13.png',
              unit_en: 't_b_13.png',
              negative_image: 't_b_12.png',
              invalid_image: 't_b_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              
            normal_weather_image_progress_img_index = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 395,
              src: "weat_26.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              
            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 413,
              w: 135,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            let time_now = hmSensor.createSensor(hmSensor.id.TIME);


            function start_time_anim() {
              let HourTens = parseInt(time_now.hour / 10);
              let HourOnes = parseInt(time_now.hour % 10);
              let MinuteTens = parseInt(time_now.minute / 10);
              let MinuteOnes = parseInt(time_now.minute % 10);


              /*              if (HourTens != hour_tens) {
                              console.log('HourTens = ' + HourTens);
                              hour_tens = HourTens;
                              let animation_prefix = animationPrefix(HourTens);
                              console.log(animation_prefix);
                              normal_frame_animation_6 = undefined;
                              normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                                x: 60,
                                y: 152,
                                anim_path: "animation",
                                anim_ext: "png",
                                anim_prefix: "flip",
                                anim_fps: 15,
                                anim_size: 14,
                                repeat_count: 1,
                                anim_repeat: false,
                                anim_status:hmUI.anim_status.START,
                                show_level: hmUI.show_level.ONLY_NORMAL,
                              });
                            }

                            if (MinuteTens != minute_tens) {
                              console.log('MinuteTens = ' + MinuteTens);
                              minute_tens = MinuteTens;
                              let animation_prefix = animationPrefix(MinuteTens);
                              console.log(animation_prefix);
                              normal_frame_animation_5 = undefined;
                              normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                                x: 250,
                                y: 152,
                                anim_path: "animation",
                                anim_ext: "png",
                                anim_prefix: "flip",
                                anim_fps: 15,
                                anim_size: 14,
                                repeat_count: 1,
                                anim_repeat: false,
                                anim_status:hmUI.anim_status.START,
                                show_level: hmUI.show_level.ONLY_NORMAL,
                              });
                            }*/

              if (HourTens != hour_tens) {
                console.log('HourTens = ' + HourTens);
                hour_tens = HourTens;
                let animation_prefix = animationPrefix(HourTens);
                console.log(animation_prefix);

                normal_frame_animation_6 = undefined;
                normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 60,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: "flip",
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_frame_animation_1 = undefined;
                normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 74,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: animation_prefix,
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

              }

              if (HourOnes != hour_ones) {
                console.log('HourOnes = ' + HourOnes);
                hour_ones = HourOnes;
                let animation_prefix = animationPrefix(HourOnes);
                console.log(animation_prefix);
                normal_frame_animation_2 = undefined;
                normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 138,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: animation_prefix,
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              }

              if (MinuteTens != minute_tens) {
                console.log('MinuteTens = ' + MinuteTens);
                minute_tens = MinuteTens;
                let animation_prefix = animationPrefix(MinuteTens);
                console.log(animation_prefix);

                normal_frame_animation_5 = undefined;
                normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 250,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: "flip",
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_frame_animation_3 = undefined;
                normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 264,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: animation_prefix,
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

              }

              if (MinuteOnes != minute_ones) {
                console.log('MinuteOnes = ' + MinuteOnes);
                minute_ones = MinuteOnes;
                let animation_prefix = animationPrefix(MinuteOnes);
                console.log(animation_prefix);
                normal_frame_animation_4 = undefined;
                normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                  x: 328,
                  y: 152,
                  anim_path: "animation",
                  anim_ext: "png",
                  anim_prefix: animation_prefix,
                  anim_fps: 15,
                  anim_size: 14,
                  repeat_count: 1,
                  anim_repeat: false,
                  anim_status: hmUI.anim_status.START,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              }
            };

            function animationPrefix(number) {
              let value = "animdig_0-1";
              switch (number) {
                case 1:
                  value = "animdig_0-1";
                  break;
                case 2:
                  value = "animdig_1-2";
                  break;
                case 3:
                  value = "animdig_2-3";
                  break;
                case 4:
                  value = "animdig_3-4";
                  break;
                case 5:
                  value = "animdig_4-5";
                  break;
                case 6:
                  value = "animdig_5-6";
                  break;
                case 7:
                  value = "animdig_6-7";
                  break;
                case 8:
                  value = "animdig_7-8";
                  break;
                case 9:
                  value = "animdig_8-9";
                  break;
                case 0:
                  value = "animdig_9-0";
                  break;
              }
              return value;
            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                if (!timer_1) {
                  console.log('createTimer');
                  timer_1 = timer.createTimer(0, 1000, (function (option) {
                    start_time_anim();
                    rain();
                    hmUI.deleteWidget(normal_rain_icon_img);
                    //normal_rain_icon_img = undefined;
                    normal_rain_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                      x: 30 + xxx1,
                      y: 164,
                      src: 'rain.png',
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    hmUI.deleteWidget(normal_frost_icon_img);
                    normal_frost_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                      x: 30 + xxx2,
                      y: 160,
                      src: 'frost.png',
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    hmUI.deleteWidget(normal_fog_large_icon_img);
                    normal_fog_large_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                      x: 30 + xxx3,
                      y: 164,
                      src: 'fog_large.png',
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                  })); // end timer create
                };
                setWeatherAnimation();
              }),
              pause_call: (function () {
                if (timer_1) {
                  timer.stopTimer(timer_1);
                  timer_1 = undefined;
                };
                stopWeatherAnimation();
              }),
            });


            function rain() {
              let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
              forecastData = weatherData.forecastData;
              let index = 25; // неизвестная погода
              if (forecastData.count > 0) { // если погодные данные получены
                index = forecastData.data[0].index; // меняем индекс на текущий
                //index = 21 // тест
              };

              // сосульки  
              let temperature = forecastData.data[0].high
              if (temperature < 0) { // если температура меньше 0
                xxx2 = 0
              } else {
                xxx2 = 500
              };

              // Туман 
              if (index == 13) { // если туман
                xxx3 = 0
              } else {
                xxx3 = 500
              };

              //  капли  
              if (index == 1 || index == 5 || index == 7 || index == 10 || index == 15 || index == 18 || index == 19 || index == 20 || index == 21 || index == 24 || index == 27) { // если дождь
                xxx1 = 0
              } else {
                xxx1 = 500
              };
            };

            function scale_call() {
              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
            };



            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 276,
              y: 44,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 44,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
              
            normal_calendar_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 44,
              w: 60,
              h: 60,
              src: 'icon_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calendar_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'ScheduleCalScreen',
                native: true
              })
            });

              
              
              

/*            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 330,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 392,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              

/*            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 44,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
              
            normal_find_img_click = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 44,
              w: 60,
              h: 60,
              src: 'icon_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_find_img_click.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({
                appid: 1,
                url: 'FindPhoneScreen',
                native: true
              })
            });


/*            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 330,
              w: 60,
              h: 60,
              src: '0001.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
              
        btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 90, //x кнопки
          y: 330, //y кнопки
          text: '',
          w: 60, //ширина кнопки
          h: 60, //высота кнопки
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_zona1();
            click_Vibrate(); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
              
        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_altimeter_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false); normal_wind_DIRECTION_img_LEVEL.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false); normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false); 
              
              
        btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 316, //x кнопки
          y: 330, //y кнопки
          text: '',
          w: 60, //ширина кнопки
          h: 60, //высота кнопки
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_zona2();
            click_Vibrate(); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              
              
              
            //dynamic modify end
          },


          onInit() {
            n.log("index page.js on init invoke")
            this.init_view()
          },
          onReady() {
            console.log('index page.js on ready invoke')
          },
          onShow() {
            console.log('index page.js on show invoke')
          },
          onHide() {
            console.log('index page.js on hide invoke')
          },

          build() {
            this.init_view(),
              n.log("index page.js on ready invoke")
          },
          onDestroy() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            n.log("index page.js on destroy invoke")
            vibrate && vibrate.stop();
          }

        })
      })()
    } catch (e) {
      console.log("Mini Program Error", e),
        e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
    }
