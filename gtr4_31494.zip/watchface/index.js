﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
		let img1 = ''
		let img2 = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_image_progress_img_level = ''
        let normal_sun_pointer_progress_img_pointer = ''
		let bg_mask1 = ''
		let bg_mask2 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_stand_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_stress_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''

		let btn_arrow = '' //change_arrow
		let hour_pointer = ''//change_arrow
		let minute_pointer = ''//change_arrow
		let arrowsVisible = true
		
		function showHideArrows() {							// прячем / показываем стрелки
			arrowsVisible = !arrowsVisible;
		
			minute_pointer.setProperty(hmUI.prop.VISIBLE, arrowsVisible);
			hour_pointer.setProperty(hmUI.prop.VISIBLE, arrowsVisible);
		}

		let btn_zona1 = ''
		let zona1_num = 0
		let zona1_all = 2
		
		function click_zona1() {
		zona1_num = (zona1_num + 1) % (zona1_all + 1);
		if (zona1_num == 0) {
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'STEPS'
        });
      };

		if (zona1_num == 1) {
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'CALRS'
        });
      };
		if (zona1_num == 2) {
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'DISTANCE'
        });
      };
    }	

		let btn_zona2 = ''
		let zona2_num = 0
		let zona2_all = 2
		
		function click_zona2() {
		zona2_num = (zona2_num + 1) % (zona2_all + 1);
		if (zona2_num == 0) {
        normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);		
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'BEZEL1'
        });
      };

		if (zona2_num == 1) {
        normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'BEZEL2'
        });
      };

		if (zona2_num == 2) {
        normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);	
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'BEZEL2'
        });
      };	  
    }	

		let btn_zona3 = ''
		let zona3_num = 0
		let zona3_all = 1
		
		function click_zona3() {
		zona3_num = (zona3_num + 1) % (zona3_all + 1);
		if (zona3_num == 0) {
        img1.setProperty(hmUI.prop.VISIBLE, true);
        img2.setProperty(hmUI.prop.VISIBLE, false);
        bg_mask1.setProperty(hmUI.prop.VISIBLE, true);		
        bg_mask2.setProperty(hmUI.prop.VISIBLE, false);	
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'BG LIGHT'
        });
      };

		if (zona3_num == 1) {
        img1.setProperty(hmUI.prop.VISIBLE, false);
        img2.setProperty(hmUI.prop.VISIBLE, true);
        bg_mask1.setProperty(hmUI.prop.VISIBLE, false);		
        bg_mask2.setProperty(hmUI.prop.VISIBLE, true);	
        hmUI.showToast(hmUI.prop.VISIBLE, false)({
          text: 'BG DARK'
        });
      };  
    }	

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   

            img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 114,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 92,
              image_array: ["star_mask_1.png","star_mask_2.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'SUN_circle.png',
              center_x: 236,
              center_y: 163,
              x: 50,
              y: 50,
              start_angle: -13,
              end_angle: 154,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bg_mask1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,			  
              src: 'Mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   	

            bg_mask2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,			  
              src: 'Mask_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 180,
              font_array: ["NUMBERS_PWR_HR_00.png","NUMBERS_PWR_HR_01.png","NUMBERS_PWR_HR_02.png","NUMBERS_PWR_HR_03.png","NUMBERS_PWR_HR_04.png","NUMBERS_PWR_HR_05.png","NUMBERS_PWR_HR_06.png","NUMBERS_PWR_HR_07.png","NUMBERS_PWR_HR_08.png","NUMBERS_PWR_HR_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 142,
              image_array: ["circle_01.png","circle_02.png","circle_03.png","circle_04.png","circle_05.png","circle_06.png","circle_07.png","circle_08.png","circle_09.png","circle_10.png","circle_11.png","circle_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 180,
              font_array: ["NUMBERS_PWR_HR_00.png","NUMBERS_PWR_HR_01.png","NUMBERS_PWR_HR_02.png","NUMBERS_PWR_HR_03.png","NUMBERS_PWR_HR_04.png","NUMBERS_PWR_HR_05.png","NUMBERS_PWR_HR_06.png","NUMBERS_PWR_HR_07.png","NUMBERS_PWR_HR_08.png","NUMBERS_PWR_HR_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 269,
              y: 142,
              image_array: ["circle_HR_01.png","circle_HR_02.png","circle_HR_03.png","circle_HR_04.png","circle_HR_05.png","circle_HR_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 268,
              font_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'NUMBERS_DATE_WEATHER_C.png',
              unit_tc: 'NUMBERS_DATE_WEATHER_C.png',
              unit_en: 'NUMBERS_DATE_WEATHER_C.png',
              negative_image: 'NUMBERS_DATE_WEATHER_MINUS.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 362,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 364,
              font_array: ["NUMBERS_STEPS_00.png","NUMBERS_STEPS_01.png","NUMBERS_STEPS_02.png","NUMBERS_STEPS_03.png","NUMBERS_STEPS_04.png","NUMBERS_STEPS_05.png","NUMBERS_STEPS_06.png","NUMBERS_STEPS_07.png","NUMBERS_STEPS_08.png","NUMBERS_STEPS_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 362,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 364,
              font_array: ["NUMBERS_STEPS_00.png","NUMBERS_STEPS_01.png","NUMBERS_STEPS_02.png","NUMBERS_STEPS_03.png","NUMBERS_STEPS_04.png","NUMBERS_STEPS_05.png","NUMBERS_STEPS_06.png","NUMBERS_STEPS_07.png","NUMBERS_STEPS_08.png","NUMBERS_STEPS_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 364,
              font_array: ["NUMBERS_DISTANCE_00.png","NUMBERS_DISTANCE_01.png","NUMBERS_DISTANCE_02.png","NUMBERS_DISTANCE_03.png","NUMBERS_DISTANCE_04.png","NUMBERS_DISTANCE_05.png","NUMBERS_DISTANCE_06.png","NUMBERS_DISTANCE_07.png","NUMBERS_DISTANCE_08.png","NUMBERS_DISTANCE_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'NUMBERS_DISTANCE_DOTE.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 362,
              src: 'icon_distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 138,
              month_startY: 268,
              month_sc_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              month_tc_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              month_en_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 268,
              day_sc_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              day_tc_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              day_en_array: ["NUMBERS_DATE_WEATHER_00.png","NUMBERS_DATE_WEATHER_01.png","NUMBERS_DATE_WEATHER_02.png","NUMBERS_DATE_WEATHER_03.png","NUMBERS_DATE_WEATHER_04.png","NUMBERS_DATE_WEATHER_05.png","NUMBERS_DATE_WEATHER_06.png","NUMBERS_DATE_WEATHER_07.png","NUMBERS_DATE_WEATHER_08.png","NUMBERS_DATE_WEATHER_09.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 268,
              src: 'NUMBERS_DATE_WEATHER_-.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 99,
              am_y: 310,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 99,
              pm_y: 310,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 308,
              hour_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 308,
              minute_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 313,
              second_startY: 309,
              second_array: ["NUMBERS_MED_00.png","NUMBERS_MED_01.png","NUMBERS_MED_02.png","NUMBERS_MED_03.png","NUMBERS_MED_04.png","NUMBERS_MED_05.png","NUMBERS_MED_06.png","NUMBERS_MED_07.png","NUMBERS_MED_08.png","NUMBERS_MED_09.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 395,
              src: 'icon_bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 314,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		    hour_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HAND_H_0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 35,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            minute_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'HAND_M_0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 46,
              minute_posY: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_S.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 232,
              second_cover_path: 'CAP.png',
              second_cover_x: 224,
              second_cover_y: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			btn_arrow = hmUI.createWidget(hmUI.widget.BUTTON, {//change_arrow - at 6
               x: 182,//change_arrow
               y: 183,//change_arrow
               text: '',//change_arrow
               w: 100,//change_arrow
               h: 100,//change_arrow
               normal_src: 'click_e.png',//change_arrow
               press_src: 'click_e.png',//change_arrow
               click_func: () => {//change_arrow
					showHideArrows();
               },//change_arrow
               show_level: hmUI.show_level.ONLY_NORMAL,//change_arrow
           });//change_arrow
		   
		   
			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 156, //x кнопки
				y: 362, //y кнопки
				text: '',
				w: 153, //ширина кнопки
				h: 57, //высота кнопки
				normal_src: 'click_e.png',
				press_src: 'click_e.png',
				click_func: () => {
				click_zona1();
				click_Vibrate(); //имя вызываемой функции
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
				btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

					normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
					normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);		
					normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
					normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);		   
					
					
			btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 185, //x кнопки
				y: 0, //y кнопки
				text: '',
				w: 100, //ширина кнопки
				h: 88, //высота кнопки
				normal_src: 'click_e.png',
				press_src: 'click_e.png',
				click_func: () => {
				click_zona2();
				click_Vibrate(); //имя вызываемой функции
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
				btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

					normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
					normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
					normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);	

			btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 0, //x кнопки
				y: 201, //y кнопки
				text: '',
				w: 89, //ширина кнопки
				h: 63, //высота кнопки
				normal_src: 'click_e.png',
				press_src: 'click_e.png',
				click_func: () => {
				click_zona3();
				click_Vibrate(); //имя вызываемой функции
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
				btn_zona3.setProperty(hmUI.prop.VISIBLE, true);

					img1.setProperty(hmUI.prop.VISIBLE, true);
					img2.setProperty(hmUI.prop.VISIBLE, false);
					bg_mask1.setProperty(hmUI.prop.VISIBLE, true);		
					bg_mask2.setProperty(hmUI.prop.VISIBLE, false);	

			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 58,
				y: 257,
				text: '',
				w: 116,
				h: 41,
				normal_src: 'click_e.png',
				press_src: 'click_e.png',
				click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Main_AOD_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 180,
              font_array: ["NUMBERS_PWR_HR_00.png","NUMBERS_PWR_HR_01.png","NUMBERS_PWR_HR_02.png","NUMBERS_PWR_HR_03.png","NUMBERS_PWR_HR_04.png","NUMBERS_PWR_HR_05.png","NUMBERS_PWR_HR_06.png","NUMBERS_PWR_HR_07.png","NUMBERS_PWR_HR_08.png","NUMBERS_PWR_HR_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 142,
              image_array: ["circle_01.png","circle_02.png","circle_03.png","circle_04.png","circle_05.png","circle_06.png","circle_07.png","circle_08.png","circle_09.png","circle_10.png","circle_11.png","circle_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 180,
              font_array: ["NUMBERS_PWR_HR_00.png","NUMBERS_PWR_HR_01.png","NUMBERS_PWR_HR_02.png","NUMBERS_PWR_HR_03.png","NUMBERS_PWR_HR_04.png","NUMBERS_PWR_HR_05.png","NUMBERS_PWR_HR_06.png","NUMBERS_PWR_HR_07.png","NUMBERS_PWR_HR_08.png","NUMBERS_PWR_HR_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 269,
              y: 142,
              image_array: ["circle_HR_01.png","circle_HR_02.png","circle_HR_03.png","circle_HR_04.png","circle_HR_05.png","circle_HR_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_AOD_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 99,
              am_y: 310,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 99,
              pm_y: 310,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 308,
              hour_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 308,
              minute_array: ["NUMBERS_BIG_00.png","NUMBERS_BIG_01.png","NUMBERS_BIG_02.png","NUMBERS_BIG_03.png","NUMBERS_BIG_04.png","NUMBERS_BIG_05.png","NUMBERS_BIG_06.png","NUMBERS_BIG_07.png","NUMBERS_BIG_08.png","NUMBERS_BIG_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_AOD_mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 395,
              src: 'icon_bluetoothoff_AOD.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 314,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HAND_H_AOD.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 35,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'HAND_M_AOD.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 46,
              minute_posY: 207,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_S_AOD.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 20,
              second_posY: 232,
              second_cover_path: 'CAP_AOD.png',
              second_cover_x: 224,
              second_cover_y: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 307,
              w: 158,
              h: 49,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 91,
              w: 67,
              h: 70,
              src: 'click_e.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 258,
              w: 108,
              h: 47,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 142,
              w: 94,
              h: 101,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
