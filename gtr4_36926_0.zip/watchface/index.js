﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    ** Animated watchface made by Geofftoucourt
    */
   
    try {
    (() => {
        //start of ignored blocks
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''   
        let normal_sun_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_text =''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_frame_animation_5 = ''
        let normal_frame_animation_6 = ''
        let normal_frame_animation_7 = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let image_top_img = ''
        let image_level_text =''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_6 = ''
        let lvlcalc = 1000
        let stepsWidget = ''
        let steps = hmSensor.createSensor(hmSensor.id.STEP)
        let stepsPercent = Math.floor(steps.current / lvlcalc)  
        let lvlstep = Math.floor(stepsPercent -1) 
        let Button_4 = ''
        let colornumber = 1
        let totalcolors = 6
        let normal_background_bag_img = ''
        let normal_pai_day_text_bag_img = ''
        let normal_heart_rate_text_text_bag_img = ''
        let normal_distance_text_text_bag_img = ''
        let normal_calorie_current_text_bag_img = ''
        let normal_step_current_text_bag_img = ''
        let Button_bag_5 = ''
        let backgroundpage = 1
        let totalpage = 2
        let cc = 0
             



 
// Start background change
                 
        
function click_background() {
            if(backgroundpage>=totalpage) {
            backgroundpage=1;
                backgroundone();
                }
            else {
                backgroundpage=backgroundpage+1;
                if(backgroundpage==2) {
                  backgroundtwo();
                }

            }
            
        }


        function backgroundone(){

   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, true);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, true);
   image_top_img.setProperty(hmUI.prop.VISIBLE, true);
   image_level_text.setProperty(hmUI.prop.VISIBLE, true);
   Button_1.setProperty(hmUI.prop.VISIBLE, true);
   Button_2.setProperty(hmUI.prop.VISIBLE, true);
   Button_3.setProperty(hmUI.prop.VISIBLE, true);
   Button_4.setProperty(hmUI.prop.VISIBLE, true);
   Button_6.setProperty(hmUI.prop.VISIBLE, true);
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, false); 

}


         function backgroundtwo(){

   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, false);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
   image_top_img.setProperty(hmUI.prop.VISIBLE, false);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, false);
   image_level_text.setProperty(hmUI.prop.VISIBLE, false);
   Button_1.setProperty(hmUI.prop.VISIBLE, false);
   Button_2.setProperty(hmUI.prop.VISIBLE, false);
   Button_3.setProperty(hmUI.prop.VISIBLE, false);
   Button_4.setProperty(hmUI.prop.VISIBLE, false);
   Button_6.setProperty(hmUI.prop.VISIBLE, false);
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, true); 




}
 
// Animation hide when done
        
         function hide() {
         normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
            }

// Run click turn screen of

function click_run() {
const result = hmSetting.setScreenOff()
}

// Change pokémon

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
            hmUI.showToast({text: "Go! Pikachu!" });
                }
            else {
                colornumber=colornumber+1;       
                } 

         if(colornumber==2) hmUI.showToast({text: 'Go! Butterfree!'});
         if(colornumber==3) hmUI.showToast({text: 'What will Pidgeot do ?'});
         if(colornumber==4) hmUI.showToast({text: 'Do it! Bulbasaur!'});
         if(colornumber==5) hmUI.showToast({text: 'Go for it, Charizard!'});
         if(colornumber==6) hmUI.showToast({text: 'Go! Squirtle!'});
          normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
            
        }

// Start animation
   
       function before_anim() {
           if(colornumber==1) hmUI.showToast({text: "Pikachu used THUNDER!"});
           if(colornumber==5) hmUI.showToast({text: "Charizard used FLAMETHROWER!"}); 
           if(colornumber==2) hmUI.showToast({text: "Butterfree used SLEEP POWDER!"});
           if(colornumber==3) hmUI.showToast({text: "Pidgeot used GUST!"}); 
           if(colornumber==4) hmUI.showToast({text: "Bulbasaur used RAZOR LEAF!"});
           if(colornumber==6) hmUI.showToast({text: "Squirtle used WATER GUN!"}); 
           setTimeout(click_anim, 2000);

 }


        function click_anim() {
          if(lvlstep<stepsPercent) {
          
          if(colornumber==5) normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==5) normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==2) normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==2) normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==3) normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==3) normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);     
          if(colornumber==4) normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==4) normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);    
          if(colornumber==6) normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==6) normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==1) normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==1) normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
          lvlstep = Math.floor(lvlstep +0);
          
          
                          }
             else {
               
               if(lvlstep>stepsPercent) {
               lvlstep = 0;
               hmUI.showToast({text: "But, It failed !"});

                     }
              else {

         hmUI.showToast({text: "Get more steps !"});
                  
            }
         }              
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                   
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '233.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["231.png","232.png","233.png"],
              image_length: 3,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 264,
              y: 42,
              image_array: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png","215.png","216.png","217.png","218.png","219.png","220.png","221.png","223.png","224.png","225.png","226_Plan de travail 1.png","227_Plan de travail 1.png","228.png","229.png","230.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 208,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 350,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 149,
              minute_startY: 350,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 58,
              am_y: 348,
              am_sc_path: '23.png',
              am_en_path: '23.png',
              pm_x: 58,
              pm_y: 348,
              pm_sc_path: '24.png',
              pm_en_path: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 293,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: 0,
              unit_sc: '35.png',
              unit_tc: '35.png',
              unit_en: '35.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 400,
              y: 293,
              src: '36.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 281,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 142,
              y: 396,
              src: '48.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 397,
              src: '49.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 125,
              y: 145,
              week_en: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              week_tc: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              week_sc: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_text = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 263,
              y: 254,
              w: 150,
              h: 20,
              week_en: ["251.png","252.png","253.png","254.png","255.png","256.png","257.png"],
              week_tc: ["251.png","252.png","253.png","254.png","255.png","256.png","257.png"],
              week_sc: ["251.png","252.png","253.png","254.png","255.png","256.png","257.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


             
              stepsWidget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 254,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              text: stepsPercent,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


             steps.addEventListener(hmSensor.event.CHANGE, function stepsUpdate() {

			stepsPercent = Math.floor(steps.current / lvlcalc)
			stepsWidget.setProperty(hmUI.prop.TEXT, `${stepsPercent}`)
		})
		
             
            	
            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 317,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 366,
              image_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 396,
              font_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              padding: false,
              h_space: 1,
              unit_sc: '161.png',
              unit_tc: '161.png',
              unit_en: '161.png',
              negative_image: '159.png',
              invalid_image: '158.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 116,
              day_sc_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_tc_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_en_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 116,
              month_sc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_tc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_en_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '137.png',
              month_unit_tc: '137.png',
              month_unit_en: '137.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 94,
              year_startY: 116,
              year_sc_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_tc_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_en_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_zero: 1,
              year_space: 0,
              year_unit_sc: '126.png',
              year_unit_tc: '126.png',
              year_unit_en: '126.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: -68,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "fireattack",
              anim_fps: 11,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "gustattack",
              anim_fps: 13,
              anim_size: 11,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: -15,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "powderattack",
              anim_fps: 10,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "razorleafattack",
              anim_fps: 10,
              anim_size: 9,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: -24,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "watergunattack",
              anim_fps: 10,
              anim_size: 12,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
            normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 50,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "thunderattack",
              anim_fps: 10,
              anim_size: 13,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.STOP,
              anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_7 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 211,
              y: 334,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "second_anim",
              anim_fps: 1,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 347,
              hour_array: ["162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '172.png',
              hour_unit_tc: '172.png',
              hour_unit_en: '172.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 149,
              minute_startY: 347,
              minute_array: ["173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 58,
              am_y: 345,
              am_sc_path: '183.png',
              am_en_path: '183.png',
              pm_x: 58,
              pm_y: 345,
              pm_sc_path: '184.png',
              pm_en_path: '184.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 378,
              y: 253,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              data: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
             normal_background_bag_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 236,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 203,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 169,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 138,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 105,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
 
            image_level_text = hmUI.createWidget(hmUI.widget.IMG, {
              x: 393,
              y: 254,
              src: 'level.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 347,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '188.png',
              normal_src: '188.png',
              click_func: () => {
               click_background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 380,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '187.png',
              normal_src: '187.png',
              click_func: () => {
              click_run();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 347,
              w: 100,
              h: 40,
              text: '',
              press_src: '185.png',
              normal_src: '185.png',
              click_func: () => {
              before_anim();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
              Button_3.setProperty(hmUI.prop.VISIBLE, true); 
              // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 233,
              y: 380,
              w: 100,
              h: 40,
              text: '',
              press_src: '186.png',
              normal_src: '186.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
              Button_4.setProperty(hmUI.prop.VISIBLE, true);
              // end button

            Button_bag_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 330,
              w: 220,
              h: 78,
              text: '',
              press_src: 'close.png',
              normal_src: 'close.png',
            click_func: () => {
               click_background();
               hide();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 393,
              w: 40,
              h: 40,
              text: '',
              press_src: '',
              normal_src: '',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

if (cc == 0 ){
cc = 1

   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, true);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, true);
   image_top_img.setProperty(hmUI.prop.VISIBLE, true);
   image_level_text.setProperty(hmUI.prop.VISIBLE, true);
   Button_1.setProperty(hmUI.prop.VISIBLE, true);
   Button_2.setProperty(hmUI.prop.VISIBLE, true);
   Button_3.setProperty(hmUI.prop.VISIBLE, true);
   Button_4.setProperty(hmUI.prop.VISIBLE, true);
   Button_6.setProperty(hmUI.prop.VISIBLE, true);
   
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, false); 

}

           

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}