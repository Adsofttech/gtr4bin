﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'backG_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -245,
              second_startY: -45,
              second_array: ["Second_redline_0001.png","Second_redline_0002.png","Second_redline_0003.png","Second_redline_0004.png","Second_redline_0005.png","Second_redline_0006.png","Second_redline_0007.png","Second_redline_0008.png","Second_redline_0009.png","Second_redline_0010.png"],
              second_zero: 1,
              second_space: -387,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 0,
              src: 'Center_Grey_0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: -204,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 50,
              minute_startY: 153,
              minute_array: ["Minute_white_0001.png","Minute_white_0002.png","Minute_white_0003.png","Minute_white_0004.png","Minute_white_0005.png","Minute_white_0006.png","Minute_white_0007.png","Minute_white_0008.png","Minute_white_0009.png","Minute_white_0010.png"],
              minute_zero: 1,
              minute_space: -204,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 151,
              y: 348,
              src: 'Step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 344,
              font_array: ["Step_white_0001.png","Step_white_0002.png","Step_white_0003.png","Step_white_0004.png","Step_white_0005.png","Step_white_0006.png","Step_white_0007.png","Step_white_0008.png","Step_white_0009.png","Step_white_0010.png"],
              padding: false,
              h_space: -35,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 387,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 374,
              font_array: ["Step_white_0001.png","Step_white_0002.png","Step_white_0003.png","Step_white_0004.png","Step_white_0005.png","Step_white_0006.png","Step_white_0007.png","Step_white_0008.png","Step_white_0009.png","Step_white_0010.png"],
              padding: false,
              h_space: -35,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: -7,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 404,
              font_array: ["Step_white_0001.png","Step_white_0002.png","Step_white_0003.png","Step_white_0004.png","Step_white_0005.png","Step_white_0006.png","Step_white_0007.png","Step_white_0008.png","Step_white_0009.png","Step_white_0010.png"],
              padding: false,
              h_space: -35,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 417,
              image_array: ["Batt_icon_0001.png","Batt_icon_0002.png","Batt_icon_0003.png","Batt_icon_0004.png","Batt_icon_0005.png","Batt_icon_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: -45,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF040200',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 38,
              hour_array: ["Hour_white_0001.png","Hour_white_0002.png","Hour_white_0003.png","Hour_white_0004.png","Hour_white_0005.png","Hour_white_0006.png","Hour_white_0007.png","Hour_white_0008.png","Hour_white_0009.png","Hour_white_0010.png"],
              hour_zero: 1,
              hour_space: -204,
              hour_align: hmUI.align.LEFT,

              minute_startX: 50,
              minute_startY: 153,
              minute_array: ["Minute_white_0001.png","Minute_white_0002.png","Minute_white_0003.png","Minute_white_0004.png","Minute_white_0005.png","Minute_white_0006.png","Minute_white_0007.png","Minute_white_0008.png","Minute_white_0009.png","Minute_white_0010.png"],
              minute_zero: 1,
              minute_space: -204,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 404,
              font_array: ["Step_white_0001.png","Step_white_0002.png","Step_white_0003.png","Step_white_0004.png","Step_white_0005.png","Step_white_0006.png","Step_white_0007.png","Step_white_0008.png","Step_white_0009.png","Step_white_0010.png"],
              padding: false,
              h_space: -35,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -41,
              y: -43,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  