﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */


	//*******************************//
	//*								*//
	//*		MATT GTR4	 			*//
	//*		2023 © leXxiR 4pda		*//
	//*								*//
	//*******************************//
	



    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_fat_burning_icon_img = ''
        let normal_temperature_current_text_img = ''
		let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
		let normal_step_icon_img = ''
		let normal_heart_rate_icon_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''

		let mesh = ''
		let bg_fill = '';
		let bgColor = [0xbfff03, 0x00bef0, 0xeb212d, 0xff7800, 0xffd700];
		let colorIndex = 0;

		let activityL_icon = ''
		let activityR_icon = ''
		let activityL_text = []
		let activityR_text = []
		let activityL_index = 2;
		let activityR_index = 0;
		let activities = ['steps', 'dist', 'pulse', 'kcal'];
		let settingsScreen = ''
		let settings_btn;
		let longPress_Timer = null;
		let longPressDelay = 900;
		let checkBT;
		let switch_checkBT;
		let switch_hourlyVibro;
		let switch_randomColor;
		let randomColor = false;
		let everyHourVibro = false;
		
		var curAODmode;
		let AODmodes = ["пустой", "стандартный"];
		let AODmodeName = '';

		function checkConnection(check = true) {
			hmBle.removeListener;
			if (check){
				hmBle.addListener(function (status) {
					if(!status && checkBT) {
						hmUI.showToast({text: "Нет связи!!!"});
						vibro(9);
					}
					if(status && checkBT) {
						hmUI.showToast({text: "Снова на связи!"});
						vibro(0);
					}
				})			
			} 
		}

		function toggleСheckConnection() {
			checkBT = !checkBT;
			hmFS.SysProSetBool('nsw_checkBT', checkBT);
			vibro();
			checkConnection(checkBT);
			switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png'); 
        }

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

		function toggleEveryHourVibro() {
			everyHourVibro = !everyHourVibro;
			hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			vibro();
			switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 

        }

		function setEveryHourVibro() {
			curTime.addEventListener(curTime.event.MINUTEEND, function () {
					if (everyHourVibro && !(curTime.minute % 60)) vibro(27);
			});

        }

		function loadSettings() {
			if (hmFS.SysProGetInt('MATT_aod') === undefined) {
				curAODmode = 1;
				hmFS.SysProSetInt('MATT_aod', curAODmode);
			} else {
				curAODmode = hmFS.SysProGetInt('MATT_aod');
			}
			
			if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
				checkBT = false;
				hmFS.SysProSetBool('nsw_checkBT', checkBT);
			} else {
				checkBT = hmFS.SysProGetBool('nsw_checkBT');
			}
			
			if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
				everyHourVibro = false;
				hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			} else {
				everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
			}
			/*
			if (hmFS.SysProGetInt('MATT_colorIndex') === undefined) {
				colorIndex = 16;
				hmFS.SysProSetInt('MATT_colorIndex', colorIndex);
			} else {
				colorIndex = hmFS.SysProGetInt('MATT_colorIndex');
			}

			if (hmFS.SysProGetBool('MATT_randomColor') === undefined) {
				randomColor = false;
				hmFS.SysProSetBool('MATT_randomColor', randomColor);
			} else {
				randomColor = hmFS.SysProGetBool('MATT_randomColor');
			}
			*/
		}


		function changeBgColorRandom(random = false) {
			if(random) colorIndex = (colorIndex + randomInt(1, bgColor.length - 1)) % bgColor.length;
			else colorIndex = (colorIndex + 1) % bgColor.length;
			//hmFS.SysProSetInt('MATT_colorIndex', colorIndex);
			bg_fill.setProperty(hmUI.prop.MORE, { 
				x: 0,
				y: 0,
				w: 466,
				h: 466,
				radius: 233,
				color: bgColor[colorIndex],
			});
			sec_pointer.setProperty(hmUI.prop.SRC, `sec_pointer_${colorIndex}.png`);
		}

		function randomInt(min, max) {
		  let rand = min + Math.random() * (max + 1 - min);
		  return Math.floor(rand);
		}

		function toggleRandomColor() {
			randomColor = !randomColor;
			//hmFS.SysProSetBool('MATT_randomColor', randomColor);
			vibro();
			switch_randomColor.setProperty(hmUI.prop.SRC, randomColor ? 'slider_on.png' : 'slider_off.png'); 

        }

		let curTime = hmSensor.createSensor(hmSensor.id.TIME);
        // плавная секундная стрелка
        let second_centerX = 233;
        let second_centerY = 233;
        let second_posX = 26;
        let second_posY = 233;
        let secPointer_img = `sec_pointer_${colorIndex}.png`;
        let sec_pointer;
        let secPointer_timer = undefined;
        let secPointerAngle = 0;
        let animDelay = 0;
		let animRepeat = 1000;
        const deviceInfo = hmSetting.getDeviceInfo();

        function setSecPointerAnim(sec, animDuration) {
		  let secAnimProps = {
            anim_steps: [{
              anim_rate: 'linear',
              anim_duration: animDuration,
              anim_from: sec,
              anim_to: sec + (animDuration * 6 / 1000),
              anim_key: 'angle',
            }],
            anim_fps: 25,
            anim_auto_start: 1,
            anim_repeat: 1,
            anim_auto_destroy: 1,
          }
          sec_pointer.setProperty(hmUI.prop.ANIM, secAnimProps);
        }
	
        function setMeshAnim(sec, animDuration) {
		  let secAnimProps = {
            anim_steps: [{
              anim_rate: 'linear',
              anim_duration: animDuration,
              anim_from: sec,
              anim_to: sec - (animDuration * 6 / 1000),
              anim_key: 'angle',
            }],
            anim_fps: 25,
            anim_auto_start: 1,
            anim_repeat: 1,
            anim_auto_destroy: 1,
          }
		  mesh.setProperty(hmUI.prop.ANIM, secAnimProps);
        }	
		

        function startSecPointerAnim() {
			secPointerAngle = (curTime.second + (curTime.utc % 1000) / 1000) * 6;
			sec_pointer.setProperty(hmUI.prop.ANGLE, secPointerAngle);
			sec_pointer.setProperty(hmUI.prop.VISIBLE, true);
			setSecPointerAnim(secPointerAngle, animRepeat);
			secPointerAngle = 360 - secPointerAngle;
			mesh.setProperty(hmUI.prop.ANGLE, secPointerAngle);
			setMeshAnim(secPointerAngle, animRepeat);
			
			if (secPointer_timer) timer.stopTimer(secPointer_timer);
			animDelay = 1000 - curTime.utc % 1000;
			secPointer_timer = timer.createTimer(animDelay, animRepeat, (function (option) {
				secPointerAngle = (curTime.second + (curTime.utc % 1000) / 1000) * 6;
				setSecPointerAnim(secPointerAngle, animRepeat);
				secPointerAngle = 360 - secPointerAngle;
				setMeshAnim(secPointerAngle, animRepeat);
			}));
        }

        function stopSecPointerAnim() {
            sec_pointer.setProperty(hmUI.prop.VISIBLE, false);
			if (secPointer_timer) {
              timer.stopTimer(secPointer_timer);
              secPointer_timer = undefined;
            }
		}

		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			// время восхода
		let sunsetMins_def = 20 * 60;			// и заката по умолчанию
		let curMins = '';
		
		let isDayIcons = true;
		let wiReplacement = [0, 1, 2, 3];		// индексы иконок для замены день-ночь
		
		function autoToggleWeatherIcons() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
					}
					isDayIcons = true;
				}
			} else {
				if(isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
					}
					isDayIcons = false;
				}
			}
		}


		function toggleAODmode() {
			curAODmode = (curAODmode + 1) % AODmodes.length;
			hmFS.SysProSetInt('MATT_aod', curAODmode);
			vibro();
			AODmodeName.setProperty(hmUI.prop.TEXT, AODmodes[curAODmode]);
        }
	
		function createSettingsScreen() {

			settingsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
			settingsScreen.setProperty(hmUI.prop.VISIBLE, false);

            settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 466,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
			});
			
			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 60,
				w: 466,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКИ",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

 			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 115,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Режим AOD:",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			AODmodeName = settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 150,
				y: 155,
				w: 320,
				h: 64,
				text_size: 32,
				text: AODmodes[curAODmode],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});
			
			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 115,
              w: 340,
              h: 115,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleAODmode();
			});

            switch_checkBT = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 220,
              w: 60,
              h: 33,
              src: checkBT ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 205,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация при потере связи",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 210,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleСheckConnection();
			});


            switch_hourlyVibro = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 280,
              w: 60,
              h: 33,
              src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 265,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация в начале часа",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 270,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleEveryHourVibro();
			});

            switch_randomColor = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 340,
              w: 60,
              h: 33,
              src: randomColor ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 325,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Случайный цвет фона",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 330,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleRandomColor();
			});

		}

		function showSettingsScreen(value = true) {
			settingsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function openSettingsScreen() {
			if(longPress_Timer) timer.stopTimer(longPress_Timer);
			vibro();
			showSettingsScreen();
		}


		function makeAOD() {
			
			let mode = hmFS.SysProGetInt('MATT_aod');
			
			bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  radius: 233,
			  color: '0xFF000000',
			  show_level: hmUI.show_level.ONLY_AOD,
			});

			if (mode){			// стандартный

				idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  w: 466,
				  h: 466,
				  src: 'bg_aod.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
				  day_startX: 138,
				  day_startY: 54,
				  day_sc_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
				  day_tc_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
				  day_en_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
				  day_zero: 1,
				  day_space: 0,
				  day_align: hmUI.align.LEFT,
				  day_is_character: false,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
				  x: 218,
				  y: 54,
				  week_en: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
				  week_tc: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
				  week_sc: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 185,
				  y: 380,
				  font_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
				  padding: false,
				  h_space: 0,
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.BATTERY,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 224,
				  y: 306,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 126,
				  hour_startY: 200,
				  hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  hour_zero: 1,
				  hour_space: 3,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 246,
				  minute_startY: 200,
				  minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
				  minute_zero: 1,
				  minute_space: 3,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});
			}
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					stopVibro();
				}),
				pause_call: (function () {
					stopVibro();
				}),
			});	
			
			checkConnection(hmFS.SysProGetBool('nsw_checkBT'));
			setEveryHourVibro();
		}


		function showActivityScreen(index) {
			let url;
			vibro();

			switch(index) {
			   case 2:
					url = 'heart_app_Screen';
				break;
			   case 3:
					url = 'PAI_app_Screen';
				break;
			   default:
					url = 'activityAppScreen';
				break;
			}
			hmApp.startApp({ url: url, native: true });
		}

		function toggleActivityL() {
			activityL_index = (activityL_index + 1) % activities.length;
			if (activityL_index == activityR_index) activityL_index = (activityL_index + 1) % activities.length;
			vibro();
			activityL_icon.setProperty(hmUI.prop.SRC, `icoL_${activities[activityL_index]}.png`);
			setActivitiesTextVisibility();
        }

		function toggleActivityR() {
			activityR_index = (activityR_index + 1) % activities.length;
			if (activityR_index == activityL_index) activityR_index = (activityR_index + 1) % activities.length;
			vibro();
			activityR_icon.setProperty(hmUI.prop.SRC, `icoR_${activities[activityR_index]}.png`);
			setActivitiesTextVisibility();
        }

		function setActivitiesTextVisibility() {
			for (let i = 0; i < activities.length; i++) {
			  activityL_text[i].setProperty(hmUI.prop.VISIBLE, activityL_index == i);
			  activityR_text[i].setProperty(hmUI.prop.VISIBLE, activityR_index == i);
			}
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                
            bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
			  radius: 233,
              color: bgColor[colorIndex],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            mesh = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
			  w: 466,
			  h: 466,
			  pos_x: 0,
			  pos_y: 0,
			  center_x: second_centerX,
			  center_y: second_centerY,
              src: 'mesh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 41,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityL_icon = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 291,
              src: 'icoL_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityR_icon = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 291,
              src: 'icoR_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 223,
              font_array: ["dig_sec_0.png","dig_sec_1.png","dig_sec_2.png","dig_sec_3.png","dig_sec_4.png","dig_sec_5.png","dig_sec_6.png","dig_sec_7.png","dig_sec_8.png","dig_sec_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_sec_deg.png',
              unit_tc: 'dig_sec_deg.png',
              unit_en: 'dig_sec_deg.png',
              negative_image: 'dig_sec_minus.png',
              invalid_image: 'dig_sec_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityL_text[0] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            activityL_text[1] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
			  dot_image: 'dig_act_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			activityL_text[2] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityL_text[3] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityR_text[0] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            activityR_text[1] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
			  dot_image: 'dig_act_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			activityR_text[2] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            activityR_text[3] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 306,
              font_array: ["dig_act_0.png","dig_act_1.png","dig_act_2.png","dig_act_3.png","dig_act_4.png","dig_act_5.png","dig_act_6.png","dig_act_7.png","dig_act_8.png","dig_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			setActivitiesTextVisibility();

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 138,
              day_startY: 54,
              day_sc_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
              day_tc_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
              day_en_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 218,
              y: 54,
              week_en: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
              week_tc: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
              week_sc: ["days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 380,
              font_array: ["dig_date_0.png","dig_date_1.png","dig_date_2.png","dig_date_3.png","dig_date_4.png","dig_date_5.png","dig_date_6.png","dig_date_7.png","dig_date_8.png","dig_date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 354,
              y: 219,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 200,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 200,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 391,
              second_startY: 223,
              second_array: ["dig_sec_0.png","dig_sec_1.png","dig_sec_2.png","dig_sec_3.png","dig_sec_4.png","dig_sec_5.png","dig_sec_6.png","dig_sec_7.png","dig_sec_8.png","dig_sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  w: deviceInfo.width,
			  h: deviceInfo.height,
			  pos_x: second_centerX - second_posX,
			  pos_y: second_centerY - second_posY,
			  center_x: second_centerX,
			  center_y: second_centerY,
			  src: secPointer_img,
			  angle: 0,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 1,
              y: 165,
              w: 100,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 199,
              w: 100,
              h: 70,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 290,
              w: 100,
              h: 60,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showActivityScreen(activityL_index);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 295,
              w: 75,
              h: 75,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				toggleActivityL();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 290,
              w: 100,
              h: 60,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showActivityScreen(activityR_index);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 295,
              w: 75,
              h: 75,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				toggleActivityR();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			settings_btn = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 410,
              w: 100,
              h: 60,
			  src: 'blank.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			settings_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				longPress_Timer = timer.createTimer(longPressDelay, 0, openSettingsScreen, {});
			});
			settings_btn.addEventListener(hmUI.event.CLICK_UP, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				changeBgColorRandom(randomColor);
				vibro();
			});
			
			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 0,
              w: 190,
              h: 100,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			createSettingsScreen();
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: (function () {
				stopVibro();
				startSecPointerAnim();
				if (randomColor) changeBgColorRandom(true);
				checkConnection(checkBT);
				setEveryHourVibro();
				autoToggleWeatherIcons();
			  }),
			  pause_call: (function () {
				stopVibro();
				stopSecPointerAnim();
			  }),
			});

                //dynamic modify end
            },
            onInit() {
				loadSettings();
                n.log("index page.js on init invoke")
            },
            build() {
				if (hmSetting.getScreenType() == hmSetting.screen_type.AOD){
					makeAOD();
				} else {
					this.init_view();
				}
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
