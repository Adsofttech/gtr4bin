﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fundo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 408,
              image_array: ["033.png","034.png","035.png","036.png","037.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 308,
              y: 357,
              week_en: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png"],
              week_tc: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png"],
              week_sc: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 313,
              day_startY: 380,
              day_sc_array: ["023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png"],
              day_tc_array: ["023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png"],
              day_en_array: ["023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Min_1.png',
              hour_centerX: 228,
              hour_centerY: 185,
              hour_posX: 15,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hr_1.png',
              minute_centerX: 228,
              minute_centerY: 185,
              minute_posX: 15,
              minute_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 112,
              hour_startY: 358,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 358,
              minute_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 242,
              second_startY: 358,
              second_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 370,
              src: 'ponto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 370,
              src: 'ponto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fundo-2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 408,
              image_array: ["033.png","034.png","035.png","036.png","037.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 308,
              y: 357,
              week_en: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png"],
              week_tc: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png"],
              week_sc: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 313,
              day_startY: 380,
              day_sc_array: ["069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png"],
              day_tc_array: ["069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png"],
              day_en_array: ["069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr2.png',
              hour_centerX: 228,
              hour_centerY: 185,
              hour_posX: 15,
              hour_posY: 139,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_2.png',
              minute_centerX: 228,
              minute_centerY: 185,
              minute_posX: 15,
              minute_posY: 138,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 112,
              hour_startY: 358,
              hour_array: ["045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png","053.png","054.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 358,
              minute_array: ["045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png","053.png","054.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 242,
              second_startY: 358,
              second_array: ["045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png","053.png","054.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 370,
              src: 'ponto_2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 370,
              src: 'ponto_2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  