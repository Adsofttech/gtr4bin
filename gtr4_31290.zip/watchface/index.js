﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -23,
              y: -20,
              src: 'Picture83.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 427,
              image_array: ["batt_comple_blac_0001.png","batt_comple_blac_0002.png","batt_comple_blac_0003.png","batt_comple_blac_0004.png","batt_comple_blac_0005.png","batt_comple_blac_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 25,
              am_y: 287,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 25,
              pm_y: 287,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: -27,
              hour_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              hour_zero: 1,
              hour_space: -70,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 82,
              minute_startY: 124,
              minute_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              minute_zero: 1,
              minute_space: -70,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 352,
              second_startY: 150,
              second_array: ["seccomple_blac_0001.png","seccomple_blac_0002.png","seccomple_blac_0003.png","seccomple_blac_0004.png","seccomple_blac_0005.png","seccomple_blac_0006.png","seccomple_blac_0007.png","seccomple_blac_0008.png","seccomple_blac_0009.png","seccomple_blac_0010.png"],
              second_zero: 1,
              second_space: -56,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: -5,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -23,
              y: -20,
              src: 'Picture83.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 427,
              image_array: ["batt_comple_blac_0001.png","batt_comple_blac_0002.png","batt_comple_blac_0003.png","batt_comple_blac_0004.png","batt_comple_blac_0005.png","batt_comple_blac_0006.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: -27,
              hour_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              hour_zero: 1,
              hour_space: -70,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 82,
              minute_startY: 124,
              minute_array: ["comple_blac_0001.png","comple_blac_0002.png","comple_blac_0003.png","comple_blac_0004.png","comple_blac_0005.png","comple_blac_0006.png","comple_blac_0007.png","comple_blac_0008.png","comple_blac_0009.png","comple_blac_0010.png"],
              minute_zero: 1,
              minute_space: -70,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: -24,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  