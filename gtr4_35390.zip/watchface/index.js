﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */
    // import { Barometer } from '@zos/sensor'

    try {
     (() => {

      const {
       beforeModuleCreate = () => {}, afterModuleCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforeModuleCreate()

      const {
       beforePageCreate = () => {}, afterPageCreate = () => {}
      } = DeviceRuntimeCore.LifeCycle
      beforePageCreate()
      const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__

       //dynamic modify start

       ! function (context) {
        with(context) {

         const hmUI = __$$R$$__('@zos/ui');
         const hmSensor = __$$R$$__('@zos/sensor');
         const hmScene = __$$R$$__('@zos/app');
         const hmRouter = __$$R$$__('@zos/router');
         const hmDevice = __$$R$$__('@zos/device');
         const hmBle = __$$R$$__('@zos/ble');
         const hmStorage = __$$R$$__('@zos/storage');

         const gettext = console.log;
         const barometer = new hmSensor.Barometer();
         const altitude = barometer.getAltitude();
         let airPressure = barometer.getAirPressure() * 0.750064;
         const {
          width: DEVICE_WIDTH,
          height: DEVICE_HEIGHT
         } = hmDevice.getDeviceInfo();


         // const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
         const battery = new hmSensor.Battery();
         const distance = new hmSensor.Distance();
         const calorie = new hmSensor.Calorie();
         const step = new hmSensor.Step();
         const pai = new hmSensor.Pai()

         //const total = pai.getTotal()
         //const today = pai.getToday()
         //const lastWeek = pai.getLastWeek()			

         const heart = new hmSensor.HeartRate();


         const curTime = new hmSensor.Time();
         let MonthClok = curTime.getMonth();

         const weather = new hmSensor.Weather();
         let weatherData = weather.getForecast();
         let forecastData = weatherData.forecastData;


         let normal_background_bg_img = ''
         let normal_heart_rate_TextCircle = new Array(3);
         let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
         let normal_heart_rate_TextCircle_img_width = 20;
         let normal_heart_rate_TextCircle_img_height = 29;
         let normal_heart_rate_image_progress_img_level = ''
         let normal_calorie_pointer_progress_img_pointer = ''
         let normal_calorie_TextCircle = new Array(4);
         let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
         let normal_calorie_TextCircle_img_width = 20;
         let normal_calorie_TextCircle_img_height = 29;
         let normal_battery_pointer_progress_img_pointer = ''
         let normal_battery_TextCircle = new Array(3);
         let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
         let normal_battery_TextCircle_img_width = 20;
         let normal_battery_TextCircle_img_height = 29;
         let normal_step_pointer_progress_img_pointer = ''
         let normal_step_TextCircle = new Array(5);
         let normal_step_TextCircle_ASCIIARRAY = new Array(10);
         let normal_step_TextCircle_img_width = 20;
         let normal_step_TextCircle_img_height = 29;
         let normal_ALTIMETER_TextCircle = new Array(3);
         let normal_ALTIMETER_TextCircle_ASCIIARRAY = new Array(10);
         let normal_ALTIMETER_TextCircle_img_width = 20;
         let normal_ALTIMETER_TextCircle_img_height = 29;
         let normal_image_img = ''
         let normal_digital_clock_img_time = ''
         let normal_date_img_date_month_img = ''
         let normal_date_img_date_day = ''
         let normal_temperature_current_text_img = ''
         let normal_weather_image_progress_img_level = ''
         let normal_date_img_date_week_img = ''
         let normal_sun_current_text_img = ''
         let normal_system_disconnect_img = ''
         let normal_system_clock_img = ''
         let idle_background_bg = ''
         let idle_battery_pointer_progress_img_pointer = ''
         let idle_battery_text_text_img = ''
         let idle_digital_clock_img_time = ''
         let idle_date_img_date_month_img = ''
         let idle_date_img_date_day = ''
         let idle_date_img_date_week_img = ''
         let idle_sun_current_text_img = ''
         let idle_system_disconnect_img = ''
         let idle_system_clock_img = ''

         let normal_high_TextCircle = new Array(4);
         let normal_high_TextCircle_ASCIIARRAY = new Array(10);
         let normal_high_TextCircle_img_width = 20;
         let normal_high_TextCircle_img_height = 29;
         let normal_high_TextCircle_unit = null;
         let normal_high_TextCircle_unit_width = 20;
         let normal_high_TextCircle_dot_width = 20;
         let normal_high_TextCircle_error_img_width = 20;
         let normal_low_TextCircle = new Array(4);
         let normal_low_TextCircle_ASCIIARRAY = new Array(10);
         let normal_low_TextCircle_img_width = 20;
         let normal_low_TextCircle_img_height = 29;
         let normal_low_TextCircle_unit = null;
         let normal_low_TextCircle_unit_width = 20;
         let normal_low_TextCircle_dot_width = 20;
         let normal_low_TextCircle_error_img_width = 20;
         let normal_sunrise_TextCircle = new Array(5);
         let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
         let normal_sunrise_TextCircle_img_width = 20;
         let normal_sunrise_TextCircle_img_height = 29;
         let normal_sunrise_TextCircle_dot_width = 8;
         let normal_sunset_TextCircle = new Array(5);
         let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
         let normal_sunset_TextCircle_img_width = 20;
         let normal_sunset_TextCircle_img_height = 29;
         let normal_sunset_TextCircle_dot_width = 8;

         let normal_wind_pointer_progress_img_pointer = ''
         let normal_wind_text_text_img = ''
         let normal_wind_direction_image_progress_img_level = ''
         let normal_sun_pointer_progress_img_pointer = ''

         let normal_uvi_pointer_progress_img_pointer = ''
         let normal_uvi_text_text_img = ''
         let normal_humidity_pointer_progress_img_pointer = ''
         let normal_humidity_text_text_img = ''

         let normal_distance_pointer_progress_img_pointer = ''
         let normal_distance_TextCircle = new Array(5);
         let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
         let normal_distance_TextCircle_img_width = 20;
         let normal_distance_TextCircle_img_height = 29;
         let normal_distance_TextCircle_dot_width = 9;
         let normal_pai_pointer_progress_img_pointer = ''
         let normal_pai_total_TextCircle = new Array(3);
         let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
         let normal_pai_total_TextCircle_img_width = 20;
         let normal_pai_total_TextCircle_img_height = 29;
			
         let flag_btn_on = 0;
			
         function blok_btn_on() {
          flag_btn_on = 1;
          hmStorage.localStorage.setItem('DFCF_color_flag_btn_on', flag_btn_on);
			 
          btn_zona.setProperty(hmUI.prop.VISIBLE, false);
          btn_str.setProperty(hmUI.prop.VISIBLE, false);
          btn_tap.setProperty(hmUI.prop.VISIBLE, false);
          btn_HourVibro.setProperty(hmUI.prop.VISIBLE, false);
          btn_checkBT.setProperty(hmUI.prop.VISIBLE, false);
          btn_blok_off.setProperty(hmUI.prop.VISIBLE, true);
			 
			 
		  blok_img.setProperty(hmUI.prop.SRC, flag_btn_on == 0 ? 'ic_blok_off.png' : 'ic_blok.png');   
          hmUI.showToast({
           text: "Все кнопки заблокированы!!!"
          });
         }
			
         function blok_btn_off() {
          flag_btn_on = 0;
          hmStorage.localStorage.setItem('DFCF_color_flag_btn_on', flag_btn_on);
			 
          btn_zona.setProperty(hmUI.prop.VISIBLE, true);
          btn_str.setProperty(hmUI.prop.VISIBLE, true);
          btn_tap.setProperty(hmUI.prop.VISIBLE, true);
          btn_HourVibro.setProperty(hmUI.prop.VISIBLE, true);
          btn_checkBT.setProperty(hmUI.prop.VISIBLE, true);
          btn_blok_off.setProperty(hmUI.prop.VISIBLE, false);
			 
		  blok_img.setProperty(hmUI.prop.SRC, flag_btn_on == 0 ? 'ic_blok_off.png' : 'ic_blok.png');           

          hmUI.showToast({
           text: "Кнопки разблокированы"
          });
         }
         function menu_tip_AOD() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, true);
         }

         function tip_AOD_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);
         }

         var curAODmode = 1;

         function select_tip_AOD() {
          AOD_tip_0.setProperty(hmUI.prop.MORE, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           color: curAODmode == 0 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          AOD_tip_1.setProperty(hmUI.prop.MORE, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           color: curAODmode == 1 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

         }


         function loadSettings() {
          flag_btn_on = hmStorage.localStorage.getItem('DFCF_color_flag_btn_on', 0);          curAODmode = hmStorage.localStorage.getItem('DFCF_color_aod', 1);
          everyHourVibro = hmStorage.localStorage.getItem('DFCF_color_hourlyVibro', false);
          checkBT = hmStorage.localStorage.getItem('DFCF_color_checkBT', false);
         }

         function saveSettings() {
			hmStorage.localStorage.setItem('DFCF_color_flag_btn_on', 0);          hmStorage.localStorage.setItem('DFCF_color_hourlyVibro', false);
          hmStorage.localStorage.setItem('DFCF_color_checkBT', false);
         }


         let checkBT = false;
         let switch_checkBT;
         let checkBT_interval = ''
         let statusBT_last = ''

         function checkConnection(check = true) {
          if (check) {
           checkBT_interval = setInterval(() => {
            let statusBT = hmBle.connectStatus();
            if (statusBT != statusBT_last) {
             statusBT_last = statusBT;
             if (!statusBT) {
              hmUI.showToast({
               text: "Нет связи!!!"
              });
              vibroTimes(5); //9
             } else {
              hmUI.showToast({
               text: "Снова на связи!"
              });
              vibroTimes(3); //0
             }
            }
           }, 3000);
          } else {
           if (checkBT_interval) clearInterval(checkBT_interval);
          }
         }

         function toggleСheckConnection() {
          checkBT = !checkBT;

          hmStorage.localStorage.setItem('DFCF_color_checkBT', checkBT);
          //vibro();
          checkConnection(checkBT);
          switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png');
         }


         let everyHourVibro = false;

         function toggleEveryHourVibro() {
          everyHourVibro = !everyHourVibro;
          hmStorage.localStorage.setItem('DFCF_color_hourlyVibro', everyHourVibro);
          vibro();
          switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png');
         }

         function setEveryHourVibro() {
          curTime.onPerMinute(() => {
           if (everyHourVibro && !(curTime.getMinutes() % 60)) vibro(); //27
          })
         }

         let timesRemain = 0;
         let vibroTimes_interval = '';

         function vibroTimes(num = 1) {
          timesRemain = num;
          vibroTimes_interval = setInterval(() => {
           //vibrate.stop();
           //vibrate.start(25);
           vibro();
           timesRemain--;
           if (!timesRemain && vibroTimes_interval) {
            clearInterval(vibroTimes_interval);
            //vibrate.stop();
           }
          }, 150);
         }


         let zona = 0

         function click_zona() {
          zona = (zona + 1) % 3;


          //text_update();

          //hmFS.SysProSetInt('vienna_in_time_dig_up_set', dig_up_set);

          normal_image_img_1.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 0);
          normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 0);

          for (let i = 0; i < 5; i++) {
           normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 0);

           normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 1);
           normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 1);
           normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 2);

          };

          for (let i = 0; i < 3; i++) {
           normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 0);
           normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 0);

           normal_ALTIMETER_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 1);
             normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 2);
          };

          for (let i = 0; i < 4; i++) {
           normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 0);
           normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 1);
           normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, zona == 1);
          };


          normal_image_img_2.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_ALTIMETER_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 1);
          normal_step_WEATHER_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 1);

          normal_image_img_3.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_distance_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 2);
          normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, zona == 2);
          //normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, zona == 2);			  


          //text_update();
         }


         function click_Pogoda_on() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }


         let vibrate = new hmSensor.Vibrator();
         let stopVibro_Timer = null;


         function vibro(mode = 25) {
          let stopDelay = 25;
          vibrate.stop();
          //vibrate.setMode(mode);
          vibrate.start(mode);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
          stopVibro_Timer = setTimeout(() => {
           stopVibro();
          }, stopDelay);
         }

         function stopVibro() {
          vibrate.stop();
          //timer.stopTimer(stopVibro_Timer);
          if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
         }


         let apps = [
          ['Нет действия', '-', `tap/i_tap_pusto.png`],
          ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`],
          ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`],
          ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`],
          ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`],
          ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`],
          ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`],
          ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`],
          ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`],
          ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`],
          ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`],
          ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`],
          ['Музыка', 'PhoneMusicCtrlScreen', `tap/i_tap_musik.png`],
          ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`],
          ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`],
          ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`],
          ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`],
          ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`],
          ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`],
          ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`],
          ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`],
          ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`],
          ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`],
          ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`],
          ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`],
          ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`],
          ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`],
          ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`],
          ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`],
          ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`]
         ];


         const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: 171,
          y: 20,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 19,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 150 - 20,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: 301,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 20,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })


         let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)


         const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: 301,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 24,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 266 - 301,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: 171,
          y: 321,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 11,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 135 - 171,
          tips_y: 257 - 321,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 105,
          x: 40,
          y: 246,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 184 - 246,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_5_select = tap_5_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 106,
          x: 40,
          y: 95,
          w: 124,
          h: 124,
          select_image: 'tap/edit_red_1.png',
          un_select_image: 'tap/edit_griin_1.png',
          default_type: 0,
          optional_types: [{
           type: 0,
           preview: apps[0][2],
           title_en: apps[0][0]
          }, {
           type: 1,
           preview: apps[1][2],
           title_en: apps[1][0]
          }, {
           type: 2,
           preview: apps[2][2],
           title_en: apps[2][0]
          }, {
           type: 3,
           preview: apps[3][2],
           title_en: apps[3][0]
          }, {
           type: 4,
           preview: apps[4][2],
           title_en: apps[4][0]
          }, {
           type: 5,
           preview: apps[5][2],
           title_en: apps[5][0]
          }, {
           type: 6,
           preview: apps[6][2],
           title_en: apps[6][0]
          }, {
           type: 7,
           preview: apps[7][2],
           title_en: apps[7][0]
          }, {
           type: 8,
           preview: apps[8][2],
           title_en: apps[8][0]
          }, {
           type: 9,
           preview: apps[9][2],
           title_en: apps[9][0]
          }, {
           type: 10,
           preview: apps[10][2],
           title_en: apps[10][0]
          }, {
           type: 11,
           preview: apps[11][2],
           title_en: apps[11][0]
          }, {
           type: 12,
           preview: apps[12][2],
           title_en: apps[12][0]
          }, {
           type: 13,
           preview: apps[13][2],
           title_en: apps[13][0]
          }, {
           type: 14,
           preview: apps[14][2],
           title_en: apps[14][0]
          }, {
           type: 15,
           preview: apps[15][2],
           title_en: apps[15][0]
          }, {
           type: 16,
           preview: apps[16][2],
           title_en: apps[16][0]
          }, {
           type: 17,
           preview: apps[17][2],
           title_en: apps[17][0]
          }, {
           type: 18,
           preview: apps[18][2],
           title_en: apps[18][0]
          }, {
           type: 19,
           preview: apps[19][2],
           title_en: apps[19][0]
          }, {
           type: 20,
           preview: apps[20][2],
           title_en: apps[20][0]
          }, {
           type: 21,
           preview: apps[21][2],
           title_en: apps[21][0]
          }, {
           type: 22,
           preview: apps[22][2],
           title_en: apps[22][0]
          }, {
           type: 23,
           preview: apps[23][2],
           title_en: apps[23][0]
          }, {
           type: 24,
           preview: apps[24][2],
           title_en: apps[24][0]
          }, {
           type: 25,
           preview: apps[25][2],
           title_en: apps[25][0]
          }, {
           type: 26,
           preview: apps[26][2],
           title_en: apps[26][0]
          }, {
           type: 27,
           preview: apps[27][2],
           title_en: apps[27][0]
          }, {
           type: 28,
           preview: apps[28][2],
           title_en: apps[28][0]
          }, {
           type: 29,
           preview: apps[29][2],
           title_en: apps[29][0]
          }, ],
          count: 30,
          tips_x: 5 - 40,
          tips_y: 225 - 95,
          tips_width: 195,
          tips_margin: 10,
          tips_BG: 'tap/tips_bg.png'
         })

         let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

         let btn_tap = ''
         let btn_click_tap_exit = ''

         let btn_Tap_zona_0 = ''
         let btn_Tap_zona_1 = ''
         let btn_Tap_zona_2 = ''
         let btn_Tap_zona_3 = ''
         let btn_Tap_zona_4 = ''
         let btn_Tap_zona_5 = ''

         function tap_zona_exit() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
         }

         let tap_x_y = [
          [178, 26, 1],
          [308, 102, 1],
          [308, 253, 1],
          [178, 328, 0],
          [47, 253, 0],
          [47, 102, 0]
         ];

         function tap_run() {
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, true);
         }


         //	---------------------------------------------------------		

         //переменные для ргафика
         let weatherArrayGrafik = [] //есть
         let weatherIconImgArrayGrafik = [] //есть
         let weatherTxtImgArray = []
         let weatherTxtImgArrayN = []
         let pointred = new Array(6);
         let pointblue = new Array(5);
         let linered = new Array(6);
         let lineblue = new Array(5);
         let yArrH = new Array(6);
         let yArrL = new Array(5);
         let y_pogodaH = new Array(6);
         let y_pogodaL = new Array(5);
         let week_weater = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
         let week_weater_img = []
         let day_weater_img = []
         const ROOTPATH = "images/"

         let normal_city_name_text = ''


         //-------------------------------- 

         //массив иконок для графика       
         for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
         }


         //обновление для   графика           
         function updateGrafik() {

          const weather = new hmSensor.Weather();
          let weatherData = weather.getForecast();
          let forecastData = weatherData.forecastData;

          //normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);


          if (forecastData.count == 0) {
           for (let i = 0; i < 6; i++) {
            var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
           }
          } else {
           let weekDay = curTime.getDay() - 1;
           for (let i = 0; i < 6; i++) {
            yArrH[i] = forecastData.data[i].high;
            let element = forecastData.data[i];
            let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
            // let date = new Date(curTime.utc + 86400000 * i);
            let date = new Date(curTime.getTime() + 86400000 * i);
            let data = date.getDate();
            let week = week_weater[weekDay];
            week_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: week,
            });
            day_weater_img[i].setProperty(hmUI.prop.MORE, {
             color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
             text: data,
            });
            weekDay = (weekDay + 1) % 7;
           }
          }


          for (let i = 0; i < 5; i++) {
           yArrL[i] = forecastData.data[i].low;
          }
          let maxH = Math.max(...yArrH)
          let maxL = Math.min(...yArrL)
          var shag = 46;
          var x0 = 119;
          for (let i = 0; i < 6; i++) {
           pointred[i].setProperty(hmUI.prop.MORE, {
            x: 119 + shag * [i] - 5,
            y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFFFF0000,
            line_width: 10,
           });
          };

          for (let i = 0; i < 5; i++) {
           yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            linered[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i,
             h: 466,
             pos_x: -31 + shag * i,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_red.png',
            });
          };
          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 4; i++) {
           yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            lineblue[i].setProperty(hmUI.prop.MORE, {
             x: 0,
             y: 0,
             w: 164 + shag * i + 23,
             h: 466,
             pos_x: -31 + shag * i + 23,
             pos_y: yyyyy1 + 2,
             center_x: 119 + shag * i + 23,
             center_y: yyyyy1,
             angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
             src: ROOTPATH + 'Grafik/line_blue.png',
            });
          };

          for (let i = 0; i < 5; i++) {
           pointblue[i].setProperty(hmUI.prop.MORE, {
            x: 119 + 23 + shag * [i] - 5,
            y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
            w: 10,
            h: 10,
            start_angle: -90,
            end_angle: 270,
            color: 0xFF00eaff,
            line_width: 10,
           });
          };

          for (let i = 0; i < 6; i++) {
           y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
           weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + i * 45 * 1.02,
            y: y_pogodaH[i] - 38, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrH[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }

          for (let i = 0; i < 5; i++) {
           y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
           weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
            x: 96 - 5 + 23 + i * 45 * 1.02,
            y: y_pogodaL[i] - 1, //120-7
            w: 50,
            h: 40,
            color: "0xFFffffff",
            text_size: 27,
            text: yArrL[i],
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });
          }
         }


         function makeAOD() {
          statusBT_last = hmBle.connectStatus();

          hmUI.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: '0xFF000000',
           show_level: hmUI.show_level.ONLY_AOD,
          });

          if (curAODmode == 1) {

           idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            color: '0xFF000000',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           //            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           //              src: 'str_progress_down.png',
           //              center_x: 233,
           //              center_y: 233,
           //              x: 100,
           //              y: 233,
           //              start_angle: 135,
           //              end_angle: 90,
           //              type: hmUI.data_type.BATTERY,
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });


           idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 184,
            y: 333,
            font_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            padding: false,
            h_space: 1,
            unit_sc: 'dig_a_pro.png',
            unit_tc: 'dig_a_pro.png',
            unit_en: 'dig_a_pro.png',
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 22,
            y: 203,
            src: 'ic_aod.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_startX: 112,
            hour_startY: 184,
            hour_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
            hour_zero: 1,
            hour_space: 8,
            hour_angle: 0,
            hour_align: hmUI.align.CENTER_H,

            minute_startX: 256,
            minute_startY: 184,
            minute_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
            minute_zero: 1,
            minute_space: 8,
            minute_angle: 0,
            minute_follow: 0,
            minute_align: hmUI.align.CENTER_H,

            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 159,
            month_startY: 144,
            month_sc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_tc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_en_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
            month_is_character: true,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            day_startX: 209,
            day_startY: 100,
            day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
            day_zero: 1,
            day_space: 3,
            day_align: hmUI.align.LEFT,
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 124,
            y: 283,
            week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
            show_level: hmUI.show_level.ONLY_AOD,
           });

           //            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           //              x: 18,
           //              y: 230,
           //              font_array: ["dig_b_0.png","dig_b_1.png","dig_b_2.png","dig_b_3.png","dig_b_4.png","dig_b_5.png","dig_b_6.png","dig_b_7.png","dig_b_8.png","dig_b_9.png"],
           //              padding: false,
           //              h_space: 0,
           //              invalid_image: 'dig_b_p.png',
           //              dot_image: 'dig_b_dot2.png',
           //              align_h: hmUI.align.CENTER_H,
           //              type: hmUI.data_type.SUN_CURRENT,
           //              show_level: hmUI.show_level.ONLY_AOD,
           //            });

           idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 389,
            y: 210,
            src: 'status_B.png',
            type: hmUI.system_status.DISCONNECT,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 20,
            y: 201,
            src: 'status_H.png',
            type: hmUI.system_status.CLOCK,
            show_level: hmUI.show_level.ONLY_AOD,
           });

           idle_normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 18,
            y: 230,
            font_array: ["dig_b_0.png", "dig_b_1.png", "dig_b_2.png", "dig_b_3.png", "dig_b_4.png", "dig_b_5.png", "dig_b_6.png", "dig_b_7.png", "dig_b_8.png", "dig_b_9.png"],
            padding: false,
            h_space: 0,
            invalid_image: 'dig_b_p.png',
            dot_image: 'dig_b_dot2.png',
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.ALARM_CLOCK,
            show_level: hmUI.show_level.ONLY_AOD,
           });

            blok_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 213,
              src: flag_btn_on == 0 ? 'ic_blok_off.png' : 'ic_blok.png', 
              show_level: hmUI.show_level.ONLY_AOD,
            });

			  

           switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
            x: 36,
            y: 201,
            src: checkBT ? 'slider_on.png' : 'slider_off.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

           switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
            x: 385,
            y: 216,
            src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
            show_level: hmUI.show_level.ONLY_AOD,
           });

          }


          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {

            stopVibro();
           }),
           pause_call: (function () {
            stopVibro();
           }),
          });

          checkConnection(checkBT);
          setEveryHourVibro();

         }


         //dynamic modify end

         function init_view() {
          //dynamic modify start
          if (hmStorage.localStorage.getItem('DFCF_color_init') != true) {
           saveSettings();
          }
          loadSettings();

          normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: '0000.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
          // circle_center_X: 233,
          // circle_center_Y: 233,
          // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          // radius: 178,
          // angle: -133,
          // char_space_angle: 2,
          // zero: false,
          // reverse_direction: true,
          // unit_in_alignment: true,
          // vertical_alignment: CENTER_V,
          // horizontal_alignment: CENTER_H,
          // type: hmUI.data_type.HEART,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 3; i++) {
           normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_heart_rate_TextCircle_img_width / 2,
            pos_y: 233 + 164,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block

          //            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
          //            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
          //              text_update();
          //            });

          function toDegree(radian) {
           return radian * (180 / Math.PI);
          };

          normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 21,
           y: 317,
           image_array: ["puls_pr_0.png", "puls_pr_1.png", "puls_pr_2.png", "puls_pr_3.png", "puls_pr_4.png", "puls_pr_5.png"],
           image_length: 6,
           type: hmUI.data_type.HEART,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 232,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 90,
           end_angle: 135,
           type: hmUI.data_type.CAL,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
          // circle_center_X: 233,
          // circle_center_Y: 233,
          // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          // radius: 178,
          // angle: 44,
          // char_space_angle: 2,
          // zero: false,
          // reverse_direction: false,
          // unit_in_alignment: true,
          // vertical_alignment: CENTER_V,
          // horizontal_alignment: CENTER_H,
          // type: hmUI.data_type.CAL,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          normal_calorie_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_calorie_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 4; i++) {
           normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_calorie_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block

          //            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
          //            calorie.addEventListener(hmSensor.event.CHANGE, function() {
          //              text_update();
          //            });

          normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress_down.png',
           center_x: 233,
           center_y: 233,
           x: 100,
           y: 233,
           start_angle: 135,
           end_angle: 90,
           type: hmUI.data_type.BATTERY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
          // circle_center_X: 233,
          // circle_center_Y: 233,
          // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          // radius: 178,
          // angle: 136,
          // char_space_angle: 2,
          // zero: false,
          // reverse_direction: true,
          // unit_in_alignment: true,
          // vertical_alignment: CENTER_V,
          // horizontal_alignment: CENTER_H,
          // type: hmUI.data_type.BATTERY,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          normal_battery_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_battery_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 3; i++) {
           normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_battery_TextCircle_img_width / 2,
            pos_y: 233 + 164,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block

          //            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
          //            battery.addEventListener(hmSensor.event.CHANGE, function() {
          //              text_update();
          //            });

          normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 233,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 0,
           end_angle: 45,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_distance_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_distance_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_distance_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          normal_distance_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 233,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 0,
           end_angle: 45,
           type: hmUI.data_type.STEP,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 232,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 90,
           end_angle: 135,
           type: hmUI.data_type.PAI_DAILY,//PAI_DAILY PAI_WEEKLY
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          //              x: 297,
          //              y: 66,
          //              font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          //              padding: false,
          //              h_space: 0,
          //              angle: 45,
          //              align_h: hmUI.align.LEFT,
          //              type: hmUI.data_type.PAI_DAILY,
          //              show_level: hmUI.show_level.ONLY_NORMAL,
          //            });


          normal_step_WEATHER_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 233,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 0,
           end_angle: 45,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
          // circle_center_X: 233,
          // circle_center_Y: 233,
          // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
          // radius: 178,
          // angle: -45,
          // char_space_angle: 2,
          // zero: false,
          // reverse_direction: false,
          // unit_in_alignment: true,
          // vertical_alignment: CENTER_V,
          // horizontal_alignment: CENTER_H,
          // type: hmUI.data_type.STEP,
          // show_level: hmUI.show_level.ONLY_NORMAL,
          // });

          normal_step_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_step_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_step_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block


          //            normal_ALTIMETER_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          //              src: 'str_progress_down.png',
          //              center_x: 233,
          //              center_y: 233,
          //              x: 100,
          //              y: 233,
          //              start_angle: 225,
          //              end_angle: 180,
          //              type: hmUI.data_type.STEP,
          //              show_level: hmUI.show_level.ONLY_NORMAL,
          //            });

          normal_ALTIMETER_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'str_progress_down.png',
           center_x: 233,
           center_y: 233,
           pos_x: 466 / 2 - 100,
           pos_y: 0,
           angle: 220,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_ALTIMETER_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_ALTIMETER_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 3; i++) {
           normal_ALTIMETER_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_ALTIMETER_TextCircle_img_width / 2,
            pos_y: 233 + 164,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_ALTIMETER_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block    


          normal_high_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_high_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 4; i++) {
           normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_high_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };

          normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           center_x: 233,
           center_y: 233,
           pos_x: 233 - normal_high_TextCircle_unit_width / 2,
           pos_y: 233 - 192,
           src: 'dig_a_g.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
          //end of ignored block
          //const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);             

          normal_low_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_low_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 4; i++) {
           normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_low_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };

          normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           center_x: 233,
           center_y: 233,
           pos_x: 233 - normal_low_TextCircle_unit_width / 2,
           pos_y: 233 - 192,
           src: 'dig_a_g.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
          //end of ignored block


          normal_sunset_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_sunset_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_sunset_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };


          normal_sunrise_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_sunrise_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 5; i++) {
           normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_sunrise_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };

          normal_pai_total_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png'; // set of images with numbers
          normal_pai_total_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png'; // set of images with numbers

          //start of ignored block
          for (let i = 0; i < 3; i++) {
           normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 466,
            h: 466,
            center_x: 233,
            center_y: 233,
            pos_x: 233 - normal_pai_total_TextCircle_img_width / 2,
            pos_y: 233 - 192,
            src: 'dig_a_0.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };
          //end of ignored block			 


          normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 309,
           y: 401,
           image_array: ["wind_0.png", "wind_1.png", "wind_2.png", "wind_3.png", "wind_4.png", "wind_5.png", "wind_6.png", "wind_7.png"],
           image_length: 8,
           type: hmUI.data_type.WIND_DIRECTION,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress_down.png',
           center_x: 233,
           center_y: 233,
           x: 100,
           y: 233,
           start_angle: 135,
           end_angle: 90,
           type: hmUI.data_type.WIND,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 332,
           y: 351,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           angle: -45,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WIND,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress_down.png',
           center_x: 232,
           center_y: 233,
           x: 100,
           y: 233,
           start_angle: -135,
           end_angle: -180,
           type: hmUI.data_type.UVI,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 81,
           y: 329,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 0,
           angle: 45,
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.UVI,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress_down.png',
           center_x: 233,
           center_y: 233,
           x: 100,
           y: 233,
           start_angle: 135,
           end_angle: 90,
           type: hmUI.data_type.HUMIDITY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 332,
           y: 349,
           font_array: ["dig_a_0.png", "dig_a_1.png", "dig_a_2.png", "dig_a_3.png", "dig_a_4.png", "dig_a_5.png", "dig_a_6.png", "dig_a_7.png", "dig_a_8.png", "dig_a_9.png"],
           padding: false,
           h_space: 1,
           angle: -45,
           align_h: hmUI.align.LEFT,
           type: hmUI.data_type.HUMIDITY,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          //            const step = hmSensor.createSensor(hmSensor.id.STEP);
          //            step.addEventListener(hmSensor.event.CHANGE, function() {
          //              text_update();
          //            });


          normal_image_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'ic_1.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_image_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'ic_2.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_image_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'ic_3.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
           src: 'str_progress.png',
           center_x: 233,
           center_y: 233,
           x: 220,
           y: 212,
           start_angle: 90,
           end_angle: 135,
           type: hmUI.data_type.SUN_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
           hour_startX: 112,
           hour_startY: 184,
           hour_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           hour_zero: 1,
           hour_space: 8,
           hour_angle: 0,
           hour_align: hmUI.align.CENTER_H,

           minute_startX: 256,
           minute_startY: 184,
           minute_array: ["H_0.png", "H_1.png", "H_2.png", "H_3.png", "H_4.png", "H_5.png", "H_6.png", "H_7.png", "H_8.png", "H_9.png"],
           minute_zero: 1,
           minute_space: 8,
           minute_angle: 0,
           minute_follow: 0,
           minute_align: hmUI.align.CENTER_H,

           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           month_startX: 159,
           month_startY: 144,
           month_sc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_tc_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_en_array: ["mo_0.png", "mo_1.png", "mo_2.png", "mo_3.png", "mo_4.png", "mo_5.png", "mo_6.png", "mo_7.png", "mo_8.png", "mo_9.png", "mo_10.png", "mo_11.png"],
           month_is_character: true,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
           day_startX: 209,
           day_startY: 100,
           day_sc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_tc_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_en_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           day_zero: 1,
           day_space: 3,
           day_align: hmUI.align.LEFT,
           day_is_character: false,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 187,
           y: 329,
           font_array: ["data_0.png", "data_1.png", "data_2.png", "data_3.png", "data_4.png", "data_5.png", "data_6.png", "data_7.png", "data_8.png", "data_9.png"],
           padding: false,
           h_space: 1,
           unit_sc: 'data_g.png',
           unit_tc: 'data_g.png',
           unit_en: 'data_g.png',
           negative_image: 'dig_a_m.png',
           invalid_image: 'dig_a_v.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
           x: 204,
           y: 28,
           image_array: ["w_0.png", "w_1.png", "w_2.png", "w_3.png", "w_4.png", "w_5.png", "w_6.png", "w_7.png", "w_8.png", "w_9.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png"],
           image_length: 29,
           type: hmUI.data_type.WEATHER_CURRENT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
           x: 124,
           y: 283,
           week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 389,
           y: 210,
           src: 'status_B.png',
           type: hmUI.system_status.DISCONNECT,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
           x: 20,
           y: 201,
           src: 'status_H.png',
           type: hmUI.system_status.CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           x: 18,
           y: 230,
           font_array: ["dig_b_0.png", "dig_b_1.png", "dig_b_2.png", "dig_b_3.png", "dig_b_4.png", "dig_b_5.png", "dig_b_6.png", "dig_b_7.png", "dig_b_8.png", "dig_b_9.png"],
           padding: false,
           h_space: 0,
           invalid_image: 'dig_b_p.png',
           dot_image: 'dig_b_dot2.png',
           align_h: hmUI.align.CENTER_H,
           type: hmUI.data_type.ALARM_CLOCK,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
			 
            blok_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 213,
              src: flag_btn_on == 0 ? 'ic_blok_off.png' : 'ic_blok.png', 
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			 

          switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
           x: 36,
           y: 201,
           src: checkBT ? 'slider_on.png' : 'slider_off.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
           x: 385,
           y: 216,
           src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          normal_image_img_zona = hmUI.createWidget(hmUI.widget.IMG, {
           x: 212,
           y: 379,
           src: 'ic_zona.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          function text_update() {

           const weather = new hmSensor.Weather();
           let weatherData = weather.getForecast();
           let forecastData = weatherData.forecastData;

           // if  (zona == 1 ) {           


           //console.log('update text circle heart_rate_HEART');
           let valueHeartRate = heart.getLast();
           let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

           for (var i = 1; i < 3; i++) { // hide all symbols
            normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_heart = 47;
           if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) { // display data if it was possible to get it
            let normal_heart_rate_TextCircle_img_angle = 0;
            let normal_heart_rate_TextCircle_dot_img_angle = 0;
            normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width / 2, 178));
            // alignment = CENTER_H
            let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
            normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 2 * (normal_heart_rate_circle_string.length - 1) / 2;
            normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
            char_Angle_heart -= normal_heart_rate_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_heart_rate_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 3) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_heart -= normal_heart_rate_TextCircle_img_angle;
              firstSymbol = false;
              normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_heart);
              normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_heart_rate_TextCircle_img_width / 2);
              normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
              normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 0);
              char_Angle_heart -= normal_heart_rate_TextCircle_img_angle + 2;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           //console.log('update text circle calorie_CALORIE');
           let valueCalories = calorie.getCurrent();
           let normal_calorie_circle_string = parseInt(valueCalories).toString();

           for (var i = 1; i < 4; i++) { // hide all symbols
            normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_calorie = 44;
           if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) { // display data if it was possible to get it
            let normal_calorie_TextCircle_img_angle = 0;
            let normal_calorie_TextCircle_dot_img_angle = 0;
            normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width / 2, 178));
            // alignment = CENTER_H
            let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
            normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 2 * (normal_calorie_circle_string.length - 1) / 2;
            char_Angle_calorie -= normal_calorie_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_calorie_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 4) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_calorie += normal_calorie_TextCircle_img_angle;
              firstSymbol = false;
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_calorie);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_calorie_TextCircle_img_width / 2);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
              normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 0);
              char_Angle_calorie += normal_calorie_TextCircle_img_angle + 2;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           //console.log('update text circle battery_BATTERY');
           let valueBattery = battery.getCurrent();
           let normal_battery_circle_string = parseInt(valueBattery).toString();

           for (var i = 1; i < 3; i++) { // hide all symbols
            normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_battery = 316;
           if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) { // display data if it was possible to get it
            let normal_battery_TextCircle_img_angle = 0;
            let normal_battery_TextCircle_dot_img_angle = 0;
            normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width / 2, 178));
            // alignment = CENTER_H
            let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
            normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 2 * (normal_battery_circle_string.length - 1) / 2;
            normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
            char_Angle_battery -= normal_battery_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_battery_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 3) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_battery -= normal_battery_TextCircle_img_angle;
              firstSymbol = false;
              normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_battery);
              normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_battery_TextCircle_img_width / 2);
              normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
              normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 0);
              char_Angle_battery -= normal_battery_TextCircle_img_angle + 2;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           //console.log('update text circle step_STEP');
           let valueStep = step.getCurrent();
           let normal_step_circle_string = parseInt(valueStep).toString();

           for (var i = 1; i < 5; i++) { // hide all symbols
            normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           };
           let char_Angle_step = -45;
           if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) { // display data if it was possible to get it
            let normal_step_TextCircle_img_angle = 0;
            let normal_step_TextCircle_dot_img_angle = 0;
            normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width / 2, 178));
            // alignment = CENTER_H
            let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
            normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 2 * (normal_step_circle_string.length - 1) / 2;
            char_Angle_step -= normal_step_TextCircle_angleOffset;
            // alignment end

            let firstSymbol = true;
            let index = 0;
            for (let char of normal_step_circle_string) {
             let charCode = char.charCodeAt() - 48;
             if (index >= 5) break;
             if (charCode >= 0 && charCode < 10) {
              if (!firstSymbol) char_Angle_step += normal_step_TextCircle_img_angle;
              firstSymbol = false;
              normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_step);
              normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2);
              normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
              normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 0);
              char_Angle_step += normal_step_TextCircle_img_angle + 2;
              index++;
             }; // end if digit
            }; // end char of string
           } // end isFinite


           // };  //zona 0  


           if (zona == 1) {


            let airPressure = barometer.getAirPressure() * 0.750064;
            let valueALTIMETER = airPressure;
            let normal_ALTIMETER_circle_string = parseInt(valueALTIMETER).toString();

            for (var i = 1; i < 3; i++) { // hide all symbols
             normal_ALTIMETER_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle_ALTIMETER = 45;
            if (valueALTIMETER != null && valueALTIMETER != undefined && isFinite(valueALTIMETER) && normal_ALTIMETER_circle_string.length > 0 && normal_ALTIMETER_circle_string.length < 6) { // display data if it was possible to get it
             let normal_ALTIMETER_TextCircle_img_angle = 0;
             let normal_ALTIMETER_TextCircle_dot_img_angle = 0;
             normal_ALTIMETER_TextCircle_img_angle = toDegree(Math.atan2(normal_ALTIMETER_TextCircle_img_width / 2, 178));
             // alignment = CENTER_H
             let normal_ALTIMETER_TextCircle_angleOffset = normal_ALTIMETER_TextCircle_img_angle * (normal_ALTIMETER_circle_string.length - 1);
             normal_ALTIMETER_TextCircle_angleOffset = normal_ALTIMETER_TextCircle_angleOffset + 2 * (normal_ALTIMETER_circle_string.length - 1) / 2;
             normal_ALTIMETER_TextCircle_angleOffset = -normal_ALTIMETER_TextCircle_angleOffset;
             char_Angle_ALTIMETER -= normal_ALTIMETER_TextCircle_angleOffset;
             // alignment end                    
             let firstSymbol = true;
             let index = 0;
             for (let char of normal_ALTIMETER_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 3) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_ALTIMETER -= normal_ALTIMETER_TextCircle_img_angle;
               firstSymbol = false;
               normal_ALTIMETER_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_ALTIMETER);
               normal_ALTIMETER_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_ALTIMETER_TextCircle_img_width / 2);
               normal_ALTIMETER_TextCircle[index].setProperty(hmUI.prop.SRC, normal_ALTIMETER_TextCircle_ASCIIARRAY[charCode]);
               normal_ALTIMETER_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 1);
               char_Angle_ALTIMETER -= normal_ALTIMETER_TextCircle_img_angle + 2;
               index++;
              }; // end if digit
             }; // end char of string
            } // end isFinite


            //              let weatherData = weatherSensor.getForecastWeather();
            //              let forecastData = weatherData.forecastData;
            let high_temp = -100;
            if (forecastData.count > 0) {
             high_temp = forecastData.data[0].high;
            }; // end forecastData;

            console.log('update text circle high_forecastData');
            let temperatureHigh = undefined;
            let normal_high_circle_string = undefined;
            if (high_temp > -100) {
             temperatureHigh = 0;
             normal_high_circle_string = String(high_temp)
            };

            for (var i = 1; i < 4; i++) { // hide all symbols
             normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, zona == 1);
            let char_Angle_high_temp = -22;
            if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) { // display data if it was possible to get it
             let normal_high_TextCircle_img_angle = 0;
             let normal_high_TextCircle_dot_img_angle = 0;
             let normal_high_TextCircle_unit_angle = 0;
             normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width / 2, 178));
             normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width / 2, 178));
             normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width / 2, 178));
             // alignment = RIGHT
             let normal_high_TextCircle_angleOffset = normal_high_TextCircle_img_angle * (normal_high_circle_string.length - 1);
             normal_high_TextCircle_angleOffset = normal_high_TextCircle_angleOffset + (normal_high_TextCircle_img_angle + normal_high_TextCircle_unit_angle + 0) / 2;
             char_Angle_high_temp -= 2 * normal_high_TextCircle_angleOffset;
             // alignment end

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_high_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 4) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_high_temp += normal_high_TextCircle_img_angle;
               firstSymbol = false;
               normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_high_temp);
               normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_img_width / 2);
               normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
               normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 1);
               char_Angle_high_temp += normal_high_TextCircle_img_angle;
               index++;
              } // end if digit
              else {
               if (!firstSymbol) char_Angle_high_temp += normal_high_TextCircle_dot_img_angle;
               firstSymbol = false;
               normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_high_temp);
               normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_dot_width / 2);
               normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_m.png');
               normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 1);
               char_Angle_high_temp += normal_high_TextCircle_dot_img_angle;
               index++;
              }; // end if dot point 
             }; // end char of string
             char_Angle_high_temp += normal_high_TextCircle_unit_angle;
             normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle_high_temp);
             normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
            } // end isFinite
            else {
             normal_high_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle_high_temp);
             normal_high_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_high_TextCircle_error_img_width / 2);
             normal_high_TextCircle[0].setProperty(hmUI.prop.SRC, 'dig_a_v.png');
             normal_high_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
            }; // end else isFinite


            let low_temp = -100;
            if (forecastData.count > 0) {
             low_temp = forecastData.data[0].low;
            }; // end forecastData;

            console.log('update text circle low_forecastData');
            let temperatureLow = undefined;
            let normal_low_circle_string = undefined;
            if (low_temp > -100) {
             temperatureLow = 0;
             normal_low_circle_string = String(low_temp)
            };

            for (var i = 1; i < 4; i++) { // hide all symbols
             normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, zona == 1);
            let char_Angle_low = -67;
            if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) { // display data if it was possible to get it
             let normal_low_TextCircle_img_angle = 0;
             let normal_low_TextCircle_dot_img_angle = 0;
             let normal_low_TextCircle_unit_angle = 0;
             normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width / 2, 178));
             normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width / 2, 178));
             normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width / 2, 178));

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_low_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 4) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_low += normal_low_TextCircle_img_angle;
               firstSymbol = false;
               normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_low);
               normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_img_width / 2);
               normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
               normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 1);
               char_Angle_low += normal_low_TextCircle_img_angle;
               index++;
              } // end if digit
              else {
               if (!firstSymbol) char_Angle_low += normal_low_TextCircle_dot_img_angle;
               firstSymbol = false;
               normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_low);
               normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_dot_width / 2);
               normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_m.png');
               normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, zona == 1);
               char_Angle_low += normal_low_TextCircle_dot_img_angle;
               index++;
              }; // end if dot point 
             }; // end char of string
             char_Angle_low += normal_low_TextCircle_unit_angle;
             normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle_low);
             normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
            } // end isFinite
            else {
             normal_low_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle_low);
             normal_low_TextCircle[0].setProperty(hmUI.prop.POS_X, 233 - normal_low_TextCircle_error_img_width / 2);
             normal_low_TextCircle[0].setProperty(hmUI.prop.SRC, 'dig_a_v.png');
             normal_low_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
            }; // end else isFinite


            let tideData = weatherData.tideData;
            let sunrise_hour = 0;
            let sunrise_minute = 0;
            if (tideData.count > 0) {
             sunrise_hour = tideData.data[0].sunrise.hour;
             sunrise_minute = tideData.data[0].sunrise.minute;
            }; // end tideData;

            console.log('update text circle sunrise_tideData');
            let sunriseTime = undefined;
            let normal_sunrise_circle_string = undefined;
            if (sunrise_hour != 0 && sunrise_minute != 0) {
             sunriseTime = 0;
             normal_sunrise_circle_string = String(sunrise_hour) + '.' + String(sunrise_minute).padStart(2, '0');
            };

            for (var i = 1; i < 5; i++) { // hide all symbols
             normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle_sunrise = 21;
            if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) { // display data if it was possible to get it
             let normal_sunrise_TextCircle_img_angle = 0;
             let normal_sunrise_TextCircle_dot_img_angle = 0;
             normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width / 2, 178));
             normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width / 2, 178));

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_sunrise_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 5) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_sunrise += normal_sunrise_TextCircle_img_angle;
               firstSymbol = false;
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_img_width / 2);
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_sunrise += normal_sunrise_TextCircle_img_angle;
               index++;
              } // end if digit
              else {
               if (!firstSymbol) char_Angle_sunrise += normal_sunrise_TextCircle_dot_img_angle;
               firstSymbol = false;
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunrise);
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunrise_TextCircle_dot_width / 2);
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_dot2.png');
               normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_sunrise += normal_sunrise_TextCircle_dot_img_angle;
               index++;
              }; // end if dot point 
             }; // end char of string
            } // end isFinite


            let sunset_hour = 0;
            let sunset_minute = 0;
            if (tideData.count > 0) {
             sunset_hour = tideData.data[0].sunset.hour;
             sunset_minute = tideData.data[0].sunset.minute;
            }; // end tideData;

            console.log('update text circle sunset_tideData');
            let sunsetTime = undefined;
            let normal_sunset_circle_string = undefined;
            if (sunset_hour != 0 && sunset_minute != 0) {
             sunsetTime = 0;
             normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
            };

            for (var i = 1; i < 5; i++) { // hide all symbols
             normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle_sunset = 71;
            if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) { // display data if it was possible to get it
             let normal_sunset_TextCircle_img_angle = 0;
             let normal_sunset_TextCircle_dot_img_angle = 0;
             normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width / 2, 178));
             normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width / 2, 178));
             // alignment = RIGHT
             let normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_img_angle * (normal_sunset_circle_string.length - 1);
             char_Angle_sunset -= 2 * normal_sunset_TextCircle_angleOffset;
             // alignment end

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_sunset_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 5) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_sunset += normal_sunset_TextCircle_img_angle;
               firstSymbol = false;
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_img_width / 2);
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_sunset += normal_sunset_TextCircle_img_angle;
               index++;
              } // end if digit
              else {
               if (!firstSymbol) char_Angle_sunset += normal_sunset_TextCircle_dot_img_angle;
               firstSymbol = false;
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_sunset);
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_sunset_TextCircle_dot_width / 2);
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_dot2.png');
               normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_sunset += normal_sunset_TextCircle_dot_img_angle;
               index++;
              }; // end if dot point 
             }; // end char of string
            } // end isFinite

           }; //zona == 1

           if (zona == 2) {

            //console.log('update text circle DISTANCE');
            let distanceCurrent = distance.getCurrent();
            let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

            for (var i = 1; i < 5; i++) { // hide all symbols
             normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle_distance = -45;
            if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) { // display data if it was possible to get it
             let normal_distance_TextCircle_img_angle = 0;
             let normal_distance_TextCircle_dot_img_angle = 0;
             normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width / 2, 178));
             normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width / 2, 178));
             // alignment = CENTER_H
             let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
             normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
             normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + 1 * (normal_distance_circle_string.length - 1) / 2;
             char_Angle_distance -= normal_distance_TextCircle_angleOffset;
             // alignment end

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_distance_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 5) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_distance += normal_distance_TextCircle_img_angle;
               firstSymbol = false;
               normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_distance);
               normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
               normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
               normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_distance += normal_distance_TextCircle_img_angle + 1;
               index++;
              } // end if digit
              else {
               if (!firstSymbol) char_Angle_distance += normal_distance_TextCircle_dot_img_angle;
               firstSymbol = false;
               normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_distance);
               normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
               normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'dig_a_dot.png');
               normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_distance += normal_distance_TextCircle_dot_img_angle + 1;
               index++;
              }; // end if dot point 
             }; // end char of string
            } // end isFinite


            //const total = pai.getTotal()
            //const today = pai.getToday()
            //const lastWeek = pai.getLastWeek()			


            //console.log('update text circle pai_total_PAI');
            let totalPAI = pai.getToday();
            let normal_pai_total_circle_string = parseInt(totalPAI).toString();

            for (var i = 1; i < 3; i++) { // hide all symbols
             normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            let char_Angle_pai = 45;
            if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length < 6) { // display data if it was possible to get it
             let normal_pai_total_TextCircle_img_angle = 0;
             let normal_pai_total_TextCircle_dot_img_angle = 0;
             normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width / 2, 178));
             // alignment = CENTER_H
             let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
             normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + 1 * (normal_pai_total_circle_string.length - 1) / 2;
             char_Angle_pai -= normal_pai_total_TextCircle_angleOffset;
             // alignment end

             let firstSymbol = true;
             let index = 0;
             for (let char of normal_pai_total_circle_string) {
              let charCode = char.charCodeAt() - 48;
              if (index >= 3) break;
              if (charCode >= 0 && charCode < 10) {
               if (!firstSymbol) char_Angle_pai += normal_pai_total_TextCircle_img_angle;
               firstSymbol = false;
               normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle_pai);
               normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_pai_total_TextCircle_img_width / 2);
               normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
               normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
               char_Angle_pai += normal_pai_total_TextCircle_img_angle + 1;
               index++;
              }; // end if digit
             }; // end char of string
            } // end isFinite


           }; //zona == 2

          };


          bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           src: 'tap/bg_edit.png',
           show_level: hmUI.show_level.ONLY_EDIT,
          });

          const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
           resume_call: (function () {
            stopVibro();
            statusBT_last = hmBle.connectStatus();


            //text_update();
            //            scale_call();
            updateGrafik();


            let animRepeat = 1000;
            update_sec = setInterval(() => {

             text_update();

             let airPressure = barometer.getAirPressure() * 0.750064;
             //let baroAngle = Math.round((airPressure - 760) * 3.6); //угол от -144 до 144     144 / (800 - 760) = 3,6 градуса - 1 мм рт.ст
             let baroAngle = Math.round((airPressure - 1120) * (-45 / 80)); //800-720=80, 720+(225*80/45)=1120, 45°-длина дуги, 225°-начальный угол

             normal_ALTIMETER_progress_img_pointer.setProperty(hmUI.prop.ANGLE, baroAngle);


            }, animRepeat); // end timer


           }),

           pause_call: (function () {

            groupVremya.setProperty(hmUI.prop.VISIBLE, true);
            groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
            groupTap.setProperty(hmUI.prop.VISIBLE, false);
            clearInterval(update_sec)
            stopVibro();
            group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);

           }),
          });

          group_tip_AOD = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });


          groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });




          btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
           longpress_func: () => {
            vibro();
			   blok_btn_on();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_zona = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 350, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            click_zona();
           },
           //           longpress_func: () => {
           //            vibro();
           //            click_str();
           //           },

           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_checkBT = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 351,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: 'blank.png',
           press_src: 'blank.png',
           click_func: () => {
            vibro();
            toggleСheckConnection();
           },
           longpress_func: () => {
            vibro();
            menu_tip_AOD();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_HourVibro = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 7,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: 'blank.png',
           press_src: 'blank.png',
           click_func: () => {
            vibro();
            toggleEveryHourVibro();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });

          groupTap.createWidget(hmUI.widget.IMG, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           src: 'tap/i_tap_bg.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           src: apps[tap_2_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           src: apps[tap_3_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           src: apps[tap_4_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           src: apps[tap_5_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           src: apps[tap_6_select][2],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[0][0],
           y: tap_x_y[0][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_1_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[1][0],
           y: tap_x_y[1][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_2_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[2][0],
           y: tap_x_y[2][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_3_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[3][0],
           y: tap_x_y[3][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_4_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[4][0],
           y: tap_x_y[4][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_5_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: tap_x_y[5][0],
           y: tap_x_y[5][1],
           text: '',
           w: 113,
           h: 113,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            hmRouter.launchApp({
             url: apps[tap_6_select][1],
             native: true
            });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 24,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_run();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 183,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tap_zona_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //---------------------------    погода
          groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }

          //--------------------------------------------------------- 

          tip_AOD_bg = group_tip_AOD.createWidget(hmUI.widget.FILL_RECT, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
           color: 0x000000,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          titl_text = group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 35 - 5,
           w: 466,
           h: 50,
           text: 'Тип AOD',
           //font: 'Zepp OS Number.ttf',
           color: 0xffffff,
           text_size: 45,
           char_space: -0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });

          AOD_tip_0 = group_tip_AOD.createWidget(hmUI.widget.STROKE_RECT, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           color: curAODmode == 0 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          AOD_tip_1 = group_tip_AOD.createWidget(hmUI.widget.STROKE_RECT, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           color: curAODmode == 1 ? 0xff0000 : 0x800000,
           line_width: 6,
           radius: 20,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 140 - 5 + 100 * 0,
           w: 466,
           h: 50,
           text: 'Пустой AOD',
           color: 0xffffff,
           text_size: 30,
           char_space: 0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });


          group_tip_AOD.createWidget(hmUI.widget.TEXT, {
           x: 0,
           y: 140 - 5 + 100 * 1,
           w: 466,
           h: 50,
           text: 'Графика AOD',
           color: 0xffffff,
           text_size: 30,
           char_space: 0,
           text_style: hmUI.text_style.NONE,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V, //hmUI.align.RIGHT
           //type: hmUI.data_type.DATA,
           show_level: hmUI.show_level.ONLY_NORMAL
          });


          btn_tip_AOD_0 = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 117,
           y: 108 + 25 + 100 * 0,
           w: 233,
           h: 59,
           text: '',
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            curAODmode = 0;
            hmStorage.localStorage.setItem('DFCF_color_aod', curAODmode);
            select_tip_AOD();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          btn_tip_AOD_1 = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 117,
           y: 108 + 25 + 100 * 1,
           w: 233,
           h: 59,
           text: '',
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            curAODmode = 1;
            hmStorage.localStorage.setItem('DFCF_color_aod', curAODmode);
            select_tip_AOD();

           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          group_tip_AOD.createWidget(hmUI.widget.IMG, {
           x: 183,
           y: 354,
           src: 'undo.png',
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          btn_tip_AOD_exit = group_tip_AOD.createWidget(hmUI.widget.BUTTON, {
           x: 183,
           y: 354,
           text: '',
           w: 100,
           h: 100,
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png',
           click_func: () => {
            vibro();
            tip_AOD_exit();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
			 
          btn_blok_off = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: '0_Empty.png', //'press_pogoda.png'
           longpress_func: () => {
            vibro();
			   blok_btn_off();
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          btn_blok_off.setProperty(hmUI.prop.VISIBLE, false);

			 


          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 183, //x кнопки
           y: 183, //y кнопки
           text: '',
           w: 100, //ширина кнопки
           h: 100, //высота кнопки
           normal_src: '0_Empty.png',
           press_src: 'press_100.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          group_tip_AOD.setProperty(hmUI.prop.VISIBLE, false);

          for (let i = 0; i < 3; i++) {
           normal_ALTIMETER_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };

          for (let i = 0; i < 4; i++) {
           normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
          };


          for (let i = 0; i < 5; i++) {
           normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
           normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
			  
          };


          normal_image_img_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_image_img_3.setProperty(hmUI.prop.VISIBLE, false);
          normal_ALTIMETER_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_WEATHER_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          //normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);


          checkConnection(checkBT);
          setEveryHourVibro();


          //dynamic modify end
         }

         __$$module$$__.module = WatchFace({
          onInit() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) loadSettings();
          },
          build() {
           if (hmScene.getScene() == hmScene.SCENE_AOD) {
            makeAOD();
           } else {
            init_view();
           }
          },
          onPause() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: Ставлюсь на паузу!"});
           //else hmUI.showToast({text: "Ставлюсь на паузу!"});
          },
          onResume() {
           //if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) hmUI.showToast({text: "АОД: И снова здравствуйте!!!"});
           //else hmUI.showToast({text: "И снова здравствуйте!!!"});
          },
          onDestroy() {
           vibrate && vibrate.stop();
          }
         });

        }
       }.bind(__$$G$$__)(__$$G$$__);


      afterPageCreate()
      afterModuleCreate()

     })()
    } catch (e) {

     console.log('Mini Program Error', e)
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i))

     /* todo */
    }
